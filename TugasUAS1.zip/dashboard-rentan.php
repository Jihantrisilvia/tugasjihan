<?php
require __DIR__ . '/config.php';
start_lab_session('rentan');
require_login('rentan');
$mode = 'rentan';
$error = '';
$editId = 0;
$form = ['name' => '', 'category' => 'Makanan', 'price' => '', 'description' => '', 'image_url' => ''];
// --- HAPUS RENTAN: ID DI URL, TANPA OTORISASI PEMILIK ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'delete') {
    $id = (int) ($_GET['id'] ?? 0);
    try {
        // ⚠️ VULNERABLE LINE: perubahan data lewat GET; tidak ada CSRF token dan owner_id (CSRF + IDOR).
        $affected = $pdo->exec('DELETE FROM lab_products WHERE id = ' . $id);
        flash($affected ? 'success' : 'info', $affected ? 'Produk dihapus' : 'Produk tidak ditemukan', 'Katalog sudah diperbarui.');
        go('dashboard-rentan.php');
    } catch (PDOException $e) { $error = 'Produk belum dapat dihapus.'; flash('error', 'Hapus belum berhasil', $error); }
}
// --- TAMBAH / EDIT RENTAN ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = posted('action');
    $id = (int) posted('id');
    $editId = $action === 'update' ? $id : 0;
    foreach (array_keys($form) as $key) { $form[$key] = posted($key); }

    // ⚠️ VULNERABLE LINE: Penanganan upload berkas tanpa validasi ekstensi, tipe MIME, atau sanitasi nama (Unrestricted File Upload).
    if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        // ⚠️ VULNERABLE LINE: Nama berkas klien langsung digunakan tanpa sanitasi (risiko Path Traversal / Overwrite).
        // ⚠️ VULNERABLE LINE: Tidak ada pemeriksaan whitelist ekstensi (.php, .phtml, skrip eksekusi bebas diunggah).
        // ⚠️ VULNERABLE LINE: Tidak ada verifikasi tipe MIME / magic bytes di server.
        $uploadedName = $_FILES['image_file']['name'];
        $targetFile = $uploadDir . $uploadedName;
        if (move_uploaded_file($_FILES['image_file']['tmp_name'], $targetFile)) {
            $form['image_url'] = 'uploads/' . $uploadedName;
        }
    }

    // Cast ID/harga hanya agar demo IDOR dan SQLi teks mudah dibedakan; ini BUKAN validasi lengkap.
    $price = (int) posted('price');
    $owner = (int) $_SESSION['user_id'];
    try {
        // ⚠️ VULNERABLE LINE: tidak ada validasi CSRF token sebelum perubahan data.
        if ($action === 'update') {
            // ⚠️ VULNERABLE LINE: query gabungan input; UPDATE berdasarkan id saja, tanpa owner_id (SQLi + IDOR).
            $sql = "UPDATE lab_products SET name='" . $form['name'] . "', category='" . $form['category'] . "', price=" . $price . ", description='" . $form['description'] . "', image_url='" . $form['image_url'] . "' WHERE id=" . $id;
        } elseif ($action === 'create') {
            // ⚠️ VULNERABLE LINE: input teks langsung disambung menjadi perintah INSERT (SQL Injection).
            $sql = "INSERT INTO lab_products (owner_id,name,category,price,description,image_url) VALUES (" . $owner . ", '" . $form['name'] . "', '" . $form['category'] . "', " . $price . ", '" . $form['description'] . "', '" . $form['image_url'] . "')";
        } else { throw new RuntimeException('Invalid action'); }
        $pdo->exec($sql);
        flash('success', $action === 'update' ? 'Produk diperbarui' : 'Produk ditambahkan', 'Produk langsung tersedia di katalog.');
        go('dashboard-rentan.php');
    } catch (PDOException $e) { $error = 'Perubahan belum dapat disimpan. Periksa isian dan coba kembali.'; }
    catch (RuntimeException $e) { $error = 'Permintaan tidak valid.'; }
    if ($error !== '') {
        flash('error', 'Simpan belum berhasil', $error);
        go('dashboard-rentan.php');
    }
}
// --- AMBIL PRODUK UNTUK EDIT RENTAN ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'edit') {
    $id = (int) ($_GET['id'] ?? 0);
    try {
        // ⚠️ VULNERABLE LINE: ID dari URL dipakai tanpa memastikan pemilik data (IDOR).
        $product = $pdo->query('SELECT * FROM lab_products WHERE id = ' . $id)->fetch();
        if (!$product) { flash('info', 'Produk tidak ditemukan'); go('dashboard-rentan.php'); }
        $editId = (int) $product['id'];
        foreach (array_keys($form) as $key) { $form[$key] = $product[$key]; }
    } catch (PDOException $e) { $error = 'Produk belum dapat dimuat.'; flash('error', 'Gagal memuat produk', $error); }
}
// --- DAFTAR PRODUK LAB ---
$products = [];
try { $products = $pdo->query('SELECT p.*, u.username FROM lab_products p JOIN lab_users u ON u.id = p.owner_id ORDER BY p.id DESC')->fetchAll(); }
catch (PDOException $e) { flash('error', 'Data belum dapat dimuat', 'Periksa database lalu muat ulang halaman.'); }
$ownCount = count(array_filter($products, function ($p) { return (int) $p['owner_id'] === (int) $_SESSION['user_id']; }));
page_top('Dapur produk', $mode, 'dashboard');
?>

<section class="workspace-heading">
<div>
<span class="eyebrow">PENGELOLAAN MENU</span>
<h1>Dapur produk<span class="teal">.</span>
</h1>
<p>Racik menu baru dan perbarui koleksi sajian favoritmu.</p>
</div>
<div class="user-chip">
<div class="user-avatar">◈</div>
<div class="user-info">
<strong>
<?= h($_SESSION['username']) ?>
</strong>
<small>
<?= h($_SESSION['role']) ?> / ID <?= (int) $_SESSION['user_id'] ?>
</small>
</div>
<form action="logout-rentan.php" method="post">
<!-- ⚠️ VULNERABLE LINE: tidak ada token CSRF. -->
<button type="submit" class="btn small ghost">Keluar ↗</button>
</form>
</div>
</section>
<div class="stats">
<div class="stat">
<span class="stat-icon">▦</span>
<div>
<small>Total menu</small>
<strong>
<?= count($products) ?>
</strong>
</div>
</div>
<div class="stat">
<span class="stat-icon">♧</span>
<div>
<small>Menu milikmu</small>
<strong>
<?= $ownCount ?>
</strong>
</div>
</div>
<div class="stat">
<span class="stat-icon">◈</span>
<div>
<small>Kategori menu</small>
<strong>
<?= count(CATEGORIES) ?>
</strong>
</div>
</div>
</div>
<div class="dashboard-education">
<?php learning_labels('dashboard'); ?>
</div>
<div class="dashboard-layout">
<section class="panel editor-panel" id="editor">
<div class="panel-heading">
<h2>
<?= $editId ? 'Edit sajian' : 'Tambah sajian baru' ?>
</h2>
<span>
<?= $editId ? '#' . $editId : '+' ?>
</span>
</div>
<p class="editor-help">Lengkapi informasi sajian agar mudah ditemukan di katalog.</p>
<?php if ($error !== ''): ?>
<div class="form-error" role="status">
<?= h($error) ?>
</div>
<?php endif; ?>
<form method="post" action="dashboard-<?= h($mode) ?>.php" enctype="multipart/form-data" data-validate>
<!-- ⚠️ VULNERABLE LINE: tidak ada token CSRF. -->
<input type="hidden" name="action" value="<?= $editId ? 'update' : 'create' ?>">
<input type="hidden" name="id" value="<?= $editId ?>">
<label class="field wide">
<span>Nama produk</span>
<input name="name" value="<?= h($form['name']) ?>" maxlength="120" placeholder="Contoh: Nasi Goreng Nusantara" required>
</label>
<div class="field-row wide">
<label class="field">
<span>Kategori</span>
<select name="category" required>
<?php foreach (CATEGORIES as $c): ?>
<option value="<?= h($c) ?>" <?= $form['category'] === $c ? 'selected' : '' ?>>
<?= h($c) ?>
</option>
<?php endforeach; ?>
</select>
</label>
<label class="field">
<span>Harga (Rp)</span>
<input name="price" type="number" min="1" max="2000000000" step="1" value="<?= h($form['price']) ?>" placeholder="28000" required>
<small>Angka utuh, tanpa titik/koma.</small>
</label>
</div>
<label class="field wide">
<span>Deskripsi</span>
<textarea name="description" maxlength="4000" rows="3" placeholder="Ceritakan rasa khas sajianmu…" required>
<?= h($form['description']) ?>
</textarea>
</label>
<label class="field wide">
<span>URL gambar <small style="display:inline">(opsional)</small></span>
<input id="image-url" type="text" name="image_url" maxlength="2048" placeholder="https://… atau uploads/…" value="<?= h($form['image_url']) ?>">
<small>Gunakan tautan HTTPS langsung atau jalur upload berkas. Kosongkan untuk ikon bawaan.</small>
</label>
<div class="field wide">
<span>Upload berkas gambar <small style="display:inline">(opsional / alternatif)</small></span>
<!-- ⚠️ VULNERABLE LINE: Tidak ada atribut accept, mengizinkan pemilihan berkas apapun termasuk .php / skrip. -->
<div class="file-picker"><input id="image-file" type="file" name="image_file"><label for="image-file" class="file-picker-button"><i class="fa-solid fa-cloud-arrow-up" aria-hidden="true"></i> Pilih berkas</label><span class="file-picker-name" data-file-name>Belum ada berkas dipilih</span></div>
<small style="color:var(--orange)">⚠️ VULNERABLE: Formulir tidak membatasi tipe berkas (mendukung simulasi Arbitrary File Upload).</small>
</div>
<div class="review-card wide">
  <div class="review-header">
    <span class="review-title">Pratinjau &amp; Review Gambar</span>
    <span id="preview-source-badge" class="badge neutral">Belum ada gambar</span>
  </div>
  <div class="image-preview" id="image-preview-container">
    <span id="preview-placeholder">▧<br>Pratinjau gambar sajian</span>
    <img id="image-preview" alt="Pratinjau gambar produk" hidden>
  </div>
  <div id="file-review-box" class="file-review-box" hidden>
    <div class="review-row">
      <span class="review-label">Nama berkas:</span>
      <strong id="review-filename" class="review-val">-</strong>
    </div>
    <div class="review-row">
      <span class="review-label">Ukuran berkas:</span>
      <span id="review-filesize" class="review-val">-</span>
    </div>
    <div class="review-row">
      <span class="review-label">Tipe MIME:</span>
      <span id="review-filetype" class="review-val">-</span>
    </div>
    <div id="review-security-verdict" class="review-verdict"></div>
    <button type="button" id="btn-clear-file" class="btn small ghost full-width" style="margin-top:10px">✕ Batalkan pilihan berkas</button>
  </div>
</div>
<button class="btn primary full-width wide" type="submit">
<?= $editId ? 'Simpan perubahan' : '+ Tambahkan ke menu' ?>
</button>
<?php if ($editId): ?>
<a href="dashboard-<?= h($mode) ?>.php" class="btn ghost full-width wide" style="margin-top:10px">Batal edit</a>
<?php endif; ?>
</form>
</section>
<section class="panel inventory-panel" id="inventory">
<div class="panel-heading">
<h2>Koleksi menu</h2>
<a href="#inventory" class="text-link">Lihat koleksi lab ↗</a>
</div>
<p class="inventory-note">Lihat seluruh koleksi dan perbarui informasi setiap sajian.</p>
<?php if (!$products): ?>
<div class="empty-state">
<span>🍽️</span>
<h3>Dapur masih sepi.</h3>
<p>Tambahkan sajian pertamamu di formulir.</p>
</div>
<?php else: ?>
<div class="inventory-list">
<?php foreach ($products as $p): $isOwner = (int) $p['owner_id'] === (int) $_SESSION['user_id']; ?>
<article class="inventory-item">
<div class="inventory-image">
<?php
// ⚠️ VULNERABLE LINE: path/URL dirender langsung tanpa pembersihan protokol ketat
if (!empty($p['image_url'])): ?>
    <img src="<?= $p['image_url'] ?>" alt="<?= h($p['name']) ?>" loading="lazy" decoding="async">
<?php else: ?>
    <?php photo_html($p['image_url'], 'Foto sajian', $p['category']); ?>
<?php endif; ?>
</div>
<div class="inventory-details">
<div class="inventory-meta">
<span>#<?= (int) $p['id'] ?>
</span>
<span>
<?= h($p['category']) ?>
</span>
<span class="owner-tag">
<?= $isOwner ? '◈ Milikmu' : '○ ' . h($p['username']) ?> / pemilik #<?= (int) $p['owner_id'] ?>
</span>
</div>
<h3>
<?php // ⚠️ VULNERABLE LINE: echo HTML mentah dari database (stored XSS).
 echo $p['name']; ?>
</h3>
<p>
<?php // ⚠️ VULNERABLE LINE: deskripsi ditampilkan tanpa htmlspecialchars (stored XSS).
 echo $p['description']; ?>
</p>
</div>
<div class="inventory-side">
<strong class="inventory-price">
<?= rupiah($p['price']) ?>
</strong>
<div class="inventory-actions">
<!-- ⚠️ VULNERABLE LINE: semua produk memiliki link edit/hapus tanpa otorisasi owner di server. -->
<a class="action-btn" href="dashboard-rentan.php?action=edit&amp;id=<?= (int) $p['id'] ?>#editor">Edit</a>
<a class="action-btn delete" href="dashboard-rentan.php?action=delete&amp;id=<?= (int) $p['id'] ?>" data-delete-link>Hapus</a>
</div>
</div>
</article>
<?php endforeach; ?>
</div>
<?php endif; ?>
</section>
</div>
<script>
const imageInput = document.getElementById('image-url');
const imageFile = document.getElementById('image-file');
const preview = document.getElementById('image-preview');
const placeholder = document.getElementById('preview-placeholder');
const badge = document.getElementById('preview-source-badge');
const reviewBox = document.getElementById('file-review-box');
const reviewFilename = document.getElementById('review-filename');
const reviewFilesize = document.getElementById('review-filesize');
const reviewFiletype = document.getElementById('review-filetype');
const reviewVerdict = document.getElementById('review-security-verdict');
const btnClearFile = document.getElementById('btn-clear-file');

let activeObjectUrl = null;

function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024, sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function updatePreview() {
  if (activeObjectUrl) {
    URL.revokeObjectURL(activeObjectUrl);
    activeObjectUrl = null;
  }

  // Jika berkas lokal dipilih melalui upload
  if (imageFile.files && imageFile.files[0]) {
    const file = imageFile.files[0];
    reviewBox.hidden = false;
    reviewFilename.textContent = file.name;
    reviewFilesize.textContent = formatBytes(file.size);
    reviewFiletype.textContent = file.type || 'Tidak diketahui / binari';
    
    const ext = file.name.split('.').pop().toLowerCase();
    const isScript = ['php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'phar', 'sh', 'exe', 'cgi', 'pl', 'py'].includes(ext);
    const isImage = file.type.startsWith('image/') || ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg', 'bmp', 'ico'].includes(ext);

    if (isScript) {
      badge.className = 'badge danger';
      badge.textContent = '⚡ Potensi RCE (Skrip)';
      reviewVerdict.innerHTML = '<div class="status-msg danger"><b>⚡ PERINGATAN LAB RENTAN:</b> Anda memilih berkas skrip eksekusi (<code>.' + ext + '</code>). Server rentan tidak memvalidasi ekstensi sehingga berkas ini akan tersimpan langsung di <code>uploads/</code> dan berisiko dieksekusi di server (Arbitrary File Upload / Remote Code Execution)!</div>';
    } else {
      badge.className = 'badge danger';
      badge.textContent = '⚠ Berkas siap (Rentan)';
      reviewVerdict.innerHTML = '<div class="status-msg warn"><b>⚠ INFORMASI LAB RENTAN:</b> Berkas siap diunggah. Di mode rentan, server menyimpan berkas dengan nama asli ke <code>uploads/</code> tanpa pemeriksaan tipe MIME asli (magic bytes) maupun sanitasi nama.</div>';
    }

    if (isImage) {
      activeObjectUrl = URL.createObjectURL(file);
      preview.src = activeObjectUrl;
    } else {
      preview.removeAttribute('src');
      preview.hidden = true;
      placeholder.hidden = false;
      placeholder.innerHTML = '⚠️<br>Berkas bukan gambar: <code>' + file.name + '</code><br><small style="color:var(--orange)">Server rentan tetap akan menyimpannya</small>';
      return;
    }
  } else {
    // Tidak ada berkas baru dipilih, periksa URL atau nilai tersimpan
    reviewBox.hidden = true;
    const val = imageInput.value.trim();
    if (val !== '') {
      badge.className = 'badge neutral';
      badge.textContent = val.startsWith('uploads/') ? 'Gambar tersimpan' : 'Tautan URL';
      preview.src = val;
    } else {
      badge.className = 'badge neutral';
      badge.textContent = 'Belum ada gambar';
      preview.removeAttribute('src');
      preview.hidden = true;
      placeholder.hidden = false;
      placeholder.innerHTML = '▧<br>Pratinjau gambar sajian';
      return;
    }
  }
}

preview.addEventListener('load', () => {
  preview.hidden = false;
  placeholder.hidden = true;
});

preview.addEventListener('error', () => {
  preview.hidden = true;
  placeholder.hidden = false;
  placeholder.innerHTML = '✕<br>Gambar tidak dapat dimuat';
});

imageInput.addEventListener('input', () => {
  if (!imageFile.files || imageFile.files.length === 0) {
    updatePreview();
  }
});

imageFile.addEventListener('change', updatePreview);

btnClearFile.addEventListener('click', () => {
  imageFile.value = '';
  imageFile.dispatchEvent(new Event('change'));
});

// Panggil pertama kali saat halaman dimuat
updatePreview();
</script>
<?php page_bottom(); ?>

