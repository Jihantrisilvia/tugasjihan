<?php
require __DIR__ . '/config.php';
start_lab_session('rentan');
// --- PROSES LOGIN RENTAN: HANYA UNTUK BELAJAR DI LOCALHOST ---
$error = '';
$username = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = posted('username');
    $password = posted('password');
    // ⚠️ VULNERABLE LINE: login diproses tanpa verifikasi CSRF token.
    try {
        // ⚠️ VULNERABLE LINE: username/password langsung menjadi bagian SQL; celah SQL Injection.
        $sql = "SELECT id, username, role FROM lab_users WHERE username = '" . $username . "' AND password = '" . $password . "' LIMIT 1";
        // ⚠️ VULNERABLE LINE: password dicocokkan sebagai teks biasa, tanpa password_verify().
        $user = $pdo->query($sql)->fetch();
        if ($user) {
            unset($_SESSION['lab_logout_incomplete'], $_SESSION['lab_logout_until'], $_SESSION['lab_logout_expired']);
            // ⚠️ VULNERABLE LINE: identitas login disimpan tanpa session_regenerate_id().
            $_SESSION['user_id'] = (int) $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            flash('success', 'Selamat datang di dapur!', 'Silakan kelola menu dan sajian favoritmu.');
            go('dashboard-rentan.php');
        }
        $error = 'Username atau password tidak valid.';
    } catch (PDOException $e) {
        $error = 'Login belum dapat diproses. Periksa input dan coba kembali.';
    }
    flash('error', 'Login belum berhasil', $error);
    go('login-rentan.php');
}
page_top('Masuk akun', 'rentan', 'login');
?>
<section class="auth-layout">
<div class="auth-story">
<span class="eyebrow">WELCOME TO THE FLAVOR SIDE</span>
<h1>Racik rasa.<br>
<span class="gradient-text">Bagikan cerita.</span>
</h1>
<p>Kelola sajian favorit, perbarui koleksi menu, dan hadirkan rasa khas Nusantara dari dapurmu.</p>
<div class="auth-art" aria-hidden="true">
<span><i class="fa-solid fa-bowl-food"></i></span>
<span><i class="fa-solid fa-mug-hot"></i></span>
<span><i class="fa-solid fa-cookie-bite"></i></span>
</div>
<ul class="feature-list">
<li>Koleksi menu dalam satu tempat</li>
<li>Harga dan informasi sajian yang mudah diperbarui</li>
<li>Tampilan menarik untuk setiap rasa</li>
</ul>
</div>
<div class="auth-panel panel">
<span class="eyebrow">AKUN KAWAN SANTAP</span>
<h2>Selamat datang kembali.</h2>
<p>Masuk untuk mengelola menu dan koleksi sajianmu.</p>
<?php if ($error !== ''): ?>
<div class="form-error" role="status">
<?= h($error) ?>
</div>
<?php endif; ?>
<form method="post" action="login-rentan.php" data-validate>
<!-- ⚠️ VULNERABLE LINE: form tidak memiliki CSRF token. -->
<label class="field">
<span>Username</span>
<input name="username" value="<?= h($username) ?>" autocomplete="username" placeholder="Masukkan Username" required>
</label>
<label class="field" for="password">
<span>Password</span>
</label>
<div class="field password-wrap">
<input id="password" name="password" type="password" autocomplete="current-password" placeholder="Masukkan password" required>
<button type="button" data-password-toggle="password" aria-label="Tampilkan atau sembunyikan password" aria-pressed="false">Lihat</button>
</div>
<button class="btn primary full-width" type="submit">Masuk ke dapur <span>→</span>
</button>
<p class="form-hint">Uji di localhost: username <code>admin_rentan' -- -</code> atau <code>admin_rentan' #</code>; password isi sembarang. Password tetap dicek pada login normal, tetapi komentar SQL melewati cek itu pada mode rentan.</p>
</form>
<p class="auth-switch">Belum punya akun lab? <a href="register-rentan.php">Daftar mode rentan</a></p>
</div>
</section>
<?php login_test_guide('rentan', true); page_bottom(); ?>

