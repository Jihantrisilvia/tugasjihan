<?php
require __DIR__ . '/config.php';
start_lab_session('rentan');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    flash('error', 'Permintaan logout tidak valid', 'Gunakan tombol Keluar pada dashboard.');
    go(empty($_SESSION['user_id']) ? 'login-rentan.php' : 'dashboard-rentan.php');
}
if (empty($_SESSION['user_id'])) { go('login-rentan.php'); }
// VULNERABLE: hanya berpindah halaman; session_unset() dan session_destroy() tidak dipanggil.
$_SESSION['lab_logout_incomplete'] = true;
if (empty($_SESSION['lab_logout_until'])) { $_SESSION['lab_logout_until'] = time() + 60; }
go('login-rentan.php?loggedout=1');
