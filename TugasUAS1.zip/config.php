<?php
/*
 * Kawan Santap — laboratorium lokal PHP native (PHP 8.0+ + pdo_mysql).
 * INSTALASI XAMPP / LARAGON:
 * 1. Ekstrak folder rasanusantara ke htdocs (XAMPP) atau www (Laragon).
 * 2. Jalankan Apache dan MySQL. Import database.sql melalui phpMyAdmin.
 *    SQL membuat database rasanusantara. Import ulang akan MEReset data demo.
 * 3. Sesuaikan DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS di bawah ini.
 * 4. Buka http://localhost/rasanusantara/ (jangan buka file://).
 * Akun/password demo dan panduan belajar ada di README.md.
 * Gambar memakai URL HTTPS, bukan upload berkas. Internet untuk CDN/font/foto.
 * KHUSUS localhost: jangan pasang lab rentan ini pada hosting publik.
 */

// --- KONFIGURASI DATABASE ---
const DB_HOST = '127.0.0.1';
const DB_PORT = '3306';
const DB_NAME = 'rasanusantara';
const DB_USER = 'root';
const DB_PASS = '';
const SECURE_IDLE_TIMEOUT = 900;
const CATEGORIES = ['Makanan', 'Minuman', 'Camilan', 'Dessert'];

// --- BATAS LINGKUNGAN LAB ---
// Peer IP diperiksa, bukan Host/X-Forwarded-For yang dapat dipalsukan.
if (PHP_SAPI !== 'cli' && !in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1', '::ffff:127.0.0.1'], true)) {
    http_response_code(403);
    exit('Lab edukasi ini hanya dapat dibuka dari localhost.');
}
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('X-Frame-Options: DENY');
header('Cache-Control: no-store');

// --- KONEKSI DATABASE ---
try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        // Lab SQLi tetap ada pada query gabungan; eksekusi multi-statement dibatasi.
        PDO::MYSQL_ATTR_MULTI_STATEMENTS => false,
    ]);
} catch (PDOException $e) {
    http_response_code(503);
    // AMAN: detail koneksi/query tidak dikirim ke browser.
    ?>
<!doctype html>
<html lang="id">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Kawan Santap · Persiapan</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
<link rel="stylesheet" href="assets/interior.css?v=20261114-3">
<body class="interior-page setup-page">
<main class="setup panel">
<span class="eyebrow">KAWAN SANTAP / PERSIAPAN TOKO</span>
<h1>Siapkan dapurnya dulu.</h1>
<p>Koneksi database belum tersedia. Jalankan MySQL, import <code>database.sql</code>, lalu sesuaikan kredensial di <code>config.php</code>.</p>
<a class="btn primary" href="index.php">Coba lagi</a>
<p class="muted">Petunjuk lengkap ada di README.md.</p>
</main>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11">
</script>
<script>if(window.Swal){Swal.fire({icon:'info',title:'Database belum siap',text:'Periksa MySQL, hasil import, dan konfigurasi koneksi.',background:'#fff',color:'#291e20',confirmButtonColor:'#d92747'});}</script>
</html>
<?php
    exit;
}

// --- FUNGSI KECIL BERSAMA (TETAP DALAM STRUKTUR FLAT) ---
function h($value): string { return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function rupiah($value): string { return 'Rp ' . number_format((int) $value, 0, ',', '.'); }
function go(string $path): void { header('Location: ' . $path, true, 303); exit; }
function posted(string $key): string { return isset($_POST[$key]) && is_string($_POST[$key]) ? $_POST[$key] : ''; }
function product_image($url): string {
    $url = (string) $url;
    if ($url === '') {
        return '';
    }
    // Mengizinkan berkas hasil upload lokal yang valid di folder uploads/
    if (preg_match('#^uploads/[a-zA-Z0-9_\-\.]+$#', $url) && !str_contains($url, '..')) {
        return $url;
    }
    return strlen($url) <= 2048 && filter_var($url, FILTER_VALIDATE_URL) && strtolower((string) parse_url($url, PHP_URL_SCHEME)) === 'https' ? $url : '';
}
function start_lab_session(string $mode): void {
    // Sesi terpisah mencegah login rentan menjadi autentikasi untuk mode aman.
    session_name($mode === 'aman' ? 'RN_SECURE' : 'RN_VULNERABLE');
    ini_set('session.use_only_cookies', '1');
    if ($mode === 'aman') {
        // AMAN: strict mode menolak ID sesi arbitrer; HttpOnly menghalangi pembacaan cookie via JS.
        ini_set('session.use_strict_mode', '1');
        session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
    } else {
        // ⚠️ VULNERABLE LINE: konfigurasi lemah sengaja untuk demonstrasi sesi.
        ini_set('session.use_strict_mode', '0');
        session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => false, 'httponly' => false, 'samesite' => '']);
    }
    session_start();
    // Jendela demonstrasi setelah logout rentan: sesi lama masih bisa dipakai selama 60 detik.
    if ($mode === 'rentan' && isset($_SESSION['lab_logout_until']) && time() >= (int) $_SESSION['lab_logout_until']) {
        $_SESSION = [];
        session_destroy();
        $cookie = session_get_cookie_params();
        setcookie(session_name(), '', ['expires' => time() - 42000, 'path' => $cookie['path'], 'domain' => $cookie['domain'], 'secure' => $cookie['secure'], 'httponly' => $cookie['httponly'], 'samesite' => $cookie['samesite'] ?? '']);
        session_id('');
        session_start();
        $_SESSION['lab_logout_expired'] = true;
    }
    if ($mode === 'aman' && !empty($_SESSION['user_id']) && isset($_SESSION['last_active'])
        && time() - (int) $_SESSION['last_active'] > SECURE_IDLE_TIMEOUT) {
        $_SESSION = [];
        session_regenerate_id(true);
        $_SESSION['expired'] = true;
    }
    if ($mode === 'aman' && empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
}
function csrf_ok(): bool {
    return isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], posted('csrf'));
}
function safe_login_client_key(): string {
    // Lab hanya menerima loopback; IPv4/IPv6 localhost memakai kunci yang sama.
    // Pergantian username, browser, atau alias localhost tidak menghapus batas percobaan.
    return '@client:localhost';
}
function safe_login_clear_expired(PDO $pdo, string $key): void {
    $statement = $pdo->prepare('DELETE FROM login_attempts WHERE username = ? AND locked_until <= NOW()');
    $statement->execute([$key]);
}
function safe_login_lock_seconds(PDO $pdo, string $key): int {
    $statement = $pdo->prepare('SELECT GREATEST(CEIL(TIMESTAMPDIFF(MICROSECOND, NOW(6), locked_until) / 1000000), 0) FROM login_attempts WHERE username = ? AND locked_until > NOW()');
    $statement->execute([$key]);
    return (int) ($statement->fetchColumn() ?: 0);
}
function safe_login_record_failure(PDO $pdo, string $key): int {
    $statement = $pdo->prepare('INSERT INTO login_attempts (username,failed_count,locked_until) VALUES (?,1,NULL) ON DUPLICATE KEY UPDATE locked_until = IF(failed_count >= 4, DATE_ADD(NOW(), INTERVAL 1 MINUTE), NULL), failed_count = failed_count + 1');
    $statement->execute([$key]);
    return safe_login_lock_seconds($pdo, $key);
}
function flash(string $icon, string $title, string $message = ''): void {
    $_SESSION['flash'] = ['icon' => $icon, 'title' => $title, 'text' => $message];
}
function require_login(string $mode, ?string $loginPage = null): void {
    if (empty($_SESSION['user_id']) || ($mode === 'aman' && (!isset($_SESSION['session_marker']) || !hash_equals($_SESSION['session_marker'], hash('sha256', session_id()))))) {
        if (!($mode === 'rentan' && !empty($_SESSION['lab_logout_expired']))) {
            flash('info', 'Masuk terlebih dahulu', !empty($_SESSION['expired']) ? 'Sesi berakhir. Silakan masuk kembali.' : 'Masuk ke akunmu untuk mengelola menu.');
        }
        go($loginPage ?? 'login-' . $mode . '.php');
    }
    if ($mode === 'aman') { $_SESSION['last_active'] = time(); }
}
function photo_html($url, string $alt, string $category = 'Makanan'): void {
    $icons = ['Makanan' => 'fa-bowl-food', 'Minuman' => 'fa-mug-hot', 'Camilan' => 'fa-cookie-bite', 'Dessert' => 'fa-ice-cream'];
    ?>
<div class="food-photo">
<span class="food-placeholder" aria-hidden="true">
<i class="fa-solid <?= $icons[$category] ?? 'fa-utensils' ?>"></i>
</span>
<?php if (product_image($url) !== ''): ?>
<img src="<?= h(product_image($url)) ?>" alt="<?= h($alt) ?>" loading="lazy" decoding="async" referrerpolicy="no-referrer">
<?php endif; ?>
</div>
<?php
}
function page_top(string $title, string $mode = '', string $page = ''): void {
    $rentanLogoutNotice = $mode === 'rentan' && !empty($_SESSION['lab_logout_incomplete']) && !empty($_SESSION['lab_logout_until']);
    $rentanSeconds = $rentanLogoutNotice ? max(0, (int) $_SESSION['lab_logout_until'] - time()) : 0;
    ?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#fff8f7">
<title>
<?= h($title) ?> · Kawan Santap</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<link rel="icon" type="image/svg+xml" href="assets/kawan-santap-logo.svg">
<link rel="stylesheet" href="assets/style.css?v=20261114-2">
<?php if ($page === 'index'): ?><link rel="stylesheet" href="assets/home.css?v=20261114-3"><?php endif; ?>
<?php if (in_array($page, ['login', 'register', 'dashboard', 'checkout'], true)): ?><link rel="stylesheet" href="assets/interior.css?v=20261114-12"><?php endif; ?>
</head>
<body class="<?= $page === 'index' ? 'home-page' : 'interior-page' ?><?= $page === 'checkout' ? ' checkout-page' : '' ?>">
    <div class="lab-strip">
<span class="status-dot">
</span> KAWAN SANTAP <span class="strip-divider">/</span> Makanan &amp; minuman favoritmu
<?php if ($rentanLogoutNotice): ?><span class="grace-strip" data-rentan-remaining="<?= $rentanSeconds ?>">Sesi lama masih aktif dalam mode rentan · <b data-rentan-countdown><?= sprintf('%02d:%02d', intdiv($rentanSeconds, 60), $rentanSeconds % 60) ?></b></span><?php endif; ?>
<span class="strip-right">RASA LOKAL • RACIKAN KEKINIAN</span>
</div>
    <header class="site-header">
<a class="brand" href="index.php" aria-label="Kawan Santap beranda">
<img class="brand-logo" src="assets/kawan-santap-logo.svg" alt="" width="48" height="48">
<span>Kawan<span class="brand-accent"> Santap</span>
<small>RAGAM RASA, SATU CERITA.</small>
</span>
</a>
<nav aria-label="Navigasi utama">
<a class="nav-link <?= $page === 'index' ? 'active' : '' ?>" href="index.php#menu">Jelajah menu</a>
<?php if ($mode !== ''): ?>
<div class="mode-switch" aria-label="Pilih versi">
<a class="<?= $mode === 'aman' ? 'selected secure' : '' ?>" href="<?= h($page) ?>-aman.php">◈ Aman</a>
<a class="<?= $mode === 'rentan' ? 'selected vulnerable' : '' ?>" href="<?= h($page) ?>-rentan.php">⚠ Rentan</a>
</div>
<?php else: ?>
<?php if (!empty($_SESSION['user_id']) && ($_SESSION['role'] ?? '') === 'customer'): ?>
<?php if (basename($_SERVER['SCRIPT_NAME'] ?? '') !== 'dashboard-customer.php'): ?><a class="btn small primary" href="dashboard-customer.php">Pesanan saya <span>→</span></a><?php endif; ?>
<?php elseif (!empty($_SESSION['user_id']) && ($_SESSION['role'] ?? '') === 'admin'): ?><a class="btn small primary" href="dashboard-aman.php">Panel admin <span>→</span></a>
<?php else: ?><a class="btn small primary" href="<?= in_array(basename($_SERVER['SCRIPT_NAME'] ?? ''), ['checkout.php','login-customer.php','register-customer.php'], true) ? 'login-customer.php' : 'login-aman.php' ?>">Masuk <span>→</span></a><?php endif; ?>
<?php endif; ?>
</nav>
</header>
    <main class="container">
<?php
}
function login_test_guide(string $mode, bool $drawer = false): void {
    $safe = $mode === 'aman';
    ?>
<details class="login-test-guide<?= $drawer ? ' is-drawer' : '' ?>">
  <summary aria-label="Buka atau tutup panduan uji manual"><i class="fa-solid fa-book-open guide-open-icon" aria-hidden="true"></i><span class="guide-label">Panduan</span><i class="fa-solid fa-xmark guide-close-icon" aria-hidden="true"></i><i class="fa-solid fa-chevron-down guide-chevron" aria-hidden="true"></i></summary>
  <div class="login-test-guide-content">
  <?php if ($drawer): ?>
    <?php learning_labels('login', $mode, true); ?>
  <?php else: ?>
  <span class="guide-mode">PANDUAN UJI MANUAL · MODE <?= $safe ? 'AMAN' : 'RENTAN' ?></span>
  <h2>Tiga hal yang bisa kamu periksa</h2>
  <ol>
    <li><strong>Uji SQL Injection.</strong> <?= $safe ? 'Di login aman, kirim payload uji SQL Injection sebagai username dan password salah. Login harus ditolak: prepared statement mengirim username sebagai teks, sehingga tanda petik dan komentar tidak mengubah perintah SQL.' : 'Di login rentan, login normal tetap memeriksa password. Lalu uji username <code>admin_rentan\' -- -</code> atau <code>admin_rentan\' #</code> dengan password salah. Jika query berubah, komentar SQL membuat bagian pemeriksaan password di belakangnya diabaikan.' ?></li>
    <li><strong>Password dan percobaan berulang.</strong> Periksa tabel <?= $safe ? '<code>users</code>: password baru tersimpan sebagai hash bcrypt. Lima login salah di lab localhost yang sama, meski username berbeda, mengunci percobaan selama 1 menit dan halaman menampilkan hitung mundur.' : '<code>lab_users</code>: password tersimpan sebagai teks biasa. Login salah berulang tidak dikunci.' ?></li>
    <li><strong>Sesi dan logout.</strong> Login, klik Keluar, lalu tekan Back atau buka ulang dashboard. <?= $safe ? 'Dashboard meminta login lagi karena sesi langsung dihapus.' : 'Dashboard masih dapat dibuka selama 1 menit karena logout rentan belum menghapus sesi. Lihat hitung mundur di header.' ?></li>
  </ol>
  <?php endif; ?>
  </div>
</details>
<?php
}
function guide_copy_lines(string $input): void {
    echo '<pre class="guide-copy-lines"><code>';
    foreach (preg_split('/\R/u', $input) as $line) {
        $trimmed = trim($line);
        if ($trimmed === '') { echo '<span class="guide-copy-gap"></span>'; continue; }
        if (preg_match('/^(?:Tombol\b|Tindakan:|Cookie(?: pembanding)?:)/u', $trimmed)) {
            echo '<span class="guide-copy-heading">' . h($line) . '</span>';
            continue;
        }
        if (preg_match('/^([^:]+):\s*(.+)$/u', $trimmed, $matches)) {
            $copyValue = trim($matches[2]);
        } elseif (str_ends_with($trimmed, ':')) {
            echo '<span class="guide-copy-heading">' . h($line) . '</span>';
            continue;
        } else {
            $copyValue = $trimmed;
        }
        echo '<button type="button" class="guide-copy-line" data-copy="' . h($copyValue) . '" aria-label="Salin ' . h($copyValue) . '" title="Klik untuk menyalin">' . h($line) . '<i class="fa-regular fa-copy" aria-hidden="true"></i></button>';
    }
    echo '</code></pre>';
}
function learning_labels(string $page, string $mode = 'rentan', bool $embedded = false): void {
    // Semua contoh di bawah dirender dengan h(): contoh XSS tidak dieksekusi saat panduan dibuka.
    // Ini adalah petunjuk manual. Tidak ada tombol yang otomatis mengirim payload atau menghapus data.
    $lessons = [
        [
            'title' => 'SQL Injection',
            'button_title' => 'Uji SQL Injection',
            'definition' => 'SQL Injection terjadi saat input disambungkan langsung ke perintah database. Apostrof dapat menutup teks username, lalu OR atau komentar SQL dapat mengubah arti query.',
            'impact' => 'Pada versi rentan, penyerang dapat mengubah kondisi login dan melewati pemeriksaan password. Versi aman menjaga input tetap sebagai data.',
            'steps' => [
                ['1. Coba login normal', 'Buka login-rentan.php. Masukkan akun demo dan klik Masuk.', "Username: admin_rentan\nPassword: RasaRentan!2026", 'Dashboard terbuka. Ini hanya membuktikan akun demo berfungsi, belum membuktikan adanya SQL Injection.'],
                ['2. Pastikan password memang diperiksa', 'Keluar dari dashboard, lalu coba username yang sama dengan password yang salah.', "Username: admin_rentan\nPassword: PasswordSalah123", 'Login ditolak karena username dan password tidak cocok. Pada login normal, query rentan tetap membandingkan password.'],
                ['3. Uji perubahan query', 'Keluar jika perlu. Kembali ke login-rentan.php, pilih SATU payload username di bawah, lalu isi password salah dan klik Masuk.', "Username (pilih satu):\nadmin_rentan' -- -\nadmin_rentan' #\n' OR 1=1 LIMIT 1 -- -\n' OR 'a'='a' -- -\nPassword: PasswordSalah123", 'Dashboard lab terbuka walau password salah. Apostrof mengubah query; -- atau # membuat database mengabaikan sisa query, termasuk pemeriksaan password. Username admin_rentan tersedia pada data demo. Gunakan payload hanya di lab localhost ini.'],
            ],
            'secure_instruction' => 'Buka login-aman.php. Uji payload yang sama satu per satu, gunakan password salah, lalu klik Masuk. Setelah itu coba akun aman yang benar sebagai pembanding.',
            'secure_input' => "Uji payload (pilih satu):\nadmin_rentan' -- -\nadmin_rentan' #\n' OR 1=1 LIMIT 1 -- -\n' OR 'a'='a' -- -\nPassword: PasswordSalah123\n\nPembanding login normal:\nUsername: admin_aman\nPassword: RasaAman!2026",
            'secure_result' => 'Semua payload ditolak dan dashboard tidak terbuka. Prepared statement memperlakukan payload sebagai teks username, bukan potongan SQL. Akun admin_aman dengan password yang benar tetap bisa masuk. Password akun aman disimpan sebagai hash bcrypt.',
            'fix' => 'Gunakan PDO prepare() dan execute() di login-aman.php. Jangan menyambungkan input langsung ke SQL.',
            'link' => 'login-rentan.php',
        ],
        [
            'title' => 'XSS',
            'definition' => 'Teks dari database dibaca browser sebagai HTML atau JavaScript karena ditampilkan tanpa output encoding.',
            'impact' => 'Skrip dari isi produk berjalan di browser pengguna yang membuka halaman tersebut.',
            'steps' => [
                ['Masuk ke pengelolaan menu', 'Buka login-rentan.php, ketik akun berikut, lalu masuk ke dashboard.', "Username: admin_rentan\nPassword: RasaRentan!2026", 'Login berhasil. Lanjutkan ke formulir Tambah sajian baru.'],
                ['Isi produk untuk pengujian', 'Ketik input berikut pada formulir produk. Kosongkan URL gambar, lalu klik Tambahkan ke menu.', "Nama produk: Menu Pengujian XSS\nKategori: Makanan\nHarga: 15000\nDeskripsi: <script>alert(123)</script>\nURL gambar: kosongkan", 'Muncul dialog browser berisi 123 ketika daftar produk rentan dirender. Skrip tersimpan dalam database; ini disebut stored XSS.'],
                ['Bandingkan hasil render dan bersihkan', 'Tutup dialog, lalu kembali ke dashboard rentan, edit produk pengujian, dan ganti deskripsinya. Tabel lab terpisah dari katalog publik aman.', 'Deskripsi pengganti: Sajian hangat dengan bumbu Nusantara.', 'Setelah deskripsi diganti, dialog tidak muncul lagi. Dialog 123 adalah efek input uji, bukan notifikasi toko.'],
            ],
            'secure_input' => 'Deskripsi: <script>alert(123)</script>',
            'secure_result' => 'Pada dashboard-aman.php dan katalog publik, karakter HTML ditampilkan sebagai teks. Dialog 123 tidak berjalan. Login akun aman diperlukan untuk membuka dashboard aman.',
            'fix' => 'Gunakan h() / htmlspecialchars() saat menampilkan nama dan deskripsi. Menyimpan teks asli tidak berarti boleh merendernya sebagai HTML mentah.',
            'link' => 'dashboard-rentan.php',
        ],
        [
            'title' => 'Broken Authentication',
            'definition' => 'Password dan identitas sesi tidak dilindungi dengan memadai, walaupun proses login terlihat berfungsi.',
            'impact' => 'Password yang bocor dapat langsung dibaca dan ID sesi yang tidak diperbarui memperbesar risiko penyalahgunaan sesi.',
            'steps' => [
                ['Catat sesi sebelum masuk', 'Buka login-rentan.php. Tekan F12, buka Application → Cookies → localhost. Catat nilai cookie RN_VULNERABLE, kemudian ketik akun ini pada formulir login.', "Username: admin_rentan\nPassword: RasaRentan!2026", 'Login berhasil. Keberhasilan ini adalah alur normal; pembuktian celah dilakukan dengan memeriksa penyimpanan password dan sesi.'],
                ['Periksa sesi setelah masuk', 'Bandingkan nilai cookie setelah login dengan catatan sebelum login. Jangan hanya membandingkan cookie RN_SECURE dengan RN_VULNERABLE.', 'Cookie yang diperiksa: RN_VULNERABLE', 'ID sesi rentan tetap sama setelah login. Cookie ini juga tidak diberi atribut HttpOnly oleh aplikasi.'],
                ['Periksa penyimpanan password', 'Buka phpMyAdmin → rasanusantara → tabel lab_users. Temukan baris admin_rentan dan lihat kolom password.', 'Username pada tabel lab_users: admin_rentan', 'Password terlihat langsung sebagai RasaRentan!2026. Jika tabel lab bocor, nilai tersebut langsung dapat dibaca tanpa proses verifikasi hash.'],
            ],
            'secure_input' => "Username: admin_aman\nPassword: RasaAman!2026\nCookie pembanding: RN_SECURE",
            'secure_result' => 'Muat login-aman.php sebelum mencatat cookie. Setelah login aman berhasil, ID RN_SECURE berubah. Cookie memiliki HttpOnly, dan password akun aman di database berupa hash bcrypt yang diawali $2y$.',
            'fix' => 'Gunakan password_hash(), password_verify(), session_regenerate_id(true), serta pengaturan cookie dan strict mode di versi aman.',
            'link' => 'login-rentan.php',
        ],
        [
            'title' => 'CSRF',
            'definition' => 'Permintaan perubahan data tidak dibuktikan berasal dari formulir pengguna yang sah melalui token yang terikat ke sesi.',
            'impact' => 'Browser yang masih login berpotensi dipicu mengubah data tanpa persetujuan pengguna.',
            'steps' => [
                ['Masuk ke dashboard rentan', 'Buka login-rentan.php lalu gunakan akun berikut.', "Username: admin_rentan\nPassword: RasaRentan!2026", 'Dashboard terbuka dan formulir produk dapat digunakan.'],
                ['Kirim formulir tanpa token', 'Periksa formulir Tambah sajian baru melalui F12 → Elements. Tidak ada input bernama csrf. Ketik isian berikut lalu simpan.', "Nama produk: Es Teh Serai\nKategori: Minuman\nHarga: 12000\nDeskripsi: Teh dingin dengan aroma serai.\nURL gambar: kosongkan", 'Produk tetap ditambahkan meskipun permintaan tidak membawa token CSRF. Ini membuktikan tidak adanya validasi token, belum menjadi demonstrasi serangan lintas situs penuh.'],
                ['Periksa perbedaan di versi aman', 'Login di login-aman.php menggunakan akun pembanding di bawah. Isi formulir produk, lalu lewat F12 → Elements ubah nilai hidden input name="csrf" sebelum mengirim.', 'Nilai csrf pengganti: token-salah', 'Versi aman menolak perubahan dan menampilkan pesan form kedaluwarsa atau tidak sah. Muat ulang dashboard untuk memperoleh token yang benar.'],
            ],
            'secure_input' => "Username: admin_aman\nPassword: RasaAman!2026\nNilai csrf untuk pengujian: token-salah",
            'secure_result' => 'Produk tidak ditambahkan ketika token tidak cocok. Kegagalan request lintas situs tertentu pada browser modern dapat berasal dari SameSite; hal itu tidak menggantikan validasi token di server.',
            'fix' => 'Gunakan POST untuk perubahan data dan periksa token acak menggunakan csrf_ok() / hash_equals(). Konfirmasi SweetAlert2 bukan perlindungan CSRF di server.',
            'link' => 'dashboard-rentan.php',
        ],
        [
            'title' => 'IDOR / Broken Access Control',
            'definition' => 'Server mempercayai ID produk tanpa memeriksa apakah akun yang meminta adalah pemilik produk tersebut.',
            'impact' => 'Pengguna dapat mengubah atau menghapus produk milik pengguna lain.',
            'steps' => [
                ['Masuk sebagai pengguna ID 3', 'Login pada versi rentan menggunakan akun berikut. Pada data awal, akun ini memiliki user ID 3.', "Username: admin_rentan\nPassword: RasaRentan!2026", 'Dashboard terbuka sebagai admin_rentan. Produk lab ID 6 dimiliki pelanggan_rentan / owner ID 4, bukan akun ini.'],
                ['Buka produk pemilik lain', 'Tambahkan path berikut setelah alamat folder proyek di browser. Bila ID berubah, pilih ID milik pengguna lab lain dari daftar.', 'dashboard-rentan.php?action=edit&id=6', 'Form edit terbuka walaupun owner produk tidak sama dengan ID akun yang sedang login.'],
                ['Simpan perubahan', 'Ubah nama produk lalu klik Simpan perubahan. Catat nama awal agar dapat dikembalikan setelah pengujian.', 'Nama produk: Teh Lemon Serai Uji', 'Perubahan berhasil tersimpan pada produk lab milik pengguna lain. Cek owner di lab_products: kepemilikan tetap ID 4.'],
            ],
            'secure_input' => "Username: pelanggan_aman\nPassword: RasaAman!2026\nAlamat pembanding: dashboard-aman.php?action=edit&id=1",
            'secure_result' => 'Customer diarahkan ke dashboard pesanannya dan tidak dapat membuka pengelolaan menu admin, termasuk saat mengetik URL edit langsung. Admin dapat mengelola semua menu.',
            'fix' => 'Periksa role pada server sebelum menjalankan aksi admin. Customer hanya dapat membaca pesanan dengan user_id miliknya.',
            'link' => 'dashboard-rentan.php',
        ],
        [
            'title' => 'Unrestricted File Upload',
            'definition' => 'Server menerima berkas dari pengguna tanpa memvalidasi ekstensi, tipe MIME, isi berkas, maupun nama berkas.',
            'impact' => 'Penyerang dapat mengunggah skrip berbahaya (misal berkas .php) yang dapat dieksekusi di server (Remote Code Execution / RCE) atau menimpa berkas sistem via Path Traversal.',
            'steps' => [
                ['Masuk ke dashboard rentan', 'Buka login-rentan.php dan masuk menggunakan akun rentan.', "Username: admin_rentan\nPassword: RasaRentan!2026", 'Dashboard terbuka dan formulir produk siap digunakan.'],
                ['Pilih berkas non-gambar atau skrip', 'Pada bagian "Upload berkas gambar", pilih berkas dengan ekstensi selain gambar, misalnya info.php atau script pengujian.', 'Berkas uji: info.php atau file teks biasa', 'Antarmuka review memperlihatkan berkas terdeteksi. Formulir rentan mengizinkan pemilihan berkas apapun tanpa batasan atribut accept.'],
                ['Simpan produk ke katalog', 'Isi nama dan harga, lalu klik "+ Tambahkan ke menu".', 'Klik tombol simpan', 'Berkas langsung tersimpan ke folder uploads/ dengan nama aslinya tanpa diacak dan tanpa penolakan ekstensi.'],
            ],
            'secure_input' => "Coba unggah berkas .php atau berkas > 2MB di dashboard-aman.php",
            'secure_result' => 'Pada dashboard-aman.php, sistem menolak berkas non-gambar baik di sisi klien (accept) maupun di server (whitelist ekstensi, finfo_file MIME check, getimagesize). Nama berkas yang lolos pun diacak demi mencegah Path Traversal.',
            'fix' => 'Validasi ekstensi dengan whitelist ketat (jpg/png/webp/gif), verifikasi MIME type asli (finfo) & getimagesize(), batasi ukuran (maks 2MB), dan acak nama berkas dengan random_bytes().',
            'link' => 'dashboard-rentan.php',
        ],
    ];
    if ($page === 'login') {
        $sqlLesson = $lessons[0];
        $sqlLesson['definition'] = 'Kita mencoba memasukkan kode SQL ke kolom username untuk melihat apakah login bisa dilewati.';
        $sqlLesson['impact'] = 'Pada login rentan, kode SQL dapat membuat password salah tetap masuk. Pada login aman, input itu ditolak.';
        $sqlLesson['steps'] = [
            ['1. Login biasa', 'Masukkan akun demo di login-rentan.php.', "Username: admin_rentan\nPassword: RasaRentan!2026", 'Dashboard terbuka karena password benar.'],
            ['2. Password salah', 'Keluar, lalu masukkan password yang salah.', "Username: admin_rentan\nPassword: PasswordSalah123", 'Login ditolak. Artinya password biasanya tetap diperiksa.'],
            ['3. Masukkan contoh SQL Injection', 'Kembali ke login rentan. Pilih satu username di bawah dan isi password salah.', "Username (pilih satu):\nadmin_rentan' -- -\nadmin_rentan' #\n' OR 1=1 LIMIT 1 -- -\n' OR 'a'='a' -- -\nPassword: PasswordSalah123", 'Dashboard terbuka walaupun password salah. Tanda komentar SQL membuat pemeriksaan password dilewati.'],
        ];
        $sqlLesson['secure_instruction'] = 'Di login-aman.php, masukkan salah satu contoh username SQL Injection berikut dengan password yang salah. Lalu coba akun demo yang benar.';
        $sqlLesson['secure_input'] = "Username (pilih satu):\nadmin_rentan' -- -\nadmin_rentan' #\n' OR 1=1 LIMIT 1 -- -\nPassword: PasswordSalah123\n\nAkun demo yang benar:\nUsername: admin_aman\nPassword: RasaAman!2026";
        $sqlLesson['secure_result'] = 'Contoh SQL Injection ditolak. Akun demo dengan password yang benar tetap bisa masuk.';
        $sqlLesson['fix'] = 'Username diperlakukan sebagai teks biasa oleh prepared statement; password diperiksa dengan password_verify().';
        $lessons = [
            $sqlLesson,
            [
                'title' => 'Brute Force Manual',
                'button_title' => 'Uji Brute Force Manual',
                'definition' => 'Kita mencoba password yang salah lima kali pada username yang sama.',
                'impact' => 'Mode rentan tidak membatasi percobaan. Mode aman mengunci login selama 1 menit.',
                'steps' => [
                    ['1. Coba password salah', 'Buka login-rentan.php dan masukkan username demo dengan password yang salah.', "Username: admin_rentan\nPassword: PasswordSalah123", 'Login ditolak karena password tidak cocok.'],
                    ['2. Ulangi pada akun yang sama', 'Kirim isian salah yang sama minimal lima kali. Tutup notifikasi sebelum mengirim lagi.', "Username: admin_rentan\nPassword: PasswordSalah123", 'Setiap percobaan tetap diproses dan ditolak sebagai password salah. Mode rentan tidak menghitung atau mengunci percobaan login.'],
                    ['3. Periksa akun yang benar', 'Masukkan password demo yang benar setelah percobaan salah tadi.', "Username: admin_rentan\nPassword: RasaRentan!2026", 'Dashboard tetap terbuka; tidak ada masa tunggu atau penguncian akun pada mode rentan.'],
                ],
                'secure_instruction' => 'Di login-aman.php, masukkan password salah lima kali. Username boleh berbeda pada setiap percobaan. Lihat hitung mundur, lalu coba akun admin_aman yang benar saat masih terkunci dan setelah waktu habis.',
                'secure_input' => "Percobaan 1–4:\nUsername: uji_salah_1 hingga uji_salah_4\nPassword: PasswordSalah123\n\nPercobaan 5:\nUsername: admin_aman\nPassword: PasswordSalah123\n\nSaat terkunci:\nUsername: admin_aman\nPassword: RasaAman!2026",
                'secure_result' => 'Setelah lima kali gagal, muncul hitung mundur 1 menit. Password benar tetap ditolak selama terkunci. Setelah waktu habis, password benar bisa masuk.',
                'fix' => 'Jumlah login gagal dicatat untuk lab localhost. Setelah lima kali gagal, server menolak semua username sampai satu menit berlalu.',
                'link' => 'login-rentan.php',
            ],
            [
                'title' => 'Session Handling',
                'button_title' => 'Uji Session Handling',
                'definition' => 'Sesi adalah tanda bahwa pengguna sudah login. Kita cek apakah dashboard masih dapat dibuka setelah menekan Keluar.',
                'impact' => 'Mode rentan tidak menghapus sesi saat logout. Mode aman langsung menghapus sesi.',
                'steps' => [
                    ['1. Masuk dan buka dashboard', 'Login di mode rentan memakai akun demo.', "Username: admin_rentan\nPassword: RasaRentan!2026", 'Dashboard rentan terbuka.'],
                    ['2. Keluar, lalu kembali', 'Klik Keluar. Selama hitung mundur 1 menit di header masih berjalan, tekan Back atau buka dashboard-rentan.php lagi, lalu refresh.', 'Tombol Keluar → Back → Refresh', 'Dashboard masih terbuka selama 1 menit karena logout rentan hanya mengalihkan halaman tanpa menghapus sesi. Setelah hitung mundur habis, dashboard meminta login lagi.'],
                    ['3. Bandingkan dengan mode aman', 'Login di mode aman, klik Keluar, lalu tekan Back dan refresh dashboard.', 'login-aman.php → Keluar → Back → Refresh', 'Dashboard aman langsung meminta login lagi karena sesi dihancurkan saat logout.'],
                ],
                'secure_instruction' => 'Login di mode aman, klik Keluar, lalu tekan Back dan refresh dashboard.',
                'secure_input' => "Username: admin_aman\nPassword: RasaAman!2026\nTindakan: Keluar → Back → Refresh\nCookie: RN_SECURE",
                'secure_result' => 'Dashboard langsung meminta login lagi karena sesi sudah dihancurkan saat logout.',
                'fix' => 'Server mengganti ID sesi saat login, memeriksa sesi di dashboard, dan menghapus sesi saat logout.',
                'link' => 'login-rentan.php',
            ],
        ];
    }
    $isSecure = ($mode === 'aman');
    $badgeClass = $isSecure ? 'badge safe' : 'badge danger';
    $badgeText = $page === 'login'
        ? ($isSecure ? '◈ MODE AMAN • PANDUAN UJI' : '⚠ MODE RENTAN • PANDUAN UJI')
        : ($isSecure ? '◈ MODE AMAN • PANDUAN PENGUJIAN' : '⚠ MODE RENTAN • PENANDA EDUKASI');
    $captionText = $isSecure ? 'Buka panduan pengujian versi aman' : 'Buka panduan pengujian';
    $introText = $page === 'login'
        ? 'Pilih salah satu dari tiga uji di bawah. Ikuti langkahnya, lalu cocokkan hasil yang muncul dengan hasil yang diharapkan.'
        : ($isSecure
            ? 'Pilih topik untuk melihat mekanisme pertahanan keamanan pada versi aman, input pengujian untuk membuktikannya, dan implementasi kode perbaikannya.'
            : 'Pilih topik untuk melihat langkah, input yang diketik, dan hasil pembuktian celah pada versi rentan. Untuk pembanding versi aman, silakan buka panduan di halaman versi aman.');
    ?>
<?php if ($embedded): ?>
<div class="education embedded-guide <?= $isSecure ? 'secure' : '' ?>" id="security-guide-<?= h($mode) ?>">
<?php else: ?>
<details class="education <?= $isSecure ? 'secure' : '' ?>" id="security-guide-<?= h($mode) ?>">
    <summary class="education-heading">
        <span class="<?= $badgeClass ?>"><?= $badgeText ?></span>
        <span class="education-caption"><?= $captionText ?> <span aria-hidden="true">⌄</span></span>
    </summary>
<?php endif; ?>
    <div class="guide-body">
        <?php if ($embedded): ?><div class="education-heading"><span class="<?= $badgeClass ?>"><?= $badgeText ?></span></div><?php endif; ?>
        <p class="guide-intro"><?= h($introText) ?></p>
        <div class="lesson-grid" aria-label="Topik pengujian keamanan">
            <?php foreach ($lessons as $i => $lesson): ?>
            <button class="lesson-toggle" type="button" id="lesson-button-<?= $mode ?>-<?= $i ?>" aria-expanded="false" aria-controls="lesson-<?= $mode ?>-<?= $i ?>">
                <span class="lesson-name"><?= h($lesson['button_title'] ?? $lesson['title']) ?></span><span class="lesson-sign" aria-hidden="true">+</span>
            </button>
            <?php $link = $isSecure ? str_replace('-rentan.php', '-aman.php', $lesson['link']) : $lesson['link']; ?>
        <section class="lesson-content" id="lesson-<?= $mode ?>-<?= $i ?>" aria-labelledby="lesson-button-<?= $mode ?>-<?= $i ?>" hidden>
            <div class="lesson-overview">
                <div>
                    <span class="eyebrow"><?= $page === 'login' ? ($isSecure ? 'UJI LOGIN AMAN' : 'UJI LOGIN RENTAN') : ($isSecure ? 'MEKANISME KEAMANAN' : 'PAHAMI CELAHNYA') ?></span>
                    <h3><?= h($lesson['title']) ?></h3>
                    <p><?= h($lesson['definition']) ?></p>
                    <p><b><?= $page === 'login' ? 'Yang perlu diperhatikan:' : ($isSecure ? 'Dampak yang dicegah:' : 'Dampak:') ?></b> <?= h($lesson['impact']) ?></p>
                </div>
                <a class="btn small ghost" href="<?= h($link) ?>">Buka halaman terkait ↗</a>
            </div>

            <?php if ($isSecure): ?>
            <div class="test-steps" style="grid-template-columns:1fr">
                <div class="test-step">
                    <h4 style="color:var(--teal)"><?= $page === 'login' ? 'Langkah uji' : 'Pengujian Ketahanan pada Versi Aman' ?></h4>
                    <p><?= h($lesson['secure_instruction'] ?? 'Ketik input pengujian di bawah ini pada formulir versi aman:') ?></p>
                    <div class="test-input">
                        <span class="test-input-label"><?= $page === 'login' ? 'Ketik / periksa' : 'Input pengujian versi aman' ?></span>
                        <?php guide_copy_lines($lesson['secure_input']); ?>
                    </div>
                    <div class="test-result safe" style="border-left:2px solid var(--teal);padding-left:12px">
                        <span class="badge safe" style="font-size:8px;margin-bottom:6px">HASIL YANG DIHARAPKAN</span>
                        <p><?= h($lesson['secure_result']) ?></p>
                    </div>
                </div>
            </div>
            <div class="secure-comparison">
                <span class="badge safe"><?= $page === 'login' ? '◈ MENGAPA AMAN' : '◈ IMPLEMENTASI KODE AMAN' ?></span>
                <p><b><?= $page === 'login' ? 'Penjelasan singkat:' : 'Perbaikan kode:' ?></b> <?= h($lesson['fix']) ?></p>
            </div>
            <?php else: ?>
            <ol class="test-steps">
                <?php foreach ($lesson['steps'] as $step): ?>
                <li class="test-step">
                    <h4><?= h($step[0]) ?></h4><p><?= h($step[1]) ?></p>
                    <div class="test-input"><span class="test-input-label">Ketik / periksa</span><?php guide_copy_lines($step[2]); ?></div>
                    <div class="test-result"><b>Hasil yang diharapkan</b><p><?= h($step[3]) ?></p></div>
                </li>
                <?php endforeach; ?>
            </ol>
            <p class="guide-cleanup"><?= $page === 'login' ? 'Untuk membandingkan hasilnya, lakukan uji yang sama di login aman.' : 'Sesudah pengujian, kembalikan perubahan jika ada. Untuk melihat pembanding dan implementasi kode amannya, buka panduan pengujian di versi aman.' ?></p>
            <?php endif; ?>
        </section>
        <?php endforeach; ?>
        </div>
    </div>
<?php if ($embedded): ?></div><?php else: ?></details><?php endif; ?>
<?php
}

function page_bottom(?array $notice = null): void {
    if ($notice === null && isset($_SESSION['flash'])) { $notice = $_SESSION['flash']; unset($_SESSION['flash']); }
    ?>
<?php if ($notice): ?><div class="server-notice" role="alert"><strong><?= h($notice['title'] ?? '') ?></strong><span><?= h($notice['text'] ?? '') ?></span></div><?php endif; ?>
</main>
<footer class="site-footer">
<a class="footer-brand" href="index.php"><img src="assets/kawan-santap-logo.svg" alt="" width="34" height="34"> Kawan Santap</a>
<p>Rasa lokal, pengalaman digital. <span>Temukan sajian favoritmu.</span>
</p>
<span class="footer-meta">MAKANAN • MINUMAN • NUSANTARA</span>
</footer>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11">
</script>
<script>
    // Semua notifikasi dan konfirmasi memakai SweetAlert2, bukan alert()/confirm().
    const notice = <?= json_encode($notice, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE) ?>;
    if(window.Swal){
      window.neonAlert = Swal.mixin({background:'#fff',color:'#291e20',confirmButtonColor:'#d92747',cancelButtonColor:'#746669',customClass:{popup:'neon-popup',confirmButton:'neon-confirm'},buttonsStyling:true});
      if(notice){document.querySelector('.server-notice')?.setAttribute('hidden','');neonAlert.fire(notice);}
    }
    document.querySelectorAll('.file-picker input[type="file"]').forEach(input => {
      const name = input.closest('.file-picker').querySelector('[data-file-name]');
      input.addEventListener('change', () => { name.textContent = input.files?.[0]?.name || 'Belum ada berkas dipilih'; });
    });
    const rentanTimer = document.querySelector('[data-rentan-remaining]');
    if (rentanTimer) {
      const countdown = rentanTimer.querySelector('[data-rentan-countdown]');
      const deadline = performance.now() + Number(rentanTimer.dataset.rentanRemaining) * 1000;
      let finished = false;
      const updateRentanTimer = () => {
        const remaining = Math.max(0, Math.ceil((deadline - performance.now()) / 1000));
        countdown.textContent = String(Math.floor(remaining / 60)).padStart(2, '0') + ':' + String(remaining % 60).padStart(2, '0');
        if (remaining === 0 && !finished) {
          finished = true;
          rentanTimer.textContent = 'Jendela uji sesi lama sudah berakhir';
          if (location.pathname.endsWith('/dashboard-rentan.php')) location.reload();
        }
      };
      updateRentanTimer();
      setInterval(updateRentanTimer, 1000);
      window.addEventListener('pageshow', updateRentanTimer);
    }
    // Saat tombol Back memulihkan dashboard lama dari cache, muat ulang agar status sesi dan timer berasal dari server.
    if (location.pathname.endsWith('/dashboard-rentan.php')) {
      window.addEventListener('pageshow', event => { if (event.persisted) location.reload(); });
    }
    // Satu panduan dibuka pada satu waktu; contoh kode tetap teks, bukan dieksekusi.
    document.querySelectorAll('.lesson-toggle').forEach(button => {
      button.addEventListener('click', () => {
        const wasOpen = button.getAttribute('aria-expanded') === 'true';
        document.querySelectorAll('.lesson-toggle').forEach(other => {
          other.setAttribute('aria-expanded', 'false');
          other.querySelector('.lesson-sign').textContent = '+';
          document.getElementById(other.getAttribute('aria-controls')).hidden = true;
        });
        if (!wasOpen) {
          button.setAttribute('aria-expanded', 'true');
          button.querySelector('.lesson-sign').textContent = '−';
          document.getElementById(button.getAttribute('aria-controls')).hidden = false;
        }
      });
    });
    document.querySelectorAll('.guide-copy-line').forEach(button => button.addEventListener('click', async () => {
      const value = button.dataset.copy;
      try {
        if (navigator.clipboard && window.isSecureContext) {
          await navigator.clipboard.writeText(value);
        } else {
          const field = document.createElement('textarea');
          field.value = value;
          field.style.position = 'fixed';
          field.style.opacity = '0';
          document.body.appendChild(field);
          field.select();
          if (!document.execCommand('copy')) throw new Error('Clipboard tidak tersedia');
          field.remove();
        }
        button.classList.add('is-copied');
        button.querySelector('i')?.classList.replace('fa-copy', 'fa-check');
        setTimeout(() => {
          button.classList.remove('is-copied');
          button.querySelector('i')?.classList.replace('fa-check', 'fa-copy');
        }, 1600);
      } catch (error) {
        if (window.neonAlert) neonAlert.fire({icon:'error',title:'Gagal menyalin',text:'Periksa izin clipboard browser lalu coba lagi.'});
      }
    }));
    document.querySelectorAll('img').forEach(img=>{img.addEventListener('error',()=>{img.hidden=true;});if(img.complete && img.naturalWidth===0)img.hidden=true;});
    document.querySelectorAll('[data-password-toggle]').forEach(button=>button.addEventListener('click',()=>{const input=document.getElementById(button.dataset.passwordToggle);input.type=input.type==='password'?'text':'password';button.textContent=input.type==='password'?'Lihat':'Sembunyikan';button.setAttribute('aria-pressed',String(input.type==='text'));}));
    document.querySelectorAll('[data-delete-form]').forEach(form=>form.addEventListener('submit',async event=>{if(!window.neonAlert)return;event.preventDefault();const answer=await neonAlert.fire({icon:'warning',title:'Hapus produk ini?',text:'Produk akan dihapus dari katalog.',showCancelButton:true,confirmButtonText:'Ya, hapus',cancelButtonText:'Batal'});if(answer.isConfirmed)form.submit();}));
    document.querySelectorAll('[data-delete-link]').forEach(link=>link.addEventListener('click',async event=>{if(!window.neonAlert)return;event.preventDefault();const answer=await neonAlert.fire({icon:'warning',title:'Hapus produk ini?',text:'Produk ini akan dihapus dari katalog.',showCancelButton:true,confirmButtonText:'Ya, hapus',cancelButtonText:'Batal'});if(answer.isConfirmed)location.href=link.href;}));
    // Validasi browser bawaan dimatikan agar pesan konsisten, server tetap otoritatif.
    document.querySelectorAll('form[data-validate]').forEach(form=>{form.noValidate=true;form.addEventListener('submit',event=>{if(!form.checkValidity()){event.preventDefault();const bad=form.querySelector(':invalid');bad?.focus();if(window.neonAlert)neonAlert.fire({icon:'warning',title:'Periksa isian formulir',text:bad?.validationMessage || 'Lengkapi isian terlebih dahulu.'});}});});
    </script>
<p id="cdn-status" class="cdn-status" hidden>SweetAlert2 belum dimuat. Hubungkan internet dan muat ulang untuk konfirmasi hapus.</p>
<noscript>
<p class="cdn-status">Aktifkan JavaScript agar penjelasan edukasi dan SweetAlert2 dapat digunakan.</p>
</noscript>
</body>
</html>
<?php
}
