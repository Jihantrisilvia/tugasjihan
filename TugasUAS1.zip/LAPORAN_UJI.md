# Laporan uji keamanan Kawan Santap

Kawan Santap adalah lab PHP native dan MySQL di localhost. `index.php` menampilkan katalog; halaman login dan registrasi tersedia untuk mode aman dan rentan. Pada mode aman, admin mengelola produk dan memverifikasi pesanan; customer melihat pesanannya sendiri. Pengunjung dapat checkout tanpa akun. `logout-aman.php` mengakhiri sesi langsung; `logout-rentan.php` hanya mengalihkan halaman tanpa menghapus sesi. Checkout mencatat pesanan simulasi di database, tanpa pembayaran atau pengiriman sungguhan. Mode aman memakai `users`, `products`, `orders`, `order_items`, `login_attempts`, dan sesi `RN_SECURE`. Mode rentan memakai `lab_users`, `lab_products`, dan sesi `RN_VULNERABLE`.

Folder root adalah versi yang diuji. `Komtes/` adalah salinan lama tanpa halaman registrasi dan checkout; folder itu tidak dipakai dan tidak diubah. Inventarisasi dilakukan pada file PHP dan CSS. Skema tabel dipastikan lewat query MySQL karena pengujian perlu membedakan tabel aman dan lab; file Markdown/SQL lama tidak diperlukan untuk pelaksanaan uji.

## Tiga fitur keamanan inti

| Fitur | Mode aman | Pembanding rentan |
|---|---|---|
| Pencegahan SQL Injection | `login-aman.php:25` memakai `prepare()` dan `execute()`; input divalidasi dan output HTML di-escape melalui `h()` pada `config.php:74`. | `login-rentan.php:13` menggabungkan username dan password langsung ke SQL pada `lab_users`. |
| Hash password | `register-aman.php:33` memakai `password_hash(..., PASSWORD_BCRYPT)` dan `login-aman.php:31` memakai `password_verify()`. | `register-rentan.php:18` menyimpan password teks biasa dan login membandingkannya langsung. |
| Sesi dan pembatasan login gagal | `config.php` menetapkan strict mode, HttpOnly, SameSite, batas tidak aktif 15 menit, dan pemeriksaan sesi. `login-aman.php` mengunci login seluruh username di lab localhost yang sama selama 1 menit setelah lima kegagalan, menampilkan hitung mundur, dan mengganti ID sesi saat login. Logout aman langsung menghancurkan sesi dan cookie. | `RN_VULNERABLE` tanpa HttpOnly/rotasi ID/timeout aktivitas biasa dan tanpa pembatasan gagal. Logout rentan hanya mengarahkan ke login; sesi lama masih dapat dipakai selama jendela demonstrasi 1 menit. |

CSRF, pemeriksaan role admin/customer, pembatasan akses pesanan customer berdasarkan `user_id`, encoding HTML, dan validasi upload adalah perlindungan tambahan di mode aman.

## Pemetaan referensi Session Handling

| Kelemahan pada referensi | Implementasi mode rentan | Pembanding mode aman |
|---|---|---|
| Cookie tanpa HttpOnly dan Secure | `start_lab_session('rentan')` di `config.php` menetapkan keduanya `false`. | HttpOnly aktif; Secure aktif ketika situs dibuka lewat HTTPS. Di localhost HTTP, atribut Secure belum aktif. |
| Query login digabung langsung | `login-rentan.php` menyambung input username dan password ke SQL. | `login-aman.php` memakai prepared statement. |
| ID sesi tidak diganti setelah login | `login-rentan.php` menyimpan identitas tanpa `session_regenerate_id()`. | Login aman memanggil `session_regenerate_id(true)`. |
| Tidak ada pencatatan aktivitas terakhir | Sesi rentan tidak memakai `last_active` atau timeout aplikasi. | Sesi aman mencatat `last_active` dan menolak sesi setelah 15 menit tidak aktif. |
| Logout hanya mengalihkan halaman | `logout-rentan.php` tidak memanggil `session_unset()` atau `session_destroy()`. | `logout-aman.php` menghapus data sesi, cookie, dan sesi server. |
| Dashboard hanya memeriksa ada sesi login | `require_login('rentan')` memeriksa `user_id` tanpa penanda sesi; jendela khusus 1 menit setelah logout dibatasi pada `start_lab_session()`. | `require_login('aman')` juga memeriksa `session_marker` dan batas aktivitas. |

Untuk demonstrasi, login rentan, klik Keluar, lalu buka atau refresh `dashboard-rentan.php` sebelum hitung mundur 1 menit habis: dashboard masih terbuka. Klik Keluar lagi tidak mengulang hitung mundur. Setelah 1 menit, sesi lama dihancurkan dan dashboard kembali meminta login. Ulangi di mode aman: dashboard langsung meminta login. Sesi rentan tetap tidak memiliki timeout aktivitas biasa sebelum logout.

## Hasil uji nyata

Pengujian dijalankan pada PHP 8.2.12 development server `127.0.0.1:8000` dan MySQL lokal, memakai cookie terpisah per mode. Server CLI menggunakan folder sesi sementara yang dapat ditulis karena folder sesi bawaan XAMPP menolak akses proses CLI. Data uji yang dibuat sudah dihapus.

| Skenario | Mode rentan | Mode aman | Bukti singkat |
|---|---|---|---|
| SQL Injection login: username `' OR '1'='1' -- `, password salah | Masuk dashboard. | Tetap di login dengan pesan kredensial tidak valid. | Rentan: POST `303` → `/dashboard-rentan.php`; aman: POST `200` → `/login-aman.php`. Query rentan hanya membaca `lab_users`. |
| Brute force manual | Setelah tujuh login salah, password benar tetap bisa masuk. | Lima username berbeda dengan password salah mengunci login lab lokal; kredensial admin yang benar tetap ditolak selama kunci aktif. Setelah waktu kunci berlalu, login benar diterima. | `login_attempts` mencatat `failed_count=5` dan `locked_until` terisi pada kunci klien. Baris uji dibersihkan. |
| Login, logout, lalu akses/refresh dashboard | Dashboard dapat dibuka kembali karena sesi tidak dihapus. | Langsung kembali ke login. ID sesi berubah saat login; cookie memiliki HttpOnly dan SameSite=Lax. | Logout memakai endpoint berbeda pada tiap mode. |
| Input data/CRUD | Tambah, ubah, hapus produk lab berhasil; tabel `products` aman tidak berubah. | Admin mengelola seluruh menu dengan CSRF. Customer dialihkan ke dashboard pesanan dan tidak memiliki akses CRUD produk. | Produk uji terbaca dari tabel masing-masing, lalu jumlahnya kembali nol setelah dihapus. |
| Registrasi | Akun uji tersimpan di `lab_users` dengan password teks biasa. | Akun uji tersimpan di `users` dengan hash bcrypt `$2y$`. Form `register-aman.php` dapat memilih role untuk lab; form `register-customer.php` selalu menyimpan customer. | Akun uji dibersihkan setelah pengujian. |
| Notifikasi | `flash()` menghasilkan data notice dan elemen HTML cadangan. | Sama; kesalahan registrasi dan akun terkunci menghasilkan notice. | Kode `page_bottom()` kembali memanggil `neonAlert.fire(notice)` bila SweetAlert2 tersedia. Tampilan popup belum diperiksa secara visual. |

## Alur pesanan dan role setelah pembaruan

- Pengunjung dapat mengirim pesanan dengan nama, alamat, nomor WhatsApp, metode pembayaran, dan bukti untuk QRIS/transfer. Tombol lokasi mengisi koordinat jika browser memberi izin; alamat tetap wajib.
- Pesanan dan rincian item tersimpan pada `orders` dan `order_items` dengan status `pending`. Harga dihitung ulang dari database. Saat pesanan masuk, stok produk belum berubah; katalog menampilkan stok tersisa dan jumlah porsi yang menunggu verifikasi secara terpisah.
- Hanya admin mode aman dapat mengonfirmasi atau menolak pesanan. Konfirmasi mengurangi stok secara transaksional jika cukup; penolakan tidak mengurangi stok. Bukti pembayaran hanya dapat dibuka melalui `proof.php` oleh admin.
- Registrasi dari checkout selalu membuat customer, termasuk jika POST menyisipkan `role=admin`. Registrasi lab aman menyediakan pilihan role untuk uji lokal. Customer yang membuka dashboard admin dialihkan ke dashboard customer; riwayat customer dibatasi dengan `orders.user_id` miliknya. Checkout pengunjung tidak membutuhkan akun, tetapi nomor pesanannya harus disimpan sendiri karena tidak terhubung ke akun.
- Mode rentan beserta login, dashboard, dan logout lab tetap tersedia sebagai pembanding keamanan. Alur checkout memakai tabel mode aman.

## Penyebab dan pencegahan

**SQL Injection.** Query gabungan membuat input menjadi bagian dari sintaks SQL:

```php
// Rentan, hanya pada lab_users
$sql = "SELECT ... FROM lab_users WHERE username = '" . $username . "' ...";
// Aman
$statement = $pdo->prepare('SELECT ... FROM users WHERE username = ? LIMIT 1');
$statement->execute([$username]);
```

**Password.** Penyimpanan teks biasa langsung memperlihatkan password saat tabel bocor. Mode aman menyimpan `password_hash($password, PASSWORD_BCRYPT)` dan memeriksa dengan `password_verify($password, $hash)`.

**Sesi dan percobaan gagal.** Mode rentan mempertahankan ID sesi setelah login, tidak membatasi percobaan, dan endpoint logout rentan tidak menghapus sesi. Mode aman memanggil `session_regenerate_id(true)`, memberi cookie HttpOnly/SameSite, memeriksa sesi pada dashboard, mencatat kegagalan pada `login_attempts`, dan menghapus sesi langsung saat logout.

## Perubahan pada tahap ini

| File | Perubahan |
|---|---|
| `config.php` | Mengembalikan popup SweetAlert2 untuk flash; `.server-notice` tetap menjadi cadangan bila CDN/JS tidak tersedia. |
| `login-aman.php` | Pesan terkunci ditampilkan sejak kegagalan kelima. |
| `register-aman.php`, `register-rentan.php` | Kegagalan registrasi kini juga dikirim lewat `flash()` agar notifikasi konsisten. |
| `LAPORAN_UJI.md` | Mencatat audit, bukti uji, penyebab, pencegahan, dan batas pengujian. |

Semua berkas PHP lulus `php -l`. Belum diuji secara visual di browser: popup SweetAlert2, interaksi panel Panduan, serta perilaku tombol Back pada cache browser. Batas sesi tidak aktif 15 menit diperiksa pada kode, tetapi belum diuji dengan menunggu 15 menit. Uji HTTP membuktikan dashboard rentan tetap dapat diakses setelah logout; mode aman langsung menolak akses.
