<?php
require __DIR__ . '/config.php';
start_lab_session('aman');

$error = '';
$username = '';
$email = '';
$role = 'customer';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim(posted('username'));
    $email = trim(posted('email'));
    $password = posted('password');
    $confirmation = posted('password_confirmation');
    $role = posted('role');

    if (!csrf_ok()) {
        $error = 'Form kedaluwarsa. Muat ulang halaman lalu coba lagi.';
    } elseif (!preg_match('/^[A-Za-z0-9_.-]{3,80}$/D', $username)) {
        $error = 'Username harus 3–80 karakter dan hanya boleh berisi huruf, angka, titik, garis bawah, atau tanda hubung.';
    } elseif (strlen($email) > 150 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Masukkan alamat email yang valid, maksimal 150 karakter.';
    } elseif (!in_array($role, ['admin', 'customer'], true)) {
        $error = 'Pilih role admin atau customer.';
    } elseif (strlen($password) < 8 || strlen($password) > 72) {
        $error = 'Password harus berisi 8–72 byte.';
    } elseif ($password !== $confirmation) {
        $error = 'Konfirmasi password belum cocok.';
    } else {
        try {
            $statement = $pdo->prepare('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)');
            $statement->execute([$username, $email, password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]), $role]);
            flash('success', 'Akun dibuat', 'Silakan masuk menggunakan akun barumu.');
            go('login-aman.php');
        } catch (PDOException $e) {
            $error = $e->getCode() === '23000'
                ? 'Username atau email sudah dipakai. Gunakan yang lain.'
                : 'Pendaftaran belum dapat diproses. Coba kembali beberapa saat lagi.';
        }
    }
    if ($error !== '') {
        flash('error', 'Pendaftaran gagal', $error);
        go('register-aman.php');
    }
}

page_top('Daftar akun', 'aman', 'register');
?>
<section class="auth-layout">
  <div class="auth-story">
    <span class="eyebrow">JADI BAGIAN DARI KAWAN SANTAP</span>
    <h1>Rasa baru.<br><span class="gradient-text">Cerita baru.</span></h1>
    <p>Buat akun uji mode aman untuk membandingkan akses admin dan customer.</p>
    <div class="auth-art" aria-hidden="true">
      <span><i class="fa-solid fa-bowl-food"></i></span>
      <span><i class="fa-solid fa-mug-hot"></i></span>
      <span><i class="fa-solid fa-cookie-bite"></i></span>
    </div>
    <ul class="feature-list">
      <li>Role admin dan customer dapat dipilih untuk pengujian</li>
      <li>Password disimpan sebagai hash bcrypt</li>
      <li>Input diperiksa sebelum disimpan</li>
    </ul>
  </div>
  <div class="auth-panel panel">
    <span class="eyebrow">AKUN KAWAN SANTAP</span>
    <h2>Mulai dari sini.</h2>
    <p>Akun lab mode aman. Pilih role yang ingin diuji.</p>
    <?php if ($error !== ''): ?><div class="form-error" role="status"><?= h($error) ?></div><?php endif; ?>
    <form method="post" action="register-aman.php" data-validate>
      <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
      <label class="field"><span>Username</span>
        <input name="username" value="<?= h($username) ?>" autocomplete="username" minlength="3" maxlength="80" pattern="[A-Za-z0-9_.-]+" placeholder="Contoh: dapur_sari" required>
      </label>
      <label class="field"><span>Email</span>
        <input name="email" type="email" value="<?= h($email) ?>" autocomplete="email" maxlength="150" placeholder="nama@email.com" required>
      </label>
      <label class="field"><span>Role untuk pengujian</span><select name="role" required><option value="customer" <?= $role === 'customer' ? 'selected' : '' ?>>Customer</option><option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Admin</option></select></label>
      <label class="field" for="new-password"><span>Password</span></label>
      <div class="field password-wrap">
        <input id="new-password" name="password" type="password" autocomplete="new-password" minlength="8" maxlength="72" placeholder="Minimal 8 karakter" required>
        <button type="button" data-password-toggle="new-password" aria-label="Tampilkan atau sembunyikan password" aria-pressed="false">Lihat</button>
      </div>
      <label class="field" for="confirm-password"><span>Ulangi password</span></label>
      <div class="field password-wrap">
        <input id="confirm-password" name="password_confirmation" type="password" autocomplete="new-password" minlength="8" maxlength="72" placeholder="Ketik ulang password" required>
        <button type="button" data-password-toggle="confirm-password" aria-label="Tampilkan atau sembunyikan konfirmasi password" aria-pressed="false">Lihat</button>
      </div>
      <button class="btn primary full-width" type="submit">Buat akun <span>→</span></button>
    </form>
    <p class="auth-switch">Sudah punya akun? <a href="login-aman.php">Masuk di sini</a></p>
  </div>
</section>
<?php login_test_guide('aman'); page_bottom(); ?>
