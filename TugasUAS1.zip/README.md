# Kawan Santap

Kawan Santap adalah proyek simulasi e-commerce makanan & minuman untuk membandingkan kode PHP aman dan rentan. Khusus localhost milik sendiri. Checkout mencatat pesanan dan bukti pembayaran untuk simulasi; tidak ada pembayaran atau pengiriman sungguhan maupun eksploitasi otomatis.

Nama folder aplikasi dan database tetap `rasanusantara` agar instalasi yang sudah ada tetap dapat digunakan.

## Menjalankan di XAMPP / Laragon

1. Gunakan PHP 8.0+ dengan ekstensi `pdo_mysql`, serta MySQL 5.7+ / MariaDB 10.4+. PHP 8.x direkomendasikan untuk lab ini.
2. Ekstrak folder `rasanusantara` ke `C:\xampp\htdocs\` atau `C:\laragon\www\`.
3. Jalankan **Apache** dan **MySQL**.
4. Buka `http://localhost/phpmyadmin`, pilih **Import**, lalu import `database.sql`. File SQL membuat dan memilih database `rasanusantara` sendiri.
5. Buka `config.php` dan sesuaikan `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS`. Default lokal: `127.0.0.1`, `3306`, `rasanusantara`, `root`, password kosong. Gunakan kredensial instalasimu bila berbeda.
6. Buka **http://localhost/rasanusantara/**. Jangan membuka file PHP dengan klik ganda / `file://`.

Untuk instalasi lama, impor `lab_migration.sql` bila tabel lab belum ada, lalu impor `commerce_migration.sql` satu kali untuk stok dan pesanan. Instalasi baru cukup mengimpor `database.sql`. Pendaftaran dari checkout selalu membuat customer. Halaman `register-aman.php` adalah formulir lab yang dapat memilih role admin/customer untuk pengujian lokal.

Alternatif jika PHP dan MySQL sudah tersedia: dari folder proyek jalankan `php -S 127.0.0.1:8000`, lalu buka `http://localhost:8000/`. Import SQL dan konfigurasi koneksi tetap diperlukan. Server ini hanya untuk lokal.

Lab memeriksa IP koneksi agar hanya loopback yang diizinkan. Gunakan localhost langsung, tanpa reverse proxy, tunnel publik, atau akses IP LAN. Pada PHP development server, folder proyek menjadi document root.

## Akun demo

| Mode | Username | Password | Role | Owner ID |
|---|---|---|---|---|
| Aman | `admin_aman` | `RasaAman!2026` | admin | 1 |
| Aman | `pelanggan_aman` | `RasaAman!2026` | customer | 2 |
| Rentan | `admin_rentan` | `RasaRentan!2026` | admin | 3 |
| Rentan | `pelanggan_rentan` | `RasaRentan!2026` | customer | 4 |

Dua akun aman memakai hash bcrypt; dua akun rentan memakai teks biasa. Sesi bernama `RN_SECURE` dan `RN_VULNERABLE` terpisah. Berpindah mode memakai tautan dan membutuhkan login pada mode tujuan. Logout aman pada `logout-aman.php` langsung mengakhiri sesi; logout rentan pada `logout-rentan.php` mengalihkan halaman dan menyisakan jendela uji sesi lama selama 1 menit dengan hitung mundur di header.

Pada mode aman, admin mengelola seluruh menu, stok, dan verifikasi pesanan. Customer melihat riwayat pesanannya. Pengunjung tetap dapat checkout dengan alamat dan WhatsApp tanpa akun. Mode rentan tetap memakai `lab_users`/`lab_products` dan alur akses lemah untuk pengujian keamanan; katalog publik memakai `products` mode aman.

## Struktur

```text
rasanusantara/
  config.php
  index.php
  login-aman.php
  register-aman.php
  login-customer.php
  register-customer.php
  register-rentan.php
  login-rentan.php
  dashboard-aman.php
  dashboard-customer.php
  dashboard-rentan.php
  checkout.php
  proof.php
  logout-aman.php
  logout-customer.php
  logout-rentan.php
  database.sql
  lab_migration.sql
  commerce_migration.sql
  README.md
  assets/
    style.css
    home.css
    interior.css
```

Tidak ada Composer, framework, npm, atau build tool. Fungsi kecil bersama untuk koneksi, sesi, output encoding, shell halaman, dan notifikasi berada di `config.php`.

## Fitur yang tersedia

- Landing responsif dengan katalog 12 produk dummy, pencarian nama/deskripsi, dan empat filter kategori.
- Katalog dan keranjang menuju checkout tamu atau customer. Alamat dan WhatsApp wajib. Tombol GPS opsional mengisi alamat melalui pencarian koordinat dan menandai sumbernya; pengguna perlu memeriksa nomor rumah dan patokan. Jika pencarian alamat gagal, alamat tetap diisi manual. QRIS/transfer meminta unggahan bukti pembayaran dengan pratinjau dan tombol hapus/ganti. Pesanan berstatus `pending` masuk ke database. Stok berkurang hanya setelah admin mengonfirmasi, sedangkan pesanan ditolak tidak mengubah stok.
- Login aman/rentan dan pergantian mode di pojok navigasi.
- Checkout mengarah ke `login-customer.php` dan `register-customer.php`. Form customer meminta alamat dan WhatsApp, serta selalu menyimpan role customer walau POST diubah. `register-aman.php` tetap menjadi halaman uji mode aman dengan pilihan role admin/customer; mode rentan tetap menggunakan tabel lab dan pilihan role yang lemah untuk pembanding.
- Admin mode aman dapat mengelola semua menu, stok, bukti pembayaran, serta verifikasi pesanan. Customer hanya melihat riwayat pesanannya. Dashboard rentan tetap menjadi lab terpisah. Katalog publik membaca produk mode aman.
- Input gambar berupa **URL HTTPS** atau **Upload berkas gambar** dengan fitur review/pratinjau sebelum simpan.
- Konfirmasi hapus, notifikasi hasil login/CRUD/logout, dan error memakai SweetAlert2 bertema neon.
- Card edukasi pada setiap halaman rentan dapat dibuka dengan klik atau keyboard. Isinya definisi, prinsip, dampak, dan lokasi perbaikan pada versi aman.

## Urutan belajar dasar

1. **Kenali alur normal.** Masuk ke mode aman. Tambahkan produk dengan nama biasa, kategori valid, harga `28000`, dan deskripsi. Pastikan produk muncul di katalog. Edit, lalu hapus produk tersebut. Perhatikan konfirmasi dan notifikasi.
2. **SQL Injection.** Bandingkan query login dua versi. Pada versi aman, `prepare()` menetapkan struktur SQL dan `execute()` mengirim nilai terpisah. Pada versi rentan, input digabung ke string SQL. Nama makanan biasa yang mengandung apostrof sudah cukup memperlihatkan mengapa query gabungan rapuh. Tidak perlu mengubah query menjadi serangan untuk memahami konsepnya.
3. **Output HTML / XSS.** Pada mode rentan, simpan nama/deskripsi dengan markup pemformatan HTML sederhana yang tidak memiliki skrip, event handler, atau tautan. Bandingkan cara render dashboard rentan dengan dashboard aman menggunakan data uji pada tabel masing-masing. Versi rentan menafsirkan markup, versi aman menampilkan karakter teks.
4. **Role / akses.** Login aman sebagai `pelanggan_aman`; membuka `dashboard-aman.php` akan mengarah ke dashboard customer. Login sebagai `admin_aman` untuk mengelola semua produk dan memverifikasi pesanan. Sebagai pembanding IDOR, dashboard rentan tetap menerima perubahan produk lab berdasarkan ID tanpa pemeriksaan owner. Jangan hanya memeriksa tampilan tombol.
5. **CSRF.** Periksa sumber form: mode aman punya hidden token acak, mode rentan tidak. Dengan DevTools, hapus atau ubah token pada form aman milik sendiri, lalu kirim: perubahan ditolak. Mode rentan menerima pengiriman tanpa token. Konfirmasi SweetAlert2 tidak menggantikan pemeriksaan server. Hapus rentan memakai GET, aman memakai POST bertoken. Tidak ada halaman atau skrip serangan lintas situs yang disertakan.
6. **Sesi dan password.** Periksa kolom password di database demo dan cookie sesi lewat DevTools. Mode aman memakai bcrypt, HttpOnly, SameSite=Lax, strict mode, dan ID sesi baru saat login. Rentan memakai plaintext, cookie tanpa HttpOnly, strict mode mati, dan ID tidak diregenerasi saat login. Untuk melihat rotasi, muat login dahulu sebelum membandingkan cookie sebelum/sesudah submit.
7. **Unrestricted File Upload.** Pada dashboard rentan, formulir tidak membatasi ekstensi berkas (`accept` tidak ada), dan server menerima berkas apa pun tanpa pemeriksaan MIME type atau sanitasi nama berkas (nama asli disimpan di `uploads/`). Pada dashboard aman, hanya ekstensi gambar (JPG, PNG, WEBP, GIF) yang diizinkan, tipe MIME diverifikasi lewat Fileinfo & `getimagesize()`, ukuran dibatasi maksimal 2MB, dan nama berkas diacak otomatis menggunakan `random_bytes()` demi mencegah Path Traversal.
8. **Logout dan pemisahan mode.** Logout dari aman. Akses dashboard aman harus diarahkan kembali ke login. Sesi rentan yang sebelumnya aktif tidak memberikan akses ke dashboard aman.
9. **Reset.** Import ulang `database.sql` untuk mengembalikan data awal: 4 pengguna dan 12 produk pada tabel lama, serta 2 pengguna dan 6 produk pada tabel lab rentan. Ini menghapus semua perubahan data lab. Logout dari kedua mode sesudah reset.

Browser modern sering memberi SameSite=Lax secara default meski mode rentan tidak menetapkannya. Karena itu, request lintas situs tertentu bisa diblokir browser; keadaan ini tidak membuktikan endpoint telah memvalidasi CSRF. Kedua mode memakai origin localhost yang sama agar penyiapan sederhana: sesi terpisah bukan isolasi origin. Skrip XSS pada origin bersama tetap mempunyai dampak pada origin itu. Cookie HttpOnly mencegah pembacaan cookie lewat JavaScript, tetapi tidak mencegah seluruh tindakan yang dapat dilakukan XSS.

## Peta pembandingan kode

| Topik | Versi rentan | Versi aman |
|---|---|---|
| SQL Injection | Penggabungan input menjadi SQL | PDO native prepared statements |
| XSS | Echo mentah nama/deskripsi pada dashboard | `h()` / `htmlspecialchars()` saat render |
| Broken Authentication | Plaintext, tidak mengganti ID sesi | Bcrypt + `password_verify()`, regenerasi sesi, cookie terlindungi |
| CSRF | Form tanpa token; hapus melalui GET | POST + token sesi + `hash_equals()` |
| IDOR / akses | Edit/hapus produk lab berdasarkan ID saja | Dashboard admin dan customer dipisahkan dengan pemeriksaan role di server; customer tidak memiliki akses CRUD produk |
| File Upload | Unrestricted upload: tanpa validasi ekstensi, MIME, ukuran, atau nama | Whitelist ekstensi, verifikasi MIME (Fileinfo) & integritas (`getimagesize`), batas 2MB, nama acak |

`htmlspecialchars()` bukan pengganti prepared statement dan tidak perlu dipakai sebelum menyimpan setiap teks. Versi aman memvalidasi bentuk/ukuran input, menyimpan teks sebagai data, lalu melakukan encoding sesuai konteks HTML. URL gambar harus lolos validasi HTTPS sebelum dipasang sebagai atribut; pesan SweetAlert memakai `text`, bukan HTML dari input pengguna.

Untuk membuat hash akun aman baru, jalankan kode PHP lokal berikut lalu gunakan hasilnya pada kolom password akun aman:

```php
echo password_hash('password-baru-milikmu', PASSWORD_BCRYPT, ['cost' => 10]);
```

Contoh ini untuk praktik manual. Form customer dari checkout tidak dapat memilih role admin; form lab aman mengizinkan pemilihan role untuk tugas kuliah di localhost. Hash seed dapat diverifikasi dengan `password_verify('RasaAman!2026', $hashDariDatabase)`. Batas input password aman adalah 72 byte sesuai karakteristik bcrypt.

## Dependensi tampilan

- **SweetAlert2 v11 via jsDelivr:** satu-satunya library JavaScript, untuk seluruh notifikasi/konfirmasi. Internet diperlukan. Jika CDN gagal, operasi hapus yang dikonfirmasi UI dihentikan dan pesan status terlihat; endpoint rentan tetap sengaja tidak dilindungi server.
- **Google Fonts:** Inter dan Space Grotesk; font sistem menjadi fallback.
- **Foto stok Unsplash:** hanya ilustrasi menu, bukan jaminan representasi resep. Saat foto gagal dimuat, ikon makanan/minuman tetap tampil. Tidak ada pengambilan URL oleh server PHP.

CSS/JS tema tidak menggunakan framework. Modul PHP `pdo_mysql` merupakan ekstensi runtime, bukan dependensi frontend.

## Jika belum berjalan

- **Database belum siap / HTTP 503:** periksa MySQL, port, import SQL, serta kredensial `config.php`. Browser sengaja tidak menampilkan detail error SQL.
- **could not find driver:** aktifkan ekstensi `pdo_mysql` pada `php.ini`, lalu restart Apache/PHP.
- **404:** pastikan nama folder tepat `rasanusantara` di document root Apache.
- **Akses localhost ditolak:** buka dari komputer server sendiri dengan `http://localhost/rasanusantara/`, tanpa proxy atau tunnel.
- **Foto tidak terlihat:** periksa internet atau kosongkan URL; ikon fallback akan muncul.
- **Notifikasi tidak muncul:** pastikan JavaScript aktif dan koneksi ke CDN tersedia.
- **Harga:** masukkan angka utuh seperti `10000000`; tampilan menjadi `Rp 10.000.000`. Batas harga aman Rp 2.000.000.000, sesuai rentang tipe INT.

## Batas pembelajaran

Mode aman memiliki batas lima percobaan login gagal di lab localhost selama satu menit, termasuk jika username diganti. Timeout sesi tidak aktif adalah lima belas menit. Logout aman langsung mengakhiri sesi. Pada mode rentan, logout tidak langsung menghapus sesi sehingga Back/refresh dapat membuka dashboard lagi selama 1 menit. Logout kedua tidak memperpanjang jendela tersebut. Setelah jendela uji berakhir, sesi lama dihancurkan dan akses dashboard meminta login lagi. Sebelum logout, mode rentan tidak memiliki timeout aktivitas aplikasi. Ini tetap laboratorium, bukan aplikasi siap produksi: MFA, reset password, audit trail, dan isolasi origin tidak disertakan. Mode rentan sengaja tetap memiliki celah pada tabel lab; query multi-statement dinonaktifkan sehingga contoh `DROP TABLE` hanya dipakai sebagai teks uji. Jangan menerbitkan folder ini secara publik.

## Verifikasi paket

Sintaks tujuh berkas PHP dan JavaScript hasil render telah diperiksa. Pengujian pada PHP 8.3.6 dan MariaDB 10.11.14 melalui CGI mencakup login, rotasi/pemisahan sesi, CRUD, format Rupiah, validasi input, CSRF, penolakan IDOR versi aman, serta perbedaan render HTML dan akses data versi rentan. Data tes dikembalikan ke seed. Tampilan hasil render diperiksa pada desktop dan lebar ponsel 390 px. Belum diuji langsung pada instalasi XAMPP/Laragon Windows pengguna.

## Panduan pengujian di halaman

Pada login dan dashboard rentan, klik **MODE RENTAN • PENANDA EDUKASI**, lalu pilih SQL Injection, XSS, Broken Authentication, CSRF, atau IDOR. Masing-masing topik menampilkan input akun, tiga langkah manual, hasil yang diharapkan, pembanding versi aman, dan perbaikan kode. Hanya satu topik dibuka dalam satu waktu agar mudah dipresentasikan.

Login normal dengan password benar adalah langkah awal, bukan bukti kerentanan. Topik SQL Injection memisahkan kontrol password salah dari input bypass manual. Topik XSS menampilkan contoh dialog lokal `alert(123)` sebagai teks yang di-encode; membuka panduan tidak menjalankan skrip. Contoh tidak otomatis dikirim ke formulir. Topik CSRF menjelaskan bahwa pemeriksaan token bukan demonstrasi lintas situs penuh.

Etalase, formulir login, dashboard, dan pesan transaksi memakai bahasa toko yang natural. Penjelasan teknis dan akun contoh berada pada panel yang dapat dibuka saat diperlukan. Penanda mode tetap tersedia di pergantian versi dan panel edukasi. Pembatasan localhost, komentar pembelajaran, serta mekanisme aman/rentan tetap berlaku.

**Memperbarui instalasi lama:** ganti berkas PHP, `assets/style.css`, dan README.md dengan versi terbaru. Tidak ada perubahan struktur database; tidak perlu mengimpor ulang `database.sql` hanya untuk memasang pembaruan ini. Gunakan Ctrl+F5 bila CSS lama masih tersimpan di browser.

Pembaruan panel telah melewati 14 kelompok pemeriksaan fungsi dan pemeriksaan sintaks. Lima tombol topik serta pergantian panel diperiksa melalui browser; contoh skrip di panduan tetap berupa teks. Layout panel diperiksa pada desktop dan ponsel tanpa luapan horizontal.
