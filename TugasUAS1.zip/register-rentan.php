<?php
require __DIR__ . '/config.php';
start_lab_session('rentan');
$error = '';
$username = '';
$email = '';
$role = 'customer';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim(posted('username'));
    $email = trim(posted('email'));
    $password = posted('password');
    $role = posted('role');
    if ($username === '' || $email === '' || $password === '' || !in_array($role, ['admin', 'customer'], true)) {
        $error = 'Lengkapi data dan pilih role yang tersedia.';
    } else {
        try {
            // ⚠️ VULNERABLE: input digabung ke SQL; tanpa CSRF, kunci admin, atau hashing. Hanya tabel lab.
            $sql = "INSERT INTO lab_users (username,email,password,role) VALUES ('" . $username . "','" . $email . "','" . $password . "','" . $role . "')";
            $pdo->exec($sql);
            flash('success', 'Akun lab dibuat', 'Silakan masuk pada mode rentan.');
            go('login-rentan.php');
        } catch (PDOException $e) {
            $error = 'Pendaftaran gagal. Username atau email mungkin sudah digunakan.';
        }
    }
    if ($error !== '') {
        flash('error', 'Pendaftaran gagal', $error);
        go('register-rentan.php');
    }
}
page_top('Daftar akun lab', 'rentan', 'register');
?>
<section class="auth-layout">
  <div class="auth-story">
    <span class="eyebrow">MODE RENTAN · LAB LOKAL</span>
    <h1>Rasa baru.<br><span class="gradient-text">Cerita baru.</span></h1>
    <p>Akun di halaman ini hanya untuk tabel dan sesi lab rentan.</p>
    <div class="auth-art" aria-hidden="true"><span><i class="fa-solid fa-bowl-food"></i></span><span><i class="fa-solid fa-mug-hot"></i></span><span><i class="fa-solid fa-cookie-bite"></i></span></div>
  </div>
  <div class="auth-panel panel">
    <span class="eyebrow">DAFTAR MODE RENTAN</span>
    <h2>Buat akun lab.</h2>
    <p>Akun ini digunakan untuk membandingkan perilaku mode rentan.</p>
    <?php if ($error !== ''): ?><div class="form-error" role="alert"><?= h($error) ?></div><?php endif; ?>
    <form method="post" action="register-rentan.php">
      <label class="field"><span>Username</span><input name="username" value="<?= h($username) ?>" required></label>
      <label class="field"><span>Email</span><input name="email" type="email" value="<?= h($email) ?>" required></label>
      <label class="field"><span>Daftar sebagai</span><select name="role"><option value="customer" <?= $role === 'customer' ? 'selected' : '' ?>>Customer</option><option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Admin</option></select></label>
      <label class="field"><span>Kunci admin <small>(hanya untuk admin; mode rentan tidak memeriksanya)</small></span><input name="admin_key" type="password" autocomplete="off"></label>
      <label class="field"><span>Password</span><input name="password" type="password" required></label>
      <button class="btn primary full-width" type="submit">Buat akun lab →</button>
    </form>
    <p class="auth-switch">Sudah punya akun lab? <a href="login-rentan.php">Masuk di sini</a></p>
  </div>
</section>
<?php login_test_guide('rentan'); page_bottom(); ?>
