<?php
require __DIR__ . '/config.php';
start_lab_session('aman');
require_login('aman', 'login-customer.php');
if (($_SESSION['role'] ?? '') === 'admin') { go('dashboard-aman.php'); }
if (($_SESSION['role'] ?? '') !== 'customer') { http_response_code(403); exit('Akses ditolak.'); }
$statement = $pdo->prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC,id DESC');
$statement->execute([$_SESSION['user_id']]);
$orders = $statement->fetchAll();
$items = [];
if ($orders) {
    $ids = array_column($orders, 'id');
    $statement = $pdo->prepare('SELECT * FROM order_items WHERE order_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY id');
    $statement->execute($ids);
    foreach ($statement->fetchAll() as $item) { $items[$item['order_id']][] = $item; }
}
page_top('Pesanan saya', '', 'dashboard');
?>
<section class="workspace-heading"><div><span class="eyebrow">AKUN CUSTOMER</span><h1>Pesanan saya<span class="teal">.</span></h1><p>Lihat pesanan dan status verifikasi dari Kawan Santap.</p></div><div class="user-chip"><div class="user-info"><strong><?= h($_SESSION['username']) ?></strong><small>Customer</small></div><form action="logout-customer.php" method="post"><input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>"><button class="btn small ghost" type="submit">Keluar ↗</button></form></div></section>
<p><a class="btn primary" href="index.php#menu">Jelajah menu ↗</a></p>
<section class="panel order-panel"><h2>Riwayat pesanan</h2>
<?php if (!$orders): ?><p>Belum ada pesanan pada akun ini. Pengunjung juga dapat checkout tanpa mendaftar.</p><?php endif; ?>
<div class="order-list">
<?php foreach ($orders as $order): ?><article class="order-card"><div class="order-card-head"><strong><?= h($order['order_code']) ?></strong><span class="order-status <?= h($order['status']) ?>"><?= h($order['status']) ?></span></div><p><?= h($order['created_at']) ?> · <?= h(strtoupper($order['payment_method'])) ?></p><ul><?php foreach ($items[$order['id']] ?? [] as $item): ?><li><?= h($item['product_name']) ?> × <?= (int) $item['quantity'] ?></li><?php endforeach; ?></ul><strong><?= rupiah($order['total']) ?></strong></article><?php endforeach; ?>
</div></section>
<?php page_bottom(); ?>
