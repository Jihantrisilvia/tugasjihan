-- Jalankan sekali pada instalasi lama setelah database.sql pernah diimpor.
USE rasanusantara;
CREATE TABLE IF NOT EXISTS login_attempts (
 username VARCHAR(80) NOT NULL PRIMARY KEY,
 failed_count INT NOT NULL DEFAULT 0,
 locked_until DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS lab_users (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(80) NOT NULL UNIQUE,
 email VARCHAR(150) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role VARCHAR(20) NOT NULL DEFAULT 'customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS lab_products (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 owner_id INT NOT NULL,
 name VARCHAR(120) NOT NULL,
 category VARCHAR(40) NOT NULL,
 price INT NOT NULL,
 description TEXT NOT NULL,
 image_url VARCHAR(2048) NOT NULL DEFAULT '',
 KEY lab_products_owner_index (owner_id),
 CONSTRAINT lab_products_owner_fk FOREIGN KEY (owner_id) REFERENCES lab_users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO lab_users (id,username,email,password,role)
SELECT id,username,email,password,role FROM users WHERE id IN (3,4);
INSERT IGNORE INTO lab_products (id,owner_id,name,category,price,description,image_url)
SELECT p.id,p.owner_id,p.name,p.category,p.price,p.description,p.image_url
FROM products p JOIN lab_users u ON u.id=p.owner_id WHERE p.owner_id IN (3,4);
