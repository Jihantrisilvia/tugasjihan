<?php
require __DIR__ . '/config.php';
start_lab_session('aman');

// --- FILTER KATALOG PUBLIK ---
$search = isset($_GET['q']) && is_string($_GET['q']) ? trim($_GET['q']) : '';
$search = substr($search, 0, 100);
$category = isset($_GET['category']) && is_string($_GET['category']) && in_array($_GET['category'], CATEGORIES, true) ? $_GET['category'] : '';
$products = [];
$notice = null;

try {
    $sql = "SELECT p.*, COALESCE((SELECT SUM(oi.quantity) FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.product_id=p.id AND o.status='pending'),0) AS pending_qty FROM products p WHERE 1=1";
    $params = [];
    if ($search !== '') { 
        $sql .= ' AND (p.name LIKE ? OR p.description LIKE ?)';
        $params[] = '%' . $search . '%'; 
        $params[] = '%' . $search . '%'; 
    }
    if ($category !== '') { 
        $sql .= ' AND p.category = ?';
        $params[] = $category; 
    }
    $statement = $pdo->prepare($sql . ' ORDER BY p.id DESC');
    $statement->execute($params);
    $products = $statement->fetchAll();
} catch (PDOException $e) {
    $notice = ['icon' => 'error', 'title' => 'Menu belum dapat dimuat', 'text' => 'Coba muat ulang setelah memeriksa database.'];
}

page_top('Rasa lokal. Vibe baru.', '', 'index');
?>

<section class="hero">
  <div class="hero-copy">
    <span class="eyebrow">
      <span class="status-dot"></span> CITA RASA NUSANTARA, DI LEVEL BERIKUTNYA
    </span>
    <h1>Rasa lokal.<br><span class="gradient-text">Vibe baru.</span></h1>
    <p>Dari comfort food favorit sampai minuman yang bikin fresh. Jelajahi rasa Indonesia dengan sentuhan masa kini.</p>
    <div class="hero-actions">
      <a href="#menu" class="btn primary">Temukan rasamu <span>↗</span></a>
      <a href="login-aman.php" class="text-link">Buka dapur produk →</a>
    </div>
    <div class="hero-proof">
      <div class="mini-avatars">
        <span><i class="fa-solid fa-bowl-food" aria-hidden="true"></i></span>
        <span><i class="fa-solid fa-mug-hot" aria-hidden="true"></i></span>
        <span><i class="fa-solid fa-cookie-bite" aria-hidden="true"></i></span>
      </div>
      <div>
        <strong>Banyak rasa. Satu Nusantara.</strong>
        <small>Makanan · Minuman · Camilan · Dessert</small>
      </div>
    </div>
  </div>
  <div class="hero-visual">
    <div class="orbit orbit-one"></div>
    <div class="orbit orbit-two"></div>
    <span class="visual-note">THE LOCAL FAVORITES</span>
    <div class="hero-food">
      <?php photo_html('https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=1000&q=85', 'Inspirasi sajian nasi khas Nusantara'); ?>
    </div>
    <div class="floating-card float-top">
      <span class="round-icon">✦</span>
      <div>Made with love<strong>100% vibes Nusantara</strong></div>
    </div>
    <div class="floating-card float-bottom">
      <div class="float-food"><i class="fa-solid fa-bowl-food" aria-hidden="true"></i></div>
      <div>
        <small>FAVORIT SEMUA GENERASI</small>
        <strong>Nasi Goreng Nusantara</strong>
        <span class="teal">Mulai Rp 28.000</span>
      </div>
      <span class="circle-arrow">↗</span>
    </div>
    <span class="hero-coordinate">01° / TASTE THE CULTURE</span>
  </div>
</section>

<div class="ticker" aria-label="Keunggulan">
  <span>✦ RASA AUTENTIK</span>
  <span>✧ BAHAN PILIHAN</span>
  <span>✦ RACIKAN KEKINIAN</span>
  <span>✧ DARI NUSANTARA</span>
  <span>✦ UNTUK SEMUA SELERA</span>
</div>

<section id="menu" class="menu-section">
  <div class="section-heading">
    <div>
      <span class="eyebrow">TEMUKAN FAVORITMU</span>
      <h2>Menu yang bikin <span class="teal">balik lagi.</span></h2>
    </div>
    <span class="menu-count"><?= count($products) ?> sajian ditemukan</span>
  </div>

  <form class="menu-controls" method="get" action="index.php#menu">
    <input type="hidden" name="category" value="<?= h($category) ?>">
    <div class="search-field">
      <span aria-hidden="true">⌕</span>
      <input type="search" name="q" value="<?= h($search) ?>" maxlength="100" placeholder="Cari nasi goreng, kopi, atau favoritmu…" aria-label="Cari menu">
      <button class="btn small primary" type="submit">Cari</button>
    </div>
    <div class="category-tabs" role="group" aria-label="Filter kategori">
      <button name="category" value="" class="category-tab <?= $category === '' ? 'current' : '' ?>"><span class="category-icon" aria-hidden="true"><i class="fa-solid fa-utensils"></i></span><span>Semua menu</span></button>
      <?php $categoryIcons = ['Makanan' => 'fa-bowl-food', 'Minuman' => 'fa-mug-hot', 'Camilan' => 'fa-cookie-bite', 'Dessert' => 'fa-ice-cream']; foreach (CATEGORIES as $c): ?>
        <button name="category" value="<?= h($c) ?>" class="category-tab <?= $category === $c ? 'current' : '' ?>">
          <span class="category-icon" aria-hidden="true"><i class="fa-solid <?= $categoryIcons[$c] ?>"></i></span><span><?= h($c) ?></span>
        </button>
      <?php endforeach; ?>
    </div>
  </form>

  <?php if (!$products): ?>
    <div class="empty-state panel">
      <span>🍽️</span>
      <h3>Belum ada yang cocok.</h3>
      <p>Coba kata kunci atau kategori lainnya.</p>
      <a class="btn ghost" href="index.php#menu">Lihat semua menu</a>
    </div>
  <?php else: ?>
    <div class="product-grid">
      <?php foreach ($products as $i => $p): ?>
        <article class="product-card">
          <div class="product-photo-wrap">
            <?php photo_html($p['image_url'], $p['name'], $p['category']); ?>
            <span class="photo-badge"><?= h($p['category']) ?></span>
            <span class="photo-index"><?= str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) ?></span>
          </div>
          <div class="product-body">
            <div class="product-caption">
              <span>LOCAL SIGNATURE</span>
              <span aria-hidden="true">✦</span>
            </div>
            <h3><?= h($p['name']) ?></h3>
            <p><?= h($p['description']) ?></p>
            <p class="stock-note">Tersisa <?= (int) $p['stock'] ?> porsi · <?= (int) $p['pending_qty'] ?> porsi dipesan, menunggu verifikasi</p>
            <div class="product-bottom">
              <strong><?= rupiah($p['price']) ?></strong>
              <div class="product-actions">
                <button type="button" class="btn small primary add-to-cart" <?= (int) $p['stock'] <= 0 ? 'disabled' : '' ?>
                        data-id="<?= $p['id'] ?>" 
                        data-name="<?= h($p['name']) ?>" 
                        data-price="<?= $p['price'] ?>">
                  + Keranjang
                </button>
                <button type="button" class="product-detail" 
                        data-product="<?= h($p['name']) ?>" 
                        data-description="<?= h($p['description']) ?>" 
                        data-price="<?= h(rupiah($p['price'])) ?>" 
                        aria-label="Lihat detail <?= h($p['name']) ?>">↗</button>
              </div>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<!-- FLOATING CART BUTTON -->
<button id="cart-float-btn" class="cart-float-btn" type="button" onclick="toggleCartModal()" aria-label="Buka keranjang belanja" aria-controls="cart-modal" aria-expanded="false">
  🛒 <span id="cart-badge" class="cart-badge">0</span>
</button>

<!-- MODAL KERANJANG & PAYMENT -->
<div id="cart-modal" class="cart-modal-overlay">
  <div class="cart-modal-content">
    <div class="cart-header">
      <h2>Keranjang Belanja</h2>
      <button class="cart-close-btn" type="button" onclick="toggleCartModal()" aria-label="Tutup keranjang">&times;</button>
    </div>
    
    <div id="cart-items" class="cart-items-list">
      <!-- Item keranjang dimasukkan via JS -->
    </div>

    <div class="cart-footer">
      <div class="cart-total-row">
        <span>Total Pembayaran:</span>
        <strong id="cart-total-price">Rp 0</strong>
      </div>
      
      <form id="checkout-form" action="checkout.php" method="POST">
        <input type="hidden" name="cart_data" id="cart-data-input">
        <button type="submit" id="btn-checkout" class="btn primary cart-submit">Lanjut ke checkout ↗</button>
      </form>
    </div>
  </div>
</div>

<script>
// Logic Keranjang Belanja (localStorage)
let cart;
try {
  cart = (JSON.parse(localStorage.getItem('rasa_cart')) || []).filter(item =>
    Number.isSafeInteger(item.id) && item.id > 0 && Number.isSafeInteger(item.qty) && item.qty > 0 &&
    Number.isFinite(item.price) && typeof item.name === 'string'
  );
} catch (_) { cart = []; }

function escapeCartText(value) {
  return value.replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}

function saveCart() {
  localStorage.setItem('rasa_cart', JSON.stringify(cart));
  updateCartUI();
}

function formatRupiah(number) {
  return 'Rp ' + new Intl.NumberFormat('id-ID').format(number);
}

function addToCart(id, name, price) {
  const existing = cart.find(item => item.id === id);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ id, name, price, qty: 1 });
  }
  saveCart();
}

function updateQty(id, change) {
  const item = cart.find(item => item.id === id);
  if (item) {
    item.qty += change;
    if (item.qty <= 0) {
      cart = cart.filter(i => i.id !== id);
    }
    saveCart();
  }
}

function updateCartUI() {
  const badge = document.getElementById('cart-badge');
  const itemsContainer = document.getElementById('cart-items');
  const totalPriceEl = document.getElementById('cart-total-price');
  const cartInput = document.getElementById('cart-data-input');
  const btnCheckout = document.getElementById('btn-checkout');

  const totalQty = cart.reduce((sum, item) => sum + item.qty, 0);
  const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);

  badge.innerText = totalQty;
  totalPriceEl.innerText = formatRupiah(totalPrice);
  cartInput.value = JSON.stringify(cart);

  if (cart.length === 0) {
    itemsContainer.innerHTML = '<p class="cart-empty">Keranjang Anda masih kosong.</p>';
    btnCheckout.disabled = true;
  } else {
    btnCheckout.disabled = false;
    itemsContainer.innerHTML = cart.map(item => `
      <div class="cart-item">
        <div class="cart-item-info">
          <strong>${escapeCartText(item.name)}</strong><br>
          <small>${formatRupiah(item.price)} x ${item.qty}</small>
        </div>
        <div class="cart-item-qty">
          <button type="button" class="btn small ghost" onclick="updateQty(${item.id}, -1)">-</button>
          <span>${item.qty}</span>
          <button type="button" class="btn small ghost" onclick="updateQty(${item.id}, 1)">+</button>
        </div>
      </div>
    `).join('');
  }
}

function toggleCartModal() {
  const modal = document.getElementById('cart-modal');
  modal.style.display = (modal.style.display === 'flex') ? 'none' : 'flex';
  document.getElementById('cart-float-btn').setAttribute('aria-expanded', String(modal.style.display === 'flex'));
}

document.addEventListener('click', event => {
  // Tombol Tambah ke Keranjang
  const addBtn = event.target.closest('.add-to-cart');
  if (addBtn) {
    const id = parseInt(addBtn.dataset.id);
    const name = addBtn.dataset.name;
    const price = parseFloat(addBtn.dataset.price);
    addToCart(id, name, price);
  }

  // NeonAlert Detail Produk
  const button = event.target.closest('[data-product]');
  if (button && window.neonAlert) {
    neonAlert.fire({
      title: button.dataset.product,
      text: button.dataset.description + ' — ' + button.dataset.price,
      footer: 'Kawan Santap · Informasi sajian',
      confirmButtonText: 'Kembali ke menu'
    });
  }
});

// Inisialisasi awal saat halaman dimuat
document.addEventListener('DOMContentLoaded', updateCartUI);
</script>

<?php page_bottom($notice); ?>
