<?php
require __DIR__ . '/config.php';
start_lab_session('aman');
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_ok() || ($_SESSION['role'] ?? '') !== 'customer') {
    flash('error', 'Permintaan logout tidak valid', 'Gunakan tombol Keluar pada halaman pesanan.');
    go(empty($_SESSION['user_id']) ? 'login-customer.php' : 'dashboard-customer.php');
}
$_SESSION = [];
$cookie = session_get_cookie_params();
setcookie(session_name(), '', ['expires' => time() - 42000, 'path' => $cookie['path'], 'domain' => $cookie['domain'], 'secure' => $cookie['secure'], 'httponly' => $cookie['httponly'], 'samesite' => $cookie['samesite'] ?? '']);
session_destroy();
go('login-customer.php?loggedout=1');
