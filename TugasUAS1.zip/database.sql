-- Kawan Santap / lokal saja / MySQL 5.7+ atau MariaDB 10.4+
-- Import melalui phpMyAdmin, atau: mysql -u root -p < database.sql
-- PERHATIAN: import ulang mereset tabel products dan users di database lab ini.
CREATE DATABASE IF NOT EXISTS rasanusantara CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rasanusantara;
SET NAMES utf8mb4;
DROP TABLE IF EXISTS lab_products;
DROP TABLE IF EXISTS lab_users;
DROP TABLE IF EXISTS login_attempts;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT NOT NULL AUTO_INCREMENT,
    username VARCHAR(80) NOT NULL,
    email VARCHAR(150) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'customer',
    address TEXT NULL,
    whatsapp VARCHAR(25) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY users_username_unique (username),
    UNIQUE KEY users_email_unique (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE products (
    id INT NOT NULL AUTO_INCREMENT,
    owner_id INT NOT NULL,
    name VARCHAR(120) NOT NULL,
    category VARCHAR(40) NOT NULL,
    price INT NOT NULL,
    description TEXT NOT NULL,
    image_url VARCHAR(2048) NOT NULL DEFAULT '',
    stock INT NOT NULL DEFAULT 20,
    PRIMARY KEY (id),
    KEY products_owner_index (owner_id),
    KEY products_category_index (category),
    CONSTRAINT products_owner_fk FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE orders (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  order_code VARCHAR(30) NOT NULL UNIQUE,
  user_id INT NULL,
  customer_name VARCHAR(120) NOT NULL,
  whatsapp VARCHAR(25) NOT NULL,
  address TEXT NOT NULL,
  latitude DECIMAL(10,7) NULL,
  longitude DECIMAL(10,7) NULL,
  payment_method VARCHAR(20) NOT NULL,
  proof_path VARCHAR(255) NULL,
  total INT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME NULL,
  KEY orders_user_index (user_id),
  KEY orders_status_index (status),
  CONSTRAINT orders_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE order_items (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NULL,
  product_name VARCHAR(120) NOT NULL,
  quantity INT NOT NULL,
  unit_price INT NOT NULL,
  subtotal INT NOT NULL,
  KEY order_items_product_index (product_id),
  CONSTRAINT order_items_order_fk FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  CONSTRAINT order_items_product_fk FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Password aman: RasaAman!2026. Hash unik dibuat dengan password_hash(PASSWORD_BCRYPT).
-- Untuk membuat hash baru: password_hash('password-baru', PASSWORD_BCRYPT, ['cost' => 10]).
-- Role customer juga diberi produk untuk latihan kepemilikan; bukan toko produksi.
INSERT INTO users (id, username, email, password, role) VALUES
(1, 'admin_aman', 'admin.aman@example.test', '$2y$10$v2VcSup6W7znb2GB6Rsv4uWlblQrtein0XRwsSBEH/2a6Gt6ByGPq', 'admin'),
(2, 'pelanggan_aman', 'pelanggan.aman@example.test', '$2y$10$9RUDZLJVdjscR5/WZBmlbuLKfENV0f71qUmijKm7bxx.U0NTMXvfW', 'customer'),
-- ⚠️ VULNERABLE LINE: password berikut sengaja disimpan sebagai teks biasa.
(3, 'admin_rentan', 'admin.rentan@example.test', 'RasaRentan!2026', 'admin'),
(4, 'pelanggan_rentan', 'pelanggan.rentan@example.test', 'RasaRentan!2026', 'customer');

-- Foto stok untuk ilustrasi; tidak selalu menggambarkan resep persis.
-- Gambar eksternal opsional: bila gagal, antarmuka menampilkan ikon kategori.
INSERT INTO products (id, owner_id, name, category, price, description, image_url) VALUES
(1, 1, 'Nasi Goreng Nusantara', 'Makanan', 28000, 'Nasi goreng dengan racikan rempah pilihan, telur, dan sentuhan pedas khas rumahan.', 'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=700&q=80'),
(2, 2, 'Ayam Bakar Rempah', 'Makanan', 35000, 'Ayam bakar berbumbu meresap, disajikan bersama nasi hangat dan sambal pilihan.', 'https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=700&q=80'),
(3, 3, 'Mie Goreng Kampung', 'Makanan', 25000, 'Mie goreng gurih dengan sayuran segar dan bumbu manis pedas yang pas.', 'https://images.unsplash.com/photo-1516100882582-96c3a05fe590?auto=format&fit=crop&w=700&q=80'),
(4, 1, 'Kopi Susu Gula Aren', 'Minuman', 22000, 'Espresso, susu segar, dan gula aren yang creamy. Teman santai paling pas.', 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=700&q=80'),
(5, 2, 'Es Matcha Kelapa', 'Minuman', 26000, 'Matcha dengan sentuhan kelapa, lembut, segar, dan beda dari biasanya.', 'https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&w=700&q=80'),
(6, 4, 'Teh Lemon Serai', 'Minuman', 18000, 'Teh dingin dengan lemon dan aroma serai untuk menyegarkan harimu.', 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=700&q=80'),
(7, 3, 'Dimsum Ayam Juara', 'Camilan', 24000, 'Empat dimsum ayam hangat dengan saus pedas gurih. Sekali coba, susah berhenti.', 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=700&q=80'),
(8, 4, 'Pisang Goreng Karamel', 'Camilan', 20000, 'Pisang renyah di luar, lembut di dalam, dengan karamel manis yang pas.', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=700&q=80'),
(9, 2, 'Tahu Crispy Sambal', 'Camilan', 16000, 'Tahu garing berbumbu dengan sambal cocol untuk teman ngobrol sore.', ''),
(10, 3, 'Klepon Creamy Cup', 'Dessert', 23000, 'Inspirasi klepon pandan, kelapa, dan gula merah dalam dessert cup kekinian.', 'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=700&q=80'),
(11, 4, 'Es Krim Cokelat Lokal', 'Dessert', 24000, 'Es krim cokelat lembut dengan topping renyah untuk penutup yang manis.', 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=700&q=80'),
(12, 1, 'Puding Mangga Senja', 'Dessert', 21000, 'Puding mangga berlapis krim vanila yang ringan, lembut, dan menyegarkan.', 'https://images.unsplash.com/photo-1488900128323-21503983a07e?auto=format&fit=crop&w=700&q=80');

CREATE TABLE lab_users (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(80) NOT NULL UNIQUE,
 email VARCHAR(150) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role VARCHAR(20) NOT NULL DEFAULT 'customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE login_attempts (
 username VARCHAR(80) NOT NULL PRIMARY KEY,
 failed_count INT NOT NULL DEFAULT 0,
 locked_until DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE lab_products (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 owner_id INT NOT NULL,
 name VARCHAR(120) NOT NULL,
 category VARCHAR(40) NOT NULL,
 price INT NOT NULL,
 description TEXT NOT NULL,
 image_url VARCHAR(2048) NOT NULL DEFAULT '',
 KEY lab_products_owner_index (owner_id),
 CONSTRAINT lab_products_owner_fk FOREIGN KEY (owner_id) REFERENCES lab_users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO lab_users (id,username,email,password,role)
SELECT id,username,email,password,role FROM users WHERE id IN (3,4);
INSERT INTO lab_products (id,owner_id,name,category,price,description,image_url)
SELECT id,owner_id,name,category,price,description,image_url FROM products WHERE owner_id IN (3,4);
