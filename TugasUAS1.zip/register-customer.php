<?php
require __DIR__ . '/config.php';
start_lab_session('aman');

$error = '';
$username = '';
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim(posted('username'));
    $email = trim(posted('email'));
    $password = posted('password');
    $confirmation = posted('password_confirmation');
    $address = trim(posted('address'));
    $whatsapp = trim(posted('whatsapp'));

    if (!csrf_ok()) {
        $error = 'Form kedaluwarsa. Muat ulang halaman lalu coba lagi.';
    } elseif (!preg_match('/^[A-Za-z0-9_.-]{3,80}$/D', $username)) {
        $error = 'Username harus 3–80 karakter dan hanya boleh berisi huruf, angka, titik, garis bawah, atau tanda hubung.';
    } elseif (strlen($email) > 150 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Masukkan alamat email yang valid, maksimal 150 karakter.';
    } elseif ($address === '' || strlen($address) > 1000) {
        $error = 'Alamat wajib diisi, maksimal 1.000 karakter.';
    } elseif (!preg_match('/^\+?[0-9]{9,15}$/', $whatsapp)) {
        $error = 'Nomor WhatsApp harus 9–15 angka, boleh diawali tanda +.';
    } elseif (strlen($password) < 8 || strlen($password) > 72) {
        $error = 'Password harus berisi 8–72 byte.';
    } elseif ($password !== $confirmation) {
        $error = 'Konfirmasi password belum cocok.';
    } else {
        try {
            $statement = $pdo->prepare('INSERT INTO users (username, email, password, role, address, whatsapp) VALUES (?, ?, ?, ?, ?, ?)');
            $statement->execute([$username, $email, password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]), 'customer', $address, $whatsapp]);
            $cart = $_SESSION['checkout_cart'] ?? null;
            session_regenerate_id(true);
            $_SESSION = ['user_id' => (int) $pdo->lastInsertId(), 'username' => $username, 'role' => 'customer', 'csrf' => bin2hex(random_bytes(32)), 'last_active' => time(), 'session_marker' => hash('sha256', session_id())];
            if ($cart !== null) { $_SESSION['checkout_cart'] = $cart; }
            flash('success', 'Akun dibuat', 'Data customer sudah tersimpan.');
            go($cart !== null ? 'checkout.php' : 'dashboard-customer.php');
        } catch (PDOException $e) {
            $error = $e->getCode() === '23000'
                ? 'Username atau email sudah dipakai. Gunakan yang lain.'
                : 'Pendaftaran belum dapat diproses. Coba kembali beberapa saat lagi.';
        }
    }
    if ($error !== '') {
        flash('error', 'Pendaftaran gagal', $error);
        go('register-customer.php');
    }
}

page_top('Daftar customer', '', 'register');
?>
<section class="auth-layout">
  <div class="auth-story">
    <span class="eyebrow">JADI BAGIAN DARI KAWAN SANTAP</span>
    <h1>Rasa baru.<br><span class="gradient-text">Cerita baru.</span></h1>
    <p>Buat akun customer untuk memesan dan melihat riwayat pesananmu.</p>
    <div class="auth-art" aria-hidden="true">
      <span><i class="fa-solid fa-bowl-food"></i></span>
      <span><i class="fa-solid fa-mug-hot"></i></span>
      <span><i class="fa-solid fa-cookie-bite"></i></span>
    </div>
    <ul class="feature-list">
      <li>Data alamat tersimpan untuk pesanan berikutnya</li>
      <li>Riwayat pesanan dalam satu tempat</li>
      <li>Nomor WhatsApp memudahkan konfirmasi</li>
    </ul>
  </div>
  <div class="auth-panel panel">
    <span class="eyebrow">AKUN KAWAN SANTAP</span>
    <h2>Mulai dari sini.</h2>
    <p>Daftar sebagai customer untuk menyimpan alamat dan melihat status pesanan.</p>
    <?php if ($error !== ''): ?><div class="form-error" role="status"><?= h($error) ?></div><?php endif; ?>
    <form method="post" action="register-customer.php" data-validate>
      <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
      <label class="field"><span>Username</span>
        <input name="username" value="<?= h($username) ?>" autocomplete="username" minlength="3" maxlength="80" pattern="[A-Za-z0-9_.-]+" placeholder="Contoh: dapur_sari" required>
      </label>
      <label class="field"><span>Email</span>
        <input name="email" type="email" value="<?= h($email) ?>" autocomplete="email" maxlength="150" placeholder="nama@email.com" required>
      </label>
      <label class="field"><span>Nomor WhatsApp</span><input name="whatsapp" type="tel" inputmode="tel" value="<?= h($whatsapp ?? '') ?>" placeholder="081234567890" required></label>
      <label class="field"><span>Alamat lengkap</span><textarea name="address" rows="3" required><?= h($address ?? '') ?></textarea></label>
      <label class="field" for="new-password"><span>Password</span></label>
      <div class="field password-wrap">
        <input id="new-password" name="password" type="password" autocomplete="new-password" minlength="8" maxlength="72" placeholder="Minimal 8 karakter" required>
        <button type="button" data-password-toggle="new-password" aria-label="Tampilkan atau sembunyikan password" aria-pressed="false">Lihat</button>
      </div>
      <label class="field" for="confirm-password"><span>Ulangi password</span></label>
      <div class="field password-wrap">
        <input id="confirm-password" name="password_confirmation" type="password" autocomplete="new-password" minlength="8" maxlength="72" placeholder="Ketik ulang password" required>
        <button type="button" data-password-toggle="confirm-password" aria-label="Tampilkan atau sembunyikan konfirmasi password" aria-pressed="false">Lihat</button>
      </div>
      <button class="btn primary full-width" type="submit">Buat akun <span>→</span></button>
    </form>
    <p class="auth-switch">Sudah punya akun? <a href="login-customer.php">Masuk di sini</a></p>
  </div>
</section>
<?php page_bottom(); ?>
