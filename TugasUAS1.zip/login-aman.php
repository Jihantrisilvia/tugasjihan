<?php
require __DIR__ . '/config.php';
start_lab_session('aman');
// --- PROSES LOGIN AMAN ---
$error = '';
$username = '';
$lockSeconds = 0;
$clientKey = safe_login_client_key();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim(posted('username'));
    $_SESSION['login_username'] = $username;
    $password = posted('password');
    if (!csrf_ok()) {
        $error = 'Form kedaluwarsa. Muat ulang halaman lalu coba lagi.';
    } elseif ($username === '' || strlen($username) > 80 || $password === '' || strlen($password) > 72) {
        $error = 'Username atau password tidak valid.';
    } else {
        try {
            safe_login_clear_expired($pdo, $clientKey);
            if (safe_login_lock_seconds($pdo, $clientKey) > 0) {
                $error = 'Terlalu banyak percobaan gagal di lab lokal ini. Tunggu hingga hitung mundur selesai.';
            } else {
            // AMAN: nilai pengguna dikirim TERPISAH dari struktur SQL.
            $statement = $pdo->prepare('SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1');
            $statement->execute([$username]);
            $user = $statement->fetch();
            // AMAN: password_verify membandingkan password dengan hash; plaintext tidak diterima.
            // Hash dummy menjaga proses verifikasi tetap berjalan saat username tidak ditemukan.
            $hash = $user ? $user['password'] : '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi';
            $verified = password_verify($password, $hash);
            if ($user && $verified && password_get_info($user['password'])['algoName'] === 'bcrypt') {
                // AMAN: bila biaya bcrypt berubah, hash diperbarui dengan password_hash, bukan plaintext.
                if (password_needs_rehash($user['password'], PASSWORD_BCRYPT, ['cost' => 10])) {
                    $statement = $pdo->prepare('UPDATE users SET password = ? WHERE id = ?');
                    $statement->execute([password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]), $user['id']]);
                }
                // AMAN: ganti ID setelah autentikasi agar ID lama tidak menjadi sesi login.
                session_regenerate_id(true);
                $checkoutCart = $_SESSION['checkout_cart'] ?? null;
                $_SESSION = ['user_id' => (int) $user['id'], 'username' => $user['username'], 'role' => $user['role'], 'csrf' => bin2hex(random_bytes(32)), 'last_active' => time(), 'session_marker' => hash('sha256', session_id())];
                if ($checkoutCart !== null) { $_SESSION['checkout_cart'] = $checkoutCart; }
                $statement = $pdo->prepare('DELETE FROM login_attempts WHERE username = ?');
                $statement->execute([$clientKey]);
                flash('success', 'Selamat datang di dapur!', 'Silakan kelola menu dan sajian favoritmu.');
                go($user['role'] === 'admin' ? 'dashboard-aman.php' : ($checkoutCart !== null ? 'checkout.php' : 'dashboard-customer.php'));
            }
            $lockSeconds = safe_login_record_failure($pdo, $clientKey);
            $error = $lockSeconds > 0
                ? 'Terlalu banyak percobaan gagal di lab lokal ini. Tunggu 1 menit sebelum mencoba lagi.'
                : 'Username atau password tidak valid.';
            }
        } catch (PDOException $e) {
            // AMAN: tidak membocorkan query, stack trace, maupun keberadaan username.
            $error = 'Login belum dapat diproses. Coba kembali beberapa saat lagi.';
        }
    }
    flash('error', 'Login belum berhasil', $error);
    go('login-aman.php');
}
$username = (string) ($_SESSION['login_username'] ?? '');
try { $lockSeconds = safe_login_lock_seconds($pdo, $clientKey); }
catch (PDOException $e) { $lockSeconds = 0; }
if (isset($_GET['loggedout'])) { flash('success', 'Sampai jumpa!', 'Kamu sudah keluar dari akun.'); }
page_top('Masuk akun', 'aman', 'login');
?>
<section class="auth-layout">
<div class="auth-story">
<span class="eyebrow">WELCOME TO THE FLAVOR SIDE</span>
<h1>Racik rasa.<br>
<span class="gradient-text">Bagikan cerita.</span>
</h1>
<p>Kelola sajian favorit, perbarui koleksi menu, dan hadirkan rasa khas Nusantara dari dapurmu.</p>
<div class="auth-art" aria-hidden="true">
<span><i class="fa-solid fa-bowl-food"></i></span>
<span><i class="fa-solid fa-mug-hot"></i></span>
<span><i class="fa-solid fa-cookie-bite"></i></span>
</div>
<ul class="feature-list">
<li>Koleksi menu dalam satu tempat</li>
<li>Harga dan informasi sajian yang mudah diperbarui</li>
<li>Tampilan menarik untuk setiap rasa</li>
</ul>
</div>
<div class="auth-panel panel">
<span class="eyebrow">AKUN KAWAN SANTAP</span>
<h2>Selamat datang kembali.</h2>
<p>Masuk untuk mengelola menu dan koleksi sajianmu.</p>
<?php if ($error !== ''): ?>
<div class="form-error" role="status">
<?= h($error) ?>
</div>
<?php endif; ?>
<?php if ($lockSeconds > 0): ?>
<div class="login-lock-status" role="status" data-lock-seconds="<?= $lockSeconds ?>">
  <strong>Login dikunci sementara karena terlalu banyak aksi</strong>
  <span>Coba lagi dalam <b data-lock-countdown><?= sprintf('%02d:%02d', intdiv($lockSeconds, 60), $lockSeconds % 60) ?></b>. Halaman tidak perlu dimuat ulang.</span>
</div>
<?php endif; ?>
<form method="post" action="login-aman.php" data-validate>
<!-- AMAN: token acak terikat ke sesi; server memverifikasinya dengan hash_equals. -->
<input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<label class="field">
<span>Username</span>
<input name="username" value="<?= h($username) ?>" autocomplete="username" maxlength="80" placeholder="Masukkan username" required>
</label>
<label class="field" for="password">
<span>Password</span>
</label>
<div class="field password-wrap">
<input id="password" name="password" type="password" autocomplete="current-password" maxlength="72" placeholder="Masukkan password" required>
<button type="button" data-password-toggle="password" aria-label="Tampilkan atau sembunyikan password" aria-pressed="false">Lihat</button>
</div>
<button class="btn primary full-width" type="submit" data-safe-login-submit <?= $lockSeconds > 0 ? 'disabled' : '' ?>>Masuk ke dapur <span>→</span>
</button>
<p class="form-hint">Selamat datang di dapur Kawan Santap.</p>
</form>
<p class="auth-switch">Belum punya akun uji? <a href="register-aman.php">Daftar dan pilih role</a></p>
</div>
</section>
<script>
const lockStatus = document.querySelector('[data-lock-seconds]');
if (lockStatus) {
  const submitButton = document.querySelector('[data-safe-login-submit]');
  const form = submitButton.closest('form');
  form.addEventListener('submit', event => { if (submitButton.disabled) event.preventDefault(); });
  const countdown = lockStatus.querySelector('[data-lock-countdown]');
  const endTime = Date.now() + Number(lockStatus.dataset.lockSeconds) * 1000;
  const updateCountdown = () => {
    const remaining = Math.max(0, Math.ceil((endTime - Date.now()) / 1000));
    countdown.textContent = String(Math.floor(remaining / 60)).padStart(2, '0') + ':' + String(remaining % 60).padStart(2, '0');
    if (remaining === 0) {
      submitButton.disabled = false;
      lockStatus.querySelector('strong').textContent = 'Login siap dicoba lagi';
      lockStatus.querySelector('span').textContent = 'Silakan masukkan password dan coba login kembali.';
      clearInterval(timer);
    }
  };
  const timer = setInterval(updateCountdown, 1000);
  updateCountdown();
}
</script>
<?php login_test_guide('aman', true); page_bottom(); ?>
