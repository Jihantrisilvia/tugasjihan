<?php
require __DIR__ . '/config.php';
start_lab_session('aman');
require_login('aman');
if (($_SESSION['role'] ?? '') !== 'admin') { http_response_code(403); exit('Akses ditolak.'); }
$id = filter_input(INPUT_GET, 'order', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if (!$id) { http_response_code(404); exit; }
$statement = $pdo->prepare('SELECT proof_path FROM orders WHERE id = ?');
$statement->execute([$id]);
$name = $statement->fetchColumn();
if (!$name || basename($name) !== $name) { http_response_code(404); exit; }
$path = __DIR__ . '/private_uploads/proofs/' . $name;
if (!is_file($path)) { http_response_code(404); exit; }
$mime = (new finfo(FILEINFO_MIME_TYPE))->file($path);
if (!in_array($mime, ['image/jpeg','image/png','image/webp','application/pdf'], true)) { http_response_code(404); exit; }
header('Content-Type: ' . $mime);
header('Content-Disposition: inline; filename="bukti-' . (int) $id . '.' . pathinfo($name, PATHINFO_EXTENSION) . '"');
header('Content-Length: ' . filesize($path));
readfile($path);
