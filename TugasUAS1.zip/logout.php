<?php
// Endpoint lama diarahkan ke versi aman; dashboard memakai URL mode khusus.
header('Location: logout-aman.php', true, 303);
exit;
