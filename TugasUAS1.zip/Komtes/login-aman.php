<?php
require __DIR__ . '/config.php';
start_lab_session('aman');
// --- PROSES LOGIN AMAN ---
$error = '';
$username = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim(posted('username'));
    $password = posted('password');
    if (!csrf_ok()) {
        $error = 'Form kedaluwarsa. Muat ulang halaman lalu coba lagi.';
    } elseif ($username === '' || strlen($username) > 80 || $password === '' || strlen($password) > 72) {
        $error = 'Username atau password tidak valid.';
    } else {
        try {
            // AMAN: nilai pengguna dikirim TERPISAH dari struktur SQL.
            $statement = $pdo->prepare('SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1');
            $statement->execute([$username]);
            $user = $statement->fetch();
            // AMAN: password_verify membandingkan password dengan hash; plaintext tidak diterima.
            // Hash dummy menjaga proses verifikasi tetap berjalan saat username tidak ditemukan.
            $hash = $user ? $user['password'] : '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi';
            $verified = password_verify($password, $hash);
            if ($user && $verified && password_get_info($user['password'])['algoName'] === 'bcrypt') {
                // AMAN: bila biaya bcrypt berubah, hash diperbarui dengan password_hash, bukan plaintext.
                if (password_needs_rehash($user['password'], PASSWORD_BCRYPT, ['cost' => 10])) {
                    $statement = $pdo->prepare('UPDATE users SET password = ? WHERE id = ?');
                    $statement->execute([password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]), $user['id']]);
                }
                // AMAN: ganti ID setelah autentikasi agar ID lama tidak menjadi sesi login.
                session_regenerate_id(true);
                $_SESSION = ['user_id' => (int) $user['id'], 'username' => $user['username'], 'role' => $user['role'], 'csrf' => bin2hex(random_bytes(32))];
                flash('success', 'Selamat datang di dapur!', 'Login aman berhasil. Silakan kelola produk milikmu.');
                go('dashboard-aman.php');
            }
            $error = 'Username atau password tidak valid.';
        } catch (PDOException $e) {
            // AMAN: tidak membocorkan query, stack trace, maupun keberadaan username.
            $error = 'Login belum dapat diproses. Coba kembali beberapa saat lagi.';
        }
    }
    flash('error', 'Login belum berhasil', $error);
}
if (isset($_GET['loggedout'])) { flash('success', 'Sampai jumpa!', 'Sesi aman sudah diakhiri.'); }
page_top('Masuk aman', 'aman', 'login');
?>
<section class="auth-layout">
<div class="auth-story">
<span class="eyebrow">WELCOME TO THE FLAVOR SIDE</span>
<h1>Racik rasa.<br>
<span class="gradient-text">Jaga kepercayaan.</span>
</h1>
<p>Masuk ke dapur RasaNusantara. Kelola menu favorit dengan praktik keamanan yang bisa kamu pelajari langsung dari kodenya.</p>
<div class="auth-art" aria-hidden="true">
<span>🍲</span>
<span>🥤</span>
<span>🥟</span>
</div>
<ul class="feature-list">
<li>Password disimpan sebagai hash bcrypt</li>
<li>Input dipisahkan dari perintah SQL</li>
<li>Sesi diperbarui setelah login</li>
</ul>
</div>
<div class="auth-panel panel">
<span class="badge safe">◈ SECURE VERSION</span>
<h2>Selamat datang kembali.</h2>
<p>Masuk dengan akun demo versi aman.</p>
<?php if ($error !== ''): ?>
<div class="form-error" role="status">
<?= h($error) ?>
</div>
<?php endif; ?>
<form method="post" action="login-aman.php" data-validate>
<!-- AMAN: token acak terikat ke sesi; server memverifikasinya dengan hash_equals. -->
<input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<label class="field">
<span>Username</span>
<input name="username" value="<?= h($username) ?>" autocomplete="username" maxlength="80" placeholder="Contoh: admin_aman" required>
</label>
<label class="field" for="password">
<span>Password</span>
</label>
<div class="field password-wrap">
<input id="password" name="password" type="password" autocomplete="current-password" maxlength="72" placeholder="Masukkan password demo" required>
<button type="button" data-password-toggle="password" aria-label="Tampilkan atau sembunyikan password" aria-pressed="false">Lihat</button>
</div>
<button class="btn primary full-width" type="submit">Masuk ke dapur <span>→</span>
</button>
<p class="form-hint">◈ Sesi terpisah dari mode rentan.</p>
</form>
<details class="demo-credentials" open>
<summary>Akun demo untuk belajar</summary>
<div class="credential-row">
<code>admin_aman</code>
<code>RasaAman!2026</code>
</div>
<div class="credential-row">
<code>pelanggan_aman</code>
<code>RasaAman!2026</code>
</div>
<p>Keduanya bisa mengelola produk sendiri. Role ditampilkan sebagai informasi; admin tidak melewati pemeriksaan owner_id.</p>
</details>
</div>
</section>
<?php page_bottom(); ?>
