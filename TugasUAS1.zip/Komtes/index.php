<?php
require __DIR__ . '/config.php';
// --- FILTER KATALOG PUBLIK ---
$search = isset($_GET['q']) && is_string($_GET['q']) ? trim($_GET['q']) : '';
$search = substr($search, 0, 100);
$category = isset($_GET['category']) && is_string($_GET['category']) && in_array($_GET['category'], CATEGORIES, true) ? $_GET['category'] : '';
$products = [];
$notice = null;
try {
    // SELECT biasa pada landing, dengan parameter binding saat ada filter.
    $sql = 'SELECT * FROM products WHERE 1=1';
    $params = [];
    if ($search !== '') { $sql .= ' AND (name LIKE ? OR description LIKE ?)'; $params[] = '%' . $search . '%'; $params[] = '%' . $search . '%'; }
    if ($category !== '') { $sql .= ' AND category = ?'; $params[] = $category; }
    $statement = $pdo->prepare($sql . ' ORDER BY id DESC');
    $statement->execute($params);
    $products = $statement->fetchAll();
} catch (PDOException $e) {
    $notice = ['icon' => 'error', 'title' => 'Menu belum dapat dimuat', 'text' => 'Coba muat ulang setelah memeriksa database.'];
}
page_top('Rasa lokal. Vibe baru.', '', 'index');
?>
<section class="hero">
  <div class="hero-copy">
<span class="eyebrow">
<span class="status-dot">
</span> CITA RASA NUSANTARA, DI LEVEL BERIKUTNYA</span>
<h1>Rasa lokal.<br>
<span class="gradient-text">Vibe baru.</span>
</h1>
<p>Dari comfort food favorit sampai minuman yang bikin fresh. Jelajahi rasa Indonesia dengan sentuhan masa kini.</p>
<div class="hero-actions">
<a href="#menu" class="btn primary">Temukan rasamu <span>↗</span>
</a>
<a href="login-aman.php" class="text-link">Buka dapur produk →</a>
</div>
<div class="hero-proof">
<div class="mini-avatars">
<span>🍜</span>
<span>☕</span>
<span>🥟</span>
</div>
<div>
<strong>Banyak rasa. Satu Nusantara.</strong>
<small>Makanan · Minuman · Camilan · Dessert</small>
</div>
</div>
</div>
  <div class="hero-visual">
<div class="orbit orbit-one">
</div>
<div class="orbit orbit-two">
</div>
<span class="visual-note">THE LOCAL FAVORITES</span>
<div class="hero-food">
<?php photo_html('https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=1000&q=85', 'Inspirasi sajian nasi khas Nusantara'); ?>
</div>
<div class="floating-card float-top">
<span class="round-icon">✦</span>
<div>Made with love<strong>100% vibes Nusantara</strong>
</div>
</div>
<div class="floating-card float-bottom">
<div class="float-food">🍲</div>
<div>
<small>FAVORIT SEMUA GENERASI</small>
<strong>Nasi Goreng Nusantara</strong>
<span class="teal">Mulai Rp 28.000</span>
</div>
<span class="circle-arrow">↗</span>
</div>
<span class="hero-coordinate">01° / TASTE THE CULTURE</span>
</div>
</section>
<div class="ticker" aria-label="Keunggulan">
<span>✦ RASA AUTENTIK</span>
<span>✧ BAHAN PILIHAN</span>
<span>✦ RACIKAN KEKINIAN</span>
<span>✧ DARI NUSANTARA</span>
<span>✦ UNTUK SEMUA SELERA</span>
</div>
<section id="menu" class="menu-section">
<div class="section-heading">
<div>
<span class="eyebrow">TEMUKAN FAVORITMU</span>
<h2>Menu yang bikin <span class="teal">balik lagi.</span>
</h2>
</div>
<span class="menu-count">
<?= count($products) ?> sajian ditemukan</span>
</div>
<form class="menu-controls" method="get" action="index.php#menu">
<!-- Pertahankan kategori saat tombol Cari ditekan; tombol kategori mengirim nilai pilihan terbaru. -->
<input type="hidden" name="category" value="<?= h($category) ?>">
<div class="search-field">
<span aria-hidden="true">⌕</span>
<input type="search" name="q" value="<?= h($search) ?>" maxlength="100" placeholder="Cari nasi goreng, kopi, atau favoritmu…" aria-label="Cari menu">
<button class="btn small primary" type="submit">Cari</button>
</div>
<div class="category-tabs" role="group" aria-label="Filter kategori">
<button name="category" value="" class="category-tab <?= $category === '' ? 'current' : '' ?>">Semua menu</button>
<?php foreach (CATEGORIES as $c): ?>
<button name="category" value="<?= h($c) ?>" class="category-tab <?= $category === $c ? 'current' : '' ?>">
<?= h($c) ?>
</button>
<?php endforeach; ?>
</div>
</form>
<?php if (!$products): ?>
<div class="empty-state panel">
<span>🍽️</span>
<h3>Belum ada yang cocok.</h3>
<p>Coba kata kunci atau kategori lainnya.</p>
<a class="btn ghost" href="index.php#menu">Lihat semua menu</a>
</div>
<?php else: ?>
<div class="product-grid">
<?php foreach ($products as $i => $p): ?>
<article class="product-card">
  <div class="product-photo-wrap">
<?php photo_html($p['image_url'], $p['name'], $p['category']); ?>
<span class="photo-badge">
<?= h($p['category']) ?>
</span>
<span class="photo-index">
<?= str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) ?>
</span>
</div>
  <div class="product-body">
<div class="product-caption">
<span>LOCAL SIGNATURE</span>
<span aria-hidden="true">✦</span>
</div>
<h3>
<?= h($p['name']) ?>
</h3>
<p>
<?= h($p['description']) ?>
</p>
<div class="product-bottom">
<strong>
<?= rupiah($p['price']) ?>
</strong>
<button type="button" class="product-detail" data-product="<?= h($p['name']) ?>" data-description="<?= h($p['description']) ?>" data-price="<?= h(rupiah($p['price'])) ?>" aria-label="Lihat detail <?= h($p['name']) ?>">↗</button>
</div>
</div>
</article>
<?php endforeach; ?>
</div>
<?php endif; ?>
</section>
<section class="lab-invitation panel">
<div class="lab-symbol">&lt;/&gt;</div>
<div>
<span class="eyebrow">DARI ETALASE KE BALIK LAYAR</span>
<h2>Satu toko. Dua cara membangunnya.</h2>
<p>Pelajari perbedaan autentikasi, query, dan pengelolaan produk pada versi aman dan rentan.</p>
</div>
<div class="invitation-actions">
<a href="login-aman.php" class="btn primary">◈ Coba versi aman</a>
<a href="login-rentan.php" class="btn ghost warm">⚠ Jelajahi versi rentan</a>
</div>
</section>
<script>document.addEventListener('click',event=>{const button=event.target.closest('[data-product]');if(button && window.neonAlert)neonAlert.fire({title:button.dataset.product,text:button.dataset.description+' — '+button.dataset.price,footer:'Katalog simulasi edukasi. Tidak menerima pesanan atau pembayaran.',confirmButtonText:'Kembali ke menu'});});</script>
<?php page_bottom($notice); ?>
