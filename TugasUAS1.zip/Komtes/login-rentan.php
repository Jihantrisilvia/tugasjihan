<?php
require __DIR__ . '/config.php';
start_lab_session('rentan');
// --- PROSES LOGIN RENTAN: HANYA UNTUK BELAJAR DI LOCALHOST ---
$error = '';
$username = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = posted('username');
    $password = posted('password');
    // ⚠️ VULNERABLE LINE: login diproses tanpa verifikasi CSRF token.
    try {
        // ⚠️ VULNERABLE LINE: username/password langsung menjadi bagian SQL; celah SQL Injection.
        $sql = "SELECT id, username, role FROM users WHERE username = '" . $username . "' AND password = '" . $password . "' LIMIT 1";
        // ⚠️ VULNERABLE LINE: password dicocokkan sebagai teks biasa, tanpa password_verify().
        $user = $pdo->query($sql)->fetch();
        if ($user) {
            // ⚠️ VULNERABLE LINE: identitas login disimpan tanpa session_regenerate_id().
            $_SESSION['user_id'] = (int) $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            flash('success', 'Login demo berhasil', 'Mode rentan aktif. Perhatikan penanda edukasi pada dashboard.');
            go('dashboard-rentan.php');
        }
        $error = 'Username atau password tidak valid.';
    } catch (PDOException $e) {
        $error = 'Login belum dapat diproses. Periksa input dan coba kembali.';
    }
    flash('error', 'Login belum berhasil', $error);
}
if (isset($_GET['loggedout'])) { flash('success', 'Sampai jumpa!', 'Sesi rentan sudah diakhiri.'); }
page_top('Masuk rentan', 'rentan', 'login');
?>
<section class="auth-layout">
<div class="auth-story">
<span class="eyebrow">LEARN WHAT HAPPENS BEHIND THE CODE</span>
<h1>Rasa yang sama.<br>
<span class="gradient-text">Kode yang berbeda.</span>
</h1>
<p>Kenali bagaimana query gabungan, password teks biasa, dan sesi yang lemah memengaruhi keamanan sebuah toko digital.</p>
<div class="auth-art" aria-hidden="true">
<span>🍲</span>
<span>🥤</span>
<span>🥟</span>
</div>
<ul class="feature-list">
<li>Baca baris dengan komentar VULNERABLE LINE</li>
<li>Bandingkan dengan login-aman.php</li>
<li>Gunakan data demo milik sendiri</li>
</ul>
</div>
<div class="auth-panel panel">
<span class="badge danger">⚠ VULNERABLE VERSION / EDUKASI</span>
<h2>Masuk ke lab rentan.</h2>
<p>Simulasi kelemahan autentikasi. Khusus localhost.</p>
<?php if ($error !== ''): ?>
<div class="form-error" role="status">
<?= h($error) ?>
</div>
<?php endif; ?>
<form method="post" action="login-rentan.php" data-validate>
<!-- ⚠️ VULNERABLE LINE: form tidak memiliki CSRF token. -->
<label class="field">
<span>Username</span>
<input name="username" value="<?= h($username) ?>" autocomplete="username" placeholder="Contoh: admin_rentan" required>
</label>
<label class="field" for="password">
<span>Password</span>
</label>
<div class="field password-wrap">
<input id="password" name="password" type="password" autocomplete="current-password" placeholder="Masukkan password demo" required>
<button type="button" data-password-toggle="password" aria-label="Tampilkan atau sembunyikan password" aria-pressed="false">Lihat</button>
</div>
<button class="btn primary full-width" type="submit">Masuk ke lab rentan <span>→</span>
</button>
<p class="form-hint">⚠ Form sengaja tidak dilengkapi token CSRF.</p>
</form>
<details class="demo-credentials" open>
<summary>Akun demo untuk belajar</summary>
<div class="credential-row">
<code>admin_rentan</code>
<code>RasaRentan!2026</code>
</div>
<div class="credential-row">
<code>pelanggan_rentan</code>
<code>RasaRentan!2026</code>
</div>
<p>Password kedua akun ini sengaja disimpan sebagai teks biasa di database.sql.</p>
</details>
</div>
</section>
<?php learning_labels('login'); page_bottom(); ?>
