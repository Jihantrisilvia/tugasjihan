<?php
require __DIR__ . '/config.php';
$mode = ($_GET['mode'] ?? '') === 'rentan' ? 'rentan' : 'aman';
start_lab_session($mode);
// --- LOGOUT AMAN: POST + CSRF, MENGAKHIRI SESI MODE YANG DIPILIH ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || ($mode === 'aman' && !csrf_ok())) {
    flash('error', 'Permintaan logout tidak valid', 'Gunakan tombol Keluar pada dashboard.');
    go(empty($_SESSION['user_id']) ? 'login-' . $mode . '.php' : 'dashboard-' . $mode . '.php');
}
// Mode rentan tidak memverifikasi token; sengaja mengikuti sesi demonstrasi.
$_SESSION = [];
$cookie = session_get_cookie_params();
setcookie(session_name(), '', ['expires' => time() - 42000, 'path' => $cookie['path'], 'domain' => $cookie['domain'], 'secure' => $cookie['secure'], 'httponly' => $cookie['httponly'], 'samesite' => $cookie['samesite'] ?? '']);
session_destroy();
go('login-' . $mode . '.php?loggedout=1');
