<?php
require __DIR__ . '/config.php';
start_lab_session('aman');
require_login('aman');
$mode = 'aman';
$error = '';
$editId = 0;
$form = ['name' => '', 'category' => 'Makanan', 'price' => '', 'description' => '', 'image_url' => ''];
// --- PROSES PERUBAHAN DATA AMAN ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = posted('action');
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if (!csrf_ok()) {
        $error = 'Form kedaluwarsa atau tidak sah. Muat ulang halaman sebelum mencoba kembali.';
    } elseif (!in_array($action, ['create', 'update', 'delete'], true) || ($action !== 'create' && !$id)) {
        $error = 'Permintaan tidak valid.';
    } else {
        try {
            if ($action !== 'create') {
                // AMAN: periksa owner di SERVER; menyembunyikan tombol saja tidak cukup.
                $statement = $pdo->prepare('SELECT id FROM products WHERE id = ? AND owner_id = ?');
                $statement->execute([$id, $_SESSION['user_id']]);
                if (!$statement->fetch()) {
                    flash('error', 'Akses ditolak', 'Produk tidak tersedia atau bukan milik akun ini.');
                    go('dashboard-aman.php');
                }
            }
            if ($action === 'delete') {
                // AMAN: syarat kepemilikan juga dibawa ke query perubahan; hanya lewat POST + token.
                $statement = $pdo->prepare('DELETE FROM products WHERE id = ? AND owner_id = ?');
                $statement->execute([$id, $_SESSION['user_id']]);
                flash('success', 'Produk dihapus', 'Katalog publik sudah diperbarui.');
                go('dashboard-aman.php');
            }
            $editId = $action === 'update' ? (int) $id : 0;
            foreach (array_keys($form) as $key) { $form[$key] = trim(posted($key)); }
            // AMAN: filter_input memvalidasi angka, bukan menghapus karakter lalu mengasumsikan valid.
            $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 2000000000]]);
            if ($form['name'] === '' || strlen($form['name']) > 120) { $error = 'Nama wajib diisi, maksimal 120 byte.'; }
            elseif (!in_array($form['category'], CATEGORIES, true)) { $error = 'Pilih kategori yang tersedia.'; }
            elseif ($price === false || $price === null) { $error = 'Harga harus bilangan bulat Rp 1 sampai Rp 2.000.000.000, tanpa titik/koma.'; }
            elseif ($form['description'] === '' || strlen($form['description']) > 4000) { $error = 'Deskripsi wajib diisi, maksimal 4.000 byte.'; }
            elseif ($form['image_url'] !== '' && product_image($form['image_url']) === '') { $error = 'Gunakan URL gambar HTTPS yang valid, maksimal 2.048 karakter, atau kosongkan.'; }
            else {
                // AMAN: simpan teks asli sebagai DATA; encoding dilakukan ketika merender HTML.
                if ($action === 'update') {
                    $statement = $pdo->prepare('UPDATE products SET name = ?, category = ?, price = ?, description = ?, image_url = ? WHERE id = ? AND owner_id = ?');
                    $statement->execute([$form['name'], $form['category'], $price, $form['description'], $form['image_url'], $id, $_SESSION['user_id']]);
                } else {
                    $statement = $pdo->prepare('INSERT INTO products (owner_id, name, category, price, description, image_url) VALUES (?, ?, ?, ?, ?, ?)');
                    // AMAN: owner_id berasal dari sesi, bukan field tersembunyi yang bisa diubah pengguna.
                    $statement->execute([$_SESSION['user_id'], $form['name'], $form['category'], $price, $form['description'], $form['image_url']]);
                }
                flash('success', $action === 'update' ? 'Produk diperbarui' : 'Menu baru berhasil ditambahkan!', 'Produk langsung tersedia di katalog publik.');
                go('dashboard-aman.php');
            }
        } catch (PDOException $e) { $error = 'Perubahan belum dapat disimpan. Periksa isian dan coba kembali.'; }
    }
    if ($error !== '') { flash('error', 'Periksa permintaan', $error); }
}
// --- AMBIL PRODUK UNTUK EDIT AMAN ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'edit') {
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    try {
        $statement = $pdo->prepare('SELECT * FROM products WHERE id = ? AND owner_id = ?');
        $statement->execute([$id ?: 0, $_SESSION['user_id']]);
        $product = $statement->fetch();
        if (!$product) { flash('error', 'Akses ditolak', 'Produk tidak tersedia atau bukan milik akun ini.'); go('dashboard-aman.php'); }
        $editId = (int) $product['id'];
        foreach (array_keys($form) as $key) { $form[$key] = $product[$key]; }
    } catch (PDOException $e) { $error = 'Produk belum dapat dimuat.'; flash('error', 'Gagal memuat produk', $error); }
}
// --- DAFTAR PRODUK: SEMUA BOLEH DILIHAT, HANYA PEMILIK BOLEH MENGUBAH ---
$products = [];
try {
    $statement = $pdo->prepare('SELECT p.*, u.username FROM products p JOIN users u ON u.id = p.owner_id ORDER BY p.id DESC');
    $statement->execute();
    $products = $statement->fetchAll();
} catch (PDOException $e) { flash('error', 'Data belum dapat dimuat', 'Periksa database lalu muat ulang halaman.'); }
$ownCount = count(array_filter($products, function ($p) { return (int) $p['owner_id'] === (int) $_SESSION['user_id']; }));
page_top('Dapur produk aman', $mode, 'dashboard');
?>

<section class="workspace-heading">
<div>
<span class="badge safe">◈ SECURE WORKSPACE</span>
<h1>Dapur produk<span class="teal">.</span>
</h1>
<p>Racik menu baru, kelola sajian, dan pelajari cara kerja kodenya.</p>
</div>
<div class="user-chip">
<div class="user-avatar">◈</div>
<div class="user-info">
<strong>
<?= h($_SESSION['username']) ?>
</strong>
<small>
<?= h($_SESSION['role']) ?> / ID <?= (int) $_SESSION['user_id'] ?>
</small>
</div>
<form action="logout.php?mode=<?= h($mode) ?>" method="post">
<input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<button type="submit" class="btn small ghost">Keluar ↗</button>
</form>
</div>
</section>
<div class="stats">
<div class="stat">
<span class="stat-icon">▦</span>
<div>
<small>Total menu</small>
<strong>
<?= count($products) ?>
</strong>
</div>
</div>
<div class="stat">
<span class="stat-icon">♧</span>
<div>
<small>Menu milikmu</small>
<strong>
<?= $ownCount ?>
</strong>
</div>
</div>
<div class="stat">
<span class="stat-icon">◈</span>
<div>
<small>Mode belajar</small>
<strong>
<?= $mode === 'aman' ? 'Secure' : 'Rentan' ?>
</strong>
</div>
</div>
</div>

<div class="dashboard-layout">
<section class="panel editor-panel" id="editor">
<div class="panel-heading">
<h2>
<?= $editId ? 'Edit sajian' : 'Tambah sajian baru' ?>
</h2>
<span>
<?= $editId ? '#' . $editId : '+' ?>
</span>
</div>
<p class="safe-note ">Owner berasal dari sesi, query memakai parameter, dan setiap perubahan diverifikasi dengan token CSRF.</p>
<?php if ($error !== ''): ?>
<div class="form-error" role="status">
<?= h($error) ?>
</div>
<?php endif; ?>
<form method="post" action="dashboard-<?= h($mode) ?>.php" data-validate>
<input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<input type="hidden" name="action" value="<?= $editId ? 'update' : 'create' ?>">
<input type="hidden" name="id" value="<?= $editId ?>">
<label class="field wide">
<span>Nama produk</span>
<input name="name" value="<?= h($form['name']) ?>" maxlength="120" placeholder="Contoh: Nasi Goreng Nusantara" required>
</label>
<div class="field-row wide">
<label class="field">
<span>Kategori</span>
<select name="category" required>
<?php foreach (CATEGORIES as $c): ?>
<option value="<?= h($c) ?>" <?= $form['category'] === $c ? 'selected' : '' ?>>
<?= h($c) ?>
</option>
<?php endforeach; ?>
</select>
</label>
<label class="field">
<span>Harga (Rp)</span>
<input name="price" type="number" min="1" max="2000000000" step="1" value="<?= h($form['price']) ?>" placeholder="28000" required>
<small>Angka utuh, tanpa titik/koma.</small>
</label>
</div>
<label class="field wide">
<span>Deskripsi</span>
<textarea name="description" maxlength="4000" rows="3" placeholder="Ceritakan rasa khas sajianmu…" required>
<?= h($form['description']) ?>
</textarea>
</label>
<label class="field wide">
<span>URL gambar <small style="display:inline">(opsional)</small>
</span>
<input id="image-url" type="url" name="image_url" maxlength="2048" placeholder="https://…" value="<?= h($form['image_url']) ?>">
<small>Gunakan tautan HTTPS langsung ke gambar. Kosongkan untuk ilustrasi bawaan.</small>
</label>
<div class="image-preview wide">
<span>▧<br>Pratinjau gambar sajian</span>
<img id="image-preview" alt="Pratinjau gambar produk" hidden>
</div>
<button class="btn primary full-width wide" type="submit">
<?= $editId ? 'Simpan perubahan' : '+ Tambahkan ke menu' ?>
</button>
<?php if ($editId): ?>
<a href="dashboard-<?= h($mode) ?>.php" class="btn ghost full-width wide" style="margin-top:10px">Batal edit</a>
<?php endif; ?>
</form>
</section>
<section class="panel inventory-panel">
<div class="panel-heading">
<h2>Koleksi menu</h2>
<a href="index.php#menu" class="text-link">Lihat katalog ↗</a>
</div>
<p class="inventory-note">Semua sajian dapat dilihat. Edit/hapus hanya untuk produk milik akun ini, termasuk jika role kamu admin.</p>
<?php if (!$products): ?>
<div class="empty-state">
<span>🍽️</span>
<h3>Dapur masih sepi.</h3>
<p>Tambahkan sajian pertamamu di formulir.</p>
</div>
<?php else: ?>
<div class="inventory-list">
<?php foreach ($products as $p): $isOwner = (int) $p['owner_id'] === (int) $_SESSION['user_id']; ?>
<article class="inventory-item">
<div class="inventory-image">
<?php photo_html($p['image_url'], 'Foto sajian demo', $p['category']); ?>
</div>
<div class="inventory-details">
<div class="inventory-meta">
<span>#<?= (int) $p['id'] ?>
</span>
<span>
<?= h($p['category']) ?>
</span>
<span class="owner-tag">
<?= $isOwner ? '◈ Milikmu' : '○ ' . h($p['username']) ?> / owner <?= (int) $p['owner_id'] ?>
</span>
</div>
<h3>
<?= h($p['name']) ?>
</h3>
<p>
<?= h($p['description']) ?>
</p>
</div>
<div class="inventory-side">
<strong class="inventory-price">
<?= rupiah($p['price']) ?>
</strong>
<div class="inventory-actions">
<?php if ($isOwner): ?>
<a class="action-btn" href="dashboard-aman.php?action=edit&amp;id=<?= (int) $p['id'] ?>#editor">Edit</a>
<form method="post" action="dashboard-aman.php" data-delete-form>
<input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
<button class="action-btn delete" type="submit">Hapus</button>
</form>
<?php else: ?>
<span class="muted" style="font-size:8px">Hanya lihat</span>
<?php endif; ?>
</div>
</div>
</article>
<?php endforeach; ?>
</div>
<?php endif; ?>
</section>
</div>
<script>
const imageInput=document.getElementById('image-url'),preview=document.getElementById('image-preview');
function updatePreview(){preview.hidden=true;try{const url=new URL(imageInput.value);if(url.protocol==='https:'){preview.src=url.href;}}catch(e){preview.removeAttribute('src');}}
preview.addEventListener('load',()=>{preview.hidden=false;});preview.addEventListener('error',()=>{preview.hidden=true;});imageInput.addEventListener('input',updatePreview);updatePreview();
</script>
<?php page_bottom(); ?>
