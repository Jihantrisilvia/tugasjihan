# RasaNusantara

Proyek simulasi e-commerce makanan & minuman untuk membandingkan kode PHP aman dan rentan. Khusus localhost milik sendiri. Tidak ada checkout, pembayaran, pengiriman, atau eksploitasi otomatis.

## Menjalankan di XAMPP / Laragon

1. Gunakan PHP 8.0+ dengan ekstensi `pdo_mysql`, serta MySQL 5.7+ / MariaDB 10.4+. PHP 8.x direkomendasikan untuk lab ini.
2. Ekstrak folder `rasanusantara` ke `C:\xampp\htdocs\` atau `C:\laragon\www\`.
3. Jalankan **Apache** dan **MySQL**.
4. Buka `http://localhost/phpmyadmin`, pilih **Import**, lalu import `database.sql`. File SQL membuat dan memilih database `rasanusantara` sendiri.
5. Buka `config.php` dan sesuaikan `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS`. Default lokal: `127.0.0.1`, `3306`, `rasanusantara`, `root`, password kosong. Gunakan kredensial instalasimu bila berbeda.
6. Buka **http://localhost/rasanusantara/**. Jangan membuka file PHP dengan klik ganda / `file://`.

Alternatif jika PHP dan MySQL sudah tersedia: dari folder proyek jalankan `php -S 127.0.0.1:8000`, lalu buka `http://localhost:8000/`. Import SQL dan konfigurasi koneksi tetap diperlukan. Server ini hanya untuk lokal.

Lab memeriksa IP koneksi agar hanya loopback yang diizinkan. Gunakan localhost langsung, tanpa reverse proxy, tunnel publik, atau akses IP LAN. Pada PHP development server, folder proyek menjadi document root.

## Akun demo

| Mode | Username | Password | Role | Owner ID |
|---|---|---|---|---|
| Aman | `admin_aman` | `RasaAman!2026` | admin | 1 |
| Aman | `pelanggan_aman` | `RasaAman!2026` | customer | 2 |
| Rentan | `admin_rentan` | `RasaRentan!2026` | admin | 3 |
| Rentan | `pelanggan_rentan` | `RasaRentan!2026` | customer | 4 |

Dua akun aman memakai hash bcrypt; dua akun rentan memakai teks biasa. Sesi bernama `RN_SECURE` dan `RN_VULNERABLE` terpisah. Berpindah mode memakai tautan dan membutuhkan login pada mode tujuan. Logout hanya mengakhiri mode yang dipilih.

Role disimpan sesuai skema. Untuk pelajaran ownership, kedua role boleh masuk ke dashboard dan mengelola produk sendiri. **Admin aman juga tidak boleh mengubah produk orang lain.** Produk semua pemilik terlihat karena merupakan katalog publik. Ini bukan rancangan permission toko produksi.

## Struktur

```text
rasanusantara/
  config.php
  index.php
  login-aman.php
  login-rentan.php
  dashboard-aman.php
  dashboard-rentan.php
  logout.php
  database.sql
  README.md
  assets/
    style.css
```

Tidak ada Composer, framework, npm, atau build tool. Fungsi kecil bersama untuk koneksi, sesi, output encoding, shell halaman, dan notifikasi berada di `config.php`. Proses login dan CRUD tetap ditulis pada masing-masing halaman. Semua CSS berada di satu file.

## Fitur yang tersedia

- Landing responsif dengan katalog 12 produk dummy, pencarian nama/deskripsi, dan empat filter kategori.
- Detail produk menggunakan SweetAlert2; tidak menyimulasikan pembelian sungguhan.
- Login aman/rentan dan pergantian mode di pojok navigasi.
- Tambah, edit, hapus produk; hasil langsung dibaca katalog dari database yang sama.
- Input gambar berupa **URL HTTPS**, bukan upload berkas. Pratinjau tersedia; URL boleh dikosongkan untuk ikon kategori.
- Konfirmasi hapus, notifikasi hasil login/CRUD/logout, dan error memakai SweetAlert2 bertema neon.
- Card edukasi pada setiap halaman rentan dapat dibuka dengan klik atau keyboard. Isinya definisi, prinsip, dampak, dan lokasi perbaikan pada versi aman.

## Urutan belajar tanpa payload eksploitasi

1. **Kenali alur normal.** Masuk ke mode aman. Tambahkan produk dengan nama biasa, kategori valid, harga `28000`, dan deskripsi. Pastikan produk muncul di katalog. Edit, lalu hapus produk tersebut. Perhatikan konfirmasi dan notifikasi.
2. **SQL Injection.** Bandingkan query login dua versi. Pada versi aman, `prepare()` menetapkan struktur SQL dan `execute()` mengirim nilai terpisah. Pada versi rentan, input digabung ke string SQL. Nama makanan biasa yang mengandung apostrof sudah cukup memperlihatkan mengapa query gabungan rapuh. Tidak perlu mengubah query menjadi serangan untuk memahami konsepnya.
3. **Output HTML / XSS.** Pada mode rentan, simpan nama/deskripsi dengan markup pemformatan HTML sederhana yang tidak memiliki skrip, event handler, atau tautan. Bandingkan dashboard rentan dengan katalog dan dashboard aman. Versi rentan menafsirkan markup, versi aman menampilkan karakter teks. Pembuktian ini menunjukkan perbedaan konteks render tanpa menjalankan skrip eksploitasi.
4. **Kepemilikan / IDOR.** Catat ID dan owner produk demo yang berbeda. Login sebagai pengguna lain, lalu gunakan tautan edit produk pemilik berbeda di dashboard rentan. Perhatikan server tetap menerima perubahan. Di mode aman tombolnya hanya baca; membuka alamat edit dengan ID pemilik lain juga ditolak oleh server. Jangan hanya memeriksa tampilan tombol.
5. **CSRF.** Periksa sumber form: mode aman punya hidden token acak, mode rentan tidak. Dengan DevTools, hapus atau ubah token pada form aman milik sendiri, lalu kirim: perubahan ditolak. Mode rentan menerima pengiriman tanpa token. Konfirmasi SweetAlert2 tidak menggantikan pemeriksaan server. Hapus rentan memakai GET, aman memakai POST bertoken. Tidak ada halaman atau skrip serangan lintas situs yang disertakan.
6. **Sesi dan password.** Periksa kolom password di database demo dan cookie sesi lewat DevTools. Mode aman memakai bcrypt, HttpOnly, SameSite=Lax, strict mode, dan ID sesi baru saat login. Rentan memakai plaintext, cookie tanpa HttpOnly, strict mode mati, dan ID tidak diregenerasi saat login. Untuk melihat rotasi, muat login dahulu sebelum membandingkan cookie sebelum/sesudah submit.
7. **Logout dan pemisahan mode.** Logout dari aman. Akses dashboard aman harus diarahkan kembali ke login. Sesi rentan yang sebelumnya aktif tidak memberikan akses ke dashboard aman.
8. **Reset.** Import ulang `database.sql` untuk mengembalikan 4 pengguna dan 12 produk awal. Ini menghapus semua perubahan data lab. Logout dari kedua mode sesudah reset.

Browser modern sering memberi SameSite=Lax secara default meski mode rentan tidak menetapkannya. Karena itu, request lintas situs tertentu bisa diblokir browser; keadaan ini tidak membuktikan endpoint telah memvalidasi CSRF. Kedua mode memakai origin localhost yang sama agar penyiapan sederhana: sesi terpisah bukan isolasi origin. Skrip XSS pada origin bersama tetap mempunyai dampak pada origin itu. Cookie HttpOnly mencegah pembacaan cookie lewat JavaScript, tetapi tidak mencegah seluruh tindakan yang dapat dilakukan XSS.

## Peta pembandingan kode

| Topik | Versi rentan | Versi aman |
|---|---|---|
| SQL Injection | Penggabungan input menjadi SQL | PDO native prepared statements |
| XSS | Echo mentah nama/deskripsi pada dashboard | `h()` / `htmlspecialchars()` saat render |
| Broken Authentication | Plaintext, tidak mengganti ID sesi | Bcrypt + `password_verify()`, regenerasi sesi, cookie terlindungi |
| CSRF | Form tanpa token; hapus melalui GET | POST + token sesi + `hash_equals()` |
| IDOR / akses | Edit/hapus berdasarkan ID saja | Pemeriksaan dan query dengan ID + owner dari sesi |

`htmlspecialchars()` bukan pengganti prepared statement dan tidak perlu dipakai sebelum menyimpan setiap teks. Versi aman memvalidasi bentuk/ukuran input, menyimpan teks sebagai data, lalu melakukan encoding sesuai konteks HTML. URL gambar harus lolos validasi HTTPS sebelum dipasang sebagai atribut; pesan SweetAlert memakai `text`, bukan HTML dari input pengguna.

Untuk membuat hash akun aman baru, jalankan kode PHP lokal berikut lalu gunakan hasilnya pada kolom password akun aman:

```php
echo password_hash('password-baru-milikmu', PASSWORD_BCRYPT, ['cost' => 10]);
```

Contoh ini untuk praktik manual; tidak ada fitur registrasi dalam ruang lingkup lab. Hash seed dapat diverifikasi dengan `password_verify('RasaAman!2026', $hashDariDatabase)`. Batas input password aman adalah 72 byte sesuai karakteristik bcrypt.

## Dependensi tampilan

- **SweetAlert2 v11 via jsDelivr:** satu-satunya library JavaScript, untuk seluruh notifikasi/konfirmasi. Internet diperlukan. Jika CDN gagal, operasi hapus yang dikonfirmasi UI dihentikan dan pesan status terlihat; endpoint rentan tetap sengaja tidak dilindungi server.
- **Google Fonts:** Inter dan Space Grotesk; font sistem menjadi fallback.
- **Foto stok Unsplash:** hanya ilustrasi menu, bukan jaminan representasi resep. Saat foto gagal dimuat, ikon makanan/minuman tetap tampil. Tidak ada pengambilan URL oleh server PHP.

CSS/JS tema tidak menggunakan framework. Modul PHP `pdo_mysql` merupakan ekstensi runtime, bukan dependensi frontend.

## Jika belum berjalan

- **Database belum siap / HTTP 503:** periksa MySQL, port, import SQL, serta kredensial `config.php`. Browser sengaja tidak menampilkan detail error SQL.
- **could not find driver:** aktifkan ekstensi `pdo_mysql` pada `php.ini`, lalu restart Apache/PHP.
- **404:** pastikan nama folder tepat `rasanusantara` di document root Apache.
- **Akses localhost ditolak:** buka dari komputer server sendiri dengan `http://localhost/rasanusantara/`, tanpa proxy atau tunnel.
- **Foto tidak terlihat:** periksa internet atau kosongkan URL; ikon fallback akan muncul.
- **Notifikasi tidak muncul:** pastikan JavaScript aktif dan koneksi ke CDN tersedia.
- **Harga:** masukkan angka utuh seperti `10000000`; tampilan menjadi `Rp 10.000.000`. Batas harga aman Rp 2.000.000.000, sesuai rentang tipe INT.

## Batas pembelajaran

Mode aman melindungi lima pokok yang diminta, tetapi proyek ini tetap laboratorium, bukan aplikasi siap produksi. Fitur rate limiting, MFA, reset password, audit trail, dan isolasi origin tidak disertakan. Mode rentan sengaja tetap memiliki celah, meskipun halaman publik melakukan output encoding dan query multi-statement dinonaktifkan. Jangan menerbitkan folder ini secara publik.

## Verifikasi paket

Sintaks tujuh berkas PHP dan JavaScript hasil render telah diperiksa. Pengujian pada PHP 8.3.6 dan MariaDB 10.11.14 melalui CGI mencakup login, rotasi/pemisahan sesi, CRUD, format Rupiah, validasi input, CSRF, penolakan IDOR versi aman, serta perbedaan render HTML dan akses data versi rentan. Data tes dikembalikan ke seed. Tampilan hasil render diperiksa pada desktop dan lebar ponsel 390 px. Belum diuji langsung pada instalasi XAMPP/Laragon Windows pengguna.
