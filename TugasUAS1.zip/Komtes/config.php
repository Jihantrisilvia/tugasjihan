<?php
/*
 * RasaNusantara — laboratorium lokal PHP native (PHP 8.0+ + pdo_mysql).
 * INSTALASI XAMPP / LARAGON:
 * 1. Ekstrak folder rasanusantara ke htdocs (XAMPP) atau www (Laragon).
 * 2. Jalankan Apache dan MySQL. Import database.sql melalui phpMyAdmin.
 *    SQL membuat database rasanusantara. Import ulang akan MEReset data demo.
 * 3. Sesuaikan DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS di bawah ini.
 * 4. Buka http://localhost/rasanusantara/ (jangan buka file://).
 * Akun/password demo dan panduan belajar ada di README.md.
 * Gambar memakai URL HTTPS, bukan upload berkas. Internet untuk CDN/font/foto.
 * KHUSUS localhost: jangan pasang lab rentan ini pada hosting publik.
 */

// --- KONFIGURASI DATABASE ---
const DB_HOST = '127.0.0.1';
const DB_PORT = '3306';
const DB_NAME = 'rasanusantara';
const DB_USER = 'root';
const DB_PASS = '';
const CATEGORIES = ['Makanan', 'Minuman', 'Camilan', 'Dessert'];

// --- BATAS LINGKUNGAN LAB ---
// Peer IP diperiksa, bukan Host/X-Forwarded-For yang dapat dipalsukan.
if (PHP_SAPI !== 'cli' && !in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1', '::ffff:127.0.0.1'], true)) {
    http_response_code(403);
    exit('Lab edukasi ini hanya dapat dibuka dari localhost.');
}
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('X-Frame-Options: DENY');
header('Cache-Control: no-store');

// --- KONEKSI DATABASE ---
try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        // Lab SQLi tetap ada pada query gabungan; eksekusi multi-statement dibatasi.
        PDO::MYSQL_ATTR_MULTI_STATEMENTS => false,
    ]);
} catch (PDOException $e) {
    http_response_code(503);
    // AMAN: detail koneksi/query tidak dikirim ke browser.
    ?>
<!doctype html>
<html lang="id">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>RasaNusantara · Persiapan</title>
<link rel="stylesheet" href="assets/style.css">
<main class="setup panel">
<span class="eyebrow">RASANUSANTARA / LOCAL LAB</span>
<h1>Siapkan dapurnya dulu.</h1>
<p>Koneksi database belum tersedia. Jalankan MySQL, import <code>database.sql</code>, lalu sesuaikan kredensial di <code>config.php</code>.</p>
<a class="btn primary" href="index.php">Coba lagi</a>
<p class="muted">Petunjuk lengkap ada di README.md.</p>
</main>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11">
</script>
<script>if(window.Swal){Swal.fire({icon:'info',title:'Database belum siap',text:'Periksa MySQL, hasil import, dan konfigurasi koneksi.',background:'#111827',color:'#f6f7fb',confirmButtonColor:'#14b8a6'});}</script>
</html>
<?php
    exit;
}

// --- FUNGSI KECIL BERSAMA (TETAP DALAM STRUKTUR FLAT) ---
function h($value): string { return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function rupiah($value): string { return 'Rp ' . number_format((int) $value, 0, ',', '.'); }
function go(string $path): void { header('Location: ' . $path, true, 303); exit; }
function posted(string $key): string { return isset($_POST[$key]) && is_string($_POST[$key]) ? $_POST[$key] : ''; }
function product_image($url): string {
    // URL attribute perlu validasi protokol DAN output encoding, juga pada katalog.
    $url = (string) $url;
    return strlen($url) <= 2048 && filter_var($url, FILTER_VALIDATE_URL) && strtolower((string) parse_url($url, PHP_URL_SCHEME)) === 'https' ? $url : '';
}
function start_lab_session(string $mode): void {
    // Sesi terpisah mencegah login rentan menjadi autentikasi untuk mode aman.
    session_name($mode === 'aman' ? 'RN_SECURE' : 'RN_VULNERABLE');
    ini_set('session.use_only_cookies', '1');
    if ($mode === 'aman') {
        // AMAN: strict mode menolak ID sesi arbitrer; HttpOnly menghalangi pembacaan cookie via JS.
        ini_set('session.use_strict_mode', '1');
        session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
    } else {
        // ⚠️ VULNERABLE LINE: konfigurasi lemah sengaja untuk demonstrasi sesi.
        ini_set('session.use_strict_mode', '0');
        session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => false, 'httponly' => false, 'samesite' => '']);
    }
    session_start();
    if ($mode === 'aman' && empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
}
function csrf_ok(): bool {
    return isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], posted('csrf'));
}
function flash(string $icon, string $title, string $message = ''): void {
    $_SESSION['flash'] = ['icon' => $icon, 'title' => $title, 'text' => $message];
}
function require_login(string $mode): void {
    if (empty($_SESSION['user_id'])) { flash('info', 'Masuk terlebih dahulu', 'Gunakan akun demo untuk membuka dapur produk.'); go('login-' . $mode . '.php'); }
}
function photo_html($url, string $alt, string $category = 'Makanan'): void {
    $icons = ['Makanan' => '🍲', 'Minuman' => '🥤', 'Camilan' => '🥟', 'Dessert' => '🍨'];
    ?>
<div class="food-photo">
<span class="food-placeholder" aria-hidden="true">
<?= $icons[$category] ?? '🍽️' ?>
</span>
<?php if (product_image($url) !== ''): ?>
<img src="<?= h(product_image($url)) ?>" alt="<?= h($alt) ?>" loading="lazy" decoding="async" referrerpolicy="no-referrer">
<?php endif; ?>
</div>
<?php
}
function page_top(string $title, string $mode = '', string $page = ''): void {
    ?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#090e19">
<title>
<?= h($title) ?> · RasaNusantara</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="lab-strip">
<span class="status-dot">
</span> LOCALHOST LAB <span class="strip-divider">/</span> Simulasi edukasi keamanan web <span class="strip-right">DATA DEMO • TANPA TRANSAKSI</span>
</div>
    <header class="site-header">
<a class="brand" href="index.php" aria-label="RasaNusantara beranda">
<span class="brand-icon">r<span>n</span>
<i>
</i>
</span>
<span>Rasa<span class="brand-accent">Nusantara</span>
<small>LOCAL FLAVORS. DIGITAL EXPERIENCE.</small>
</span>
</a>
<nav aria-label="Navigasi utama">
<a class="nav-link <?= $page === 'index' ? 'active' : '' ?>" href="index.php#menu">Jelajah menu</a>
<?php if ($mode !== ''): ?>
<div class="mode-switch" aria-label="Pilih mode lab">
<a class="<?= $mode === 'aman' ? 'selected secure' : '' ?>" href="<?= h($page) ?>-aman.php">◈ Aman</a>
<a class="<?= $mode === 'rentan' ? 'selected vulnerable' : '' ?>" href="<?= h($page) ?>-rentan.php">⚠ Rentan</a>
</div>
<?php else: ?>
<a class="btn small ghost" href="login-rentan.php">Lab rentan ↗</a>
<a class="btn small primary" href="login-aman.php">Masuk aman <span>→</span>
</a>
<?php endif; ?>
</nav>
</header>
    <main class="container">
<?php
}
function learning_labels(string $page): void {
    $items = [
        ['SQL Injection', 'Input pengguna ikut dibaca sebagai perintah SQL, bukan sekadar data.', 'Query dirangkai langsung dengan input. Struktur perintah dapat berubah.', 'Autentikasi atau data dapat dimanipulasi.', 'Lihat prepare() dan execute() di login-aman.php serta dashboard-aman.php.'],
        ['XSS', 'Teks yang disimpan dibaca browser sebagai HTML atau JavaScript.', 'Nama/deskripsi produk di-echo mentah di daftar produk rentan.', 'Halaman dapat diubah atau tindakan dilakukan dalam sesi pengguna.', 'Lihat h() / htmlspecialchars() pada render produk di dashboard-aman.php.'],
        ['Broken Authentication', 'Password dan identitas sesi tidak dilindungi dengan benar.', 'Password teks biasa dibandingkan langsung; ID sesi tidak diganti setelah login.', 'Kebocoran password atau penyalahgunaan sesi.', 'Lihat password_verify(), password_hash(), dan session_regenerate_id() di login-aman.php.'],
        ['CSRF', 'Browser yang sedang login dapat dipicu mengirim permintaan tanpa niat pengguna.', 'Form rentan tidak mengikat permintaan ke token sesi; hapus bahkan memakai GET.', 'Produk dapat ditambah, diubah, atau dihapus tanpa persetujuan.', 'Versi aman memerlukan POST dan csrf_ok() sebelum perubahan. SameSite hanyalah pertahanan tambahan.'],
        ['IDOR / Broken Access Control', 'ID data dipercaya tanpa memeriksa siapa pemiliknya.', 'ID di URL dipakai untuk edit/hapus tanpa owner_id.', 'Pengguna dapat mengubah atau menghapus produk pengguna lain.', 'Versi aman membatasi SELECT/UPDATE/DELETE dengan id DAN owner_id dari sesi.'],
    ];
    ?>
<section class="education" aria-label="Penanda edukasi kerentanan">
<div class="education-heading">
<span class="badge danger">⚠ MODE RENTAN • PENANDA EDUKASI</span>
<span>Klik topik untuk mempelajari celahnya</span>
</div>
<div class="lesson-grid">
<?php foreach ($items as $i => $item): if ($page === 'login' && !in_array($i, [0,2,3], true)) continue; ?>
<div class="lesson">
<button class="lesson-toggle" type="button" aria-expanded="false" aria-controls="lesson-<?= $i ?>">⚠ <?= h($item[0]) ?> <span>+</span>
</button>
<div class="lesson-content" id="lesson-<?= $i ?>" hidden>
<p>
<b>Definisi:</b> <?= h($item[1]) ?>
</p>
<p>
<b>Prinsip:</b> <?= h($item[2]) ?>
</p>
<p>
<b>Dampak:</b> <?= h($item[3]) ?>
</p>
<p>
<b>Perbaikan:</b> <?= h($item[4]) ?>
</p>
<?php if ($i === 3): ?>
<p class="muted">Browser modern biasanya menerapkan SameSite=Lax sebagai default. Kegagalan demonstrasi lintas situs tidak berarti endpoint sudah memiliki validasi CSRF.</p>
<?php endif; ?>
</div>
</div>
<?php endforeach; ?>
</div>
</section>
<?php
}
function page_bottom(?array $notice = null): void {
    if ($notice === null && isset($_SESSION['flash'])) { $notice = $_SESSION['flash']; unset($_SESSION['flash']); }
    ?>
</main>
<footer class="site-footer">
<a class="footer-brand" href="index.php">r<span>n</span> / RasaNusantara</a>
<p>Rasa lokal, pengalaman digital. <span>Proyek simulasi edukasi.</span>
</p>
<span class="footer-meta">NATIVE PHP × MYSQL / LOCAL ONLY</span>
</footer>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11">
</script>
<script>
    // Semua notifikasi dan konfirmasi memakai SweetAlert2, bukan alert()/confirm().
    const notice = <?= json_encode($notice, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE) ?>;
    if(window.Swal){
      window.neonAlert = Swal.mixin({background:'#111827',color:'#f5f7fc',confirmButtonColor:'#14b8a6',cancelButtonColor:'#374151',customClass:{popup:'neon-popup',confirmButton:'neon-confirm'},buttonsStyling:true});
      if(notice) neonAlert.fire(notice);
    }
    document.querySelectorAll('.lesson-toggle').forEach(button=>button.addEventListener('click',()=>{const open=button.getAttribute('aria-expanded')==='true';button.setAttribute('aria-expanded',String(!open));document.getElementById(button.getAttribute('aria-controls')).hidden=open;button.querySelector('span').textContent=open?'+':'−';}));
    document.querySelectorAll('img').forEach(img=>{img.addEventListener('error',()=>{img.hidden=true;});if(img.complete && img.naturalWidth===0)img.hidden=true;});
    document.querySelectorAll('[data-password-toggle]').forEach(button=>button.addEventListener('click',()=>{const input=document.getElementById(button.dataset.passwordToggle);input.type=input.type==='password'?'text':'password';button.textContent=input.type==='password'?'Lihat':'Sembunyikan';button.setAttribute('aria-pressed',String(input.type==='text'));}));
    document.querySelectorAll('[data-delete-form]').forEach(form=>form.addEventListener('submit',async event=>{event.preventDefault();if(!window.neonAlert){document.getElementById('cdn-status').hidden=false;return;}const answer=await neonAlert.fire({icon:'warning',title:'Hapus produk ini?',text:'Produk akan dihapus dari katalog demo.',showCancelButton:true,confirmButtonText:'Ya, hapus',cancelButtonText:'Batal'});if(answer.isConfirmed)form.submit();}));
    document.querySelectorAll('[data-delete-link]').forEach(link=>link.addEventListener('click',async event=>{event.preventDefault();if(!window.neonAlert){document.getElementById('cdn-status').hidden=false;return;}const answer=await neonAlert.fire({icon:'warning',title:'Hapus produk ini?',text:'Mode rentan: server hanya memeriksa ID, tanpa kepemilikan.',showCancelButton:true,confirmButtonText:'Hapus data demo',cancelButtonText:'Batal'});if(answer.isConfirmed)location.href=link.href;}));
    // Validasi browser bawaan dimatikan agar pesan konsisten, server tetap otoritatif.
    document.querySelectorAll('form[data-validate]').forEach(form=>{form.noValidate=true;form.addEventListener('submit',event=>{if(!form.checkValidity()){event.preventDefault();const bad=form.querySelector(':invalid');bad?.focus();if(window.neonAlert)neonAlert.fire({icon:'warning',title:'Periksa isian formulir',text:bad?.validationMessage || 'Lengkapi isian terlebih dahulu.'});}});});
    </script>
<p id="cdn-status" class="cdn-status" hidden>SweetAlert2 belum dimuat. Hubungkan internet dan muat ulang untuk konfirmasi hapus.</p>
<noscript>
<p class="cdn-status">Aktifkan JavaScript agar penjelasan edukasi dan SweetAlert2 dapat digunakan.</p>
</noscript>
</body>
</html>
<?php
}
