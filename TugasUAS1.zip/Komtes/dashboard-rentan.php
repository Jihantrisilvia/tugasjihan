<?php
require __DIR__ . '/config.php';
start_lab_session('rentan');
require_login('rentan');
$mode = 'rentan';
$error = '';
$editId = 0;
$form = ['name' => '', 'category' => 'Makanan', 'price' => '', 'description' => '', 'image_url' => ''];
// --- HAPUS RENTAN: ID DI URL, TANPA OTORISASI PEMILIK ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'delete') {
    $id = (int) ($_GET['id'] ?? 0);
    try {
        // ⚠️ VULNERABLE LINE: perubahan data lewat GET; tidak ada CSRF token dan owner_id (CSRF + IDOR).
        $affected = $pdo->exec('DELETE FROM products WHERE id = ' . $id);
        flash($affected ? 'success' : 'info', $affected ? 'Produk demo dihapus' : 'Produk tidak ditemukan', 'Mode rentan tidak memeriksa kepemilikan.');
        go('dashboard-rentan.php');
    } catch (PDOException $e) { $error = 'Produk belum dapat dihapus.'; flash('error', 'Hapus belum berhasil', $error); }
}
// --- TAMBAH / EDIT RENTAN ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = posted('action');
    $id = (int) posted('id');
    $editId = $action === 'update' ? $id : 0;
    foreach (array_keys($form) as $key) { $form[$key] = posted($key); }
    // Cast ID/harga hanya agar demo IDOR dan SQLi teks mudah dibedakan; ini BUKAN validasi lengkap.
    $price = (int) posted('price');
    $owner = (int) $_SESSION['user_id'];
    try {
        // ⚠️ VULNERABLE LINE: tidak ada validasi CSRF token sebelum perubahan data.
        if ($action === 'update') {
            // ⚠️ VULNERABLE LINE: query gabungan input; UPDATE berdasarkan id saja, tanpa owner_id (SQLi + IDOR).
            $sql = "UPDATE products SET name='" . $form['name'] . "', category='" . $form['category'] . "', price=" . $price . ", description='" . $form['description'] . "', image_url='" . $form['image_url'] . "' WHERE id=" . $id;
        } elseif ($action === 'create') {
            // ⚠️ VULNERABLE LINE: input teks langsung disambung menjadi perintah INSERT (SQL Injection).
            $sql = "INSERT INTO products (owner_id,name,category,price,description,image_url) VALUES (" . $owner . ", '" . $form['name'] . "', '" . $form['category'] . "', " . $price . ", '" . $form['description'] . "', '" . $form['image_url'] . "')";
        } else { throw new RuntimeException('Invalid action'); }
        $pdo->exec($sql);
        flash('success', $action === 'update' ? 'Produk demo diperbarui' : 'Produk demo ditambahkan', 'Bandingkan tampilan mentah di sini dengan output aman di katalog publik.');
        go('dashboard-rentan.php');
    } catch (PDOException $e) { $error = 'Perubahan gagal diproses. Query gabungan rentan rusak akibat input teks.'; }
    catch (RuntimeException $e) { $error = 'Permintaan tidak valid.'; }
    if ($error !== '') { flash('error', 'Simpan belum berhasil', $error); }
}
// --- AMBIL PRODUK UNTUK EDIT RENTAN ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'edit') {
    $id = (int) ($_GET['id'] ?? 0);
    try {
        // ⚠️ VULNERABLE LINE: ID dari URL dipakai tanpa memastikan pemilik data (IDOR).
        $product = $pdo->query('SELECT * FROM products WHERE id = ' . $id)->fetch();
        if (!$product) { flash('info', 'Produk tidak ditemukan'); go('dashboard-rentan.php'); }
        $editId = (int) $product['id'];
        foreach (array_keys($form) as $key) { $form[$key] = $product[$key]; }
    } catch (PDOException $e) { $error = 'Produk belum dapat dimuat.'; flash('error', 'Gagal memuat produk', $error); }
}
// --- DAFTAR PRODUK LAB ---
$products = [];
try { $products = $pdo->query('SELECT p.*, u.username FROM products p JOIN users u ON u.id = p.owner_id ORDER BY p.id DESC')->fetchAll(); }
catch (PDOException $e) { flash('error', 'Data belum dapat dimuat', 'Periksa database lalu muat ulang halaman.'); }
$ownCount = count(array_filter($products, function ($p) { return (int) $p['owner_id'] === (int) $_SESSION['user_id']; }));
page_top('Dapur produk rentan', $mode, 'dashboard');
?>

<section class="workspace-heading">
<div>
<span class="badge danger">⚠ VULNERABLE WORKSPACE / EDUKASI</span>
<h1>Dapur produk<span class="teal">.</span>
</h1>
<p>Racik menu baru, kelola sajian, dan pelajari cara kerja kodenya.</p>
</div>
<div class="user-chip">
<div class="user-avatar">◈</div>
<div class="user-info">
<strong>
<?= h($_SESSION['username']) ?>
</strong>
<small>
<?= h($_SESSION['role']) ?> / ID <?= (int) $_SESSION['user_id'] ?>
</small>
</div>
<form action="logout.php?mode=<?= h($mode) ?>" method="post">
<!-- ⚠️ VULNERABLE LINE: tidak ada token CSRF. -->
<button type="submit" class="btn small ghost">Keluar ↗</button>
</form>
</div>
</section>
<div class="stats">
<div class="stat">
<span class="stat-icon">▦</span>
<div>
<small>Total menu</small>
<strong>
<?= count($products) ?>
</strong>
</div>
</div>
<div class="stat">
<span class="stat-icon">♧</span>
<div>
<small>Menu milikmu</small>
<strong>
<?= $ownCount ?>
</strong>
</div>
</div>
<div class="stat">
<span class="stat-icon">◈</span>
<div>
<small>Mode belajar</small>
<strong>
<?= $mode === 'aman' ? 'Secure' : 'Rentan' ?>
</strong>
</div>
</div>
</div>
<div class="dashboard-education">
<?php learning_labels('dashboard'); ?>
</div>
<div class="dashboard-layout">
<section class="panel editor-panel" id="editor">
<div class="panel-heading">
<h2>
<?= $editId ? 'Edit sajian' : 'Tambah sajian baru' ?>
</h2>
<span>
<?= $editId ? '#' . $editId : '+' ?>
</span>
</div>
<p class="safe-note unsafe-note">Input query dan output nama/deskripsi sengaja tidak dilindungi. Gunakan hanya untuk belajar dengan data demo.</p>
<?php if ($error !== ''): ?>
<div class="form-error" role="status">
<?= h($error) ?>
</div>
<?php endif; ?>
<form method="post" action="dashboard-<?= h($mode) ?>.php" data-validate>
<!-- ⚠️ VULNERABLE LINE: tidak ada token CSRF. -->
<input type="hidden" name="action" value="<?= $editId ? 'update' : 'create' ?>">
<input type="hidden" name="id" value="<?= $editId ?>">
<label class="field wide">
<span>Nama produk</span>
<input name="name" value="<?= h($form['name']) ?>" maxlength="120" placeholder="Contoh: Nasi Goreng Nusantara" required>
</label>
<div class="field-row wide">
<label class="field">
<span>Kategori</span>
<select name="category" required>
<?php foreach (CATEGORIES as $c): ?>
<option value="<?= h($c) ?>" <?= $form['category'] === $c ? 'selected' : '' ?>>
<?= h($c) ?>
</option>
<?php endforeach; ?>
</select>
</label>
<label class="field">
<span>Harga (Rp)</span>
<input name="price" type="number" min="1" max="2000000000" step="1" value="<?= h($form['price']) ?>" placeholder="28000" required>
<small>Angka utuh, tanpa titik/koma.</small>
</label>
</div>
<label class="field wide">
<span>Deskripsi</span>
<textarea name="description" maxlength="4000" rows="3" placeholder="Ceritakan rasa khas sajianmu…" required>
<?= h($form['description']) ?>
</textarea>
</label>
<label class="field wide">
<span>URL gambar <small style="display:inline">(opsional)</small>
</span>
<input id="image-url" type="url" name="image_url" maxlength="2048" placeholder="https://…" value="<?= h($form['image_url']) ?>">
<small>Gunakan tautan HTTPS langsung ke gambar. Kosongkan untuk ilustrasi bawaan.</small>
</label>
<div class="image-preview wide">
<span>▧<br>Pratinjau gambar sajian</span>
<img id="image-preview" alt="Pratinjau gambar produk" hidden>
</div>
<button class="btn primary full-width wide" type="submit">
<?= $editId ? 'Simpan perubahan' : '+ Tambahkan ke menu' ?>
</button>
<?php if ($editId): ?>
<a href="dashboard-<?= h($mode) ?>.php" class="btn ghost full-width wide" style="margin-top:10px">Batal edit</a>
<?php endif; ?>
</form>
</section>
<section class="panel inventory-panel">
<div class="panel-heading">
<h2>Koleksi menu</h2>
<a href="index.php#menu" class="text-link">Lihat katalog ↗</a>
</div>
<p class="inventory-note">Semua sajian dapat diedit/dihapus tanpa cek owner_id. Nama dan deskripsi di bawah dirender sebagai HTML mentah.</p>
<?php if (!$products): ?>
<div class="empty-state">
<span>🍽️</span>
<h3>Dapur masih sepi.</h3>
<p>Tambahkan sajian pertamamu di formulir.</p>
</div>
<?php else: ?>
<div class="inventory-list">
<?php foreach ($products as $p): $isOwner = (int) $p['owner_id'] === (int) $_SESSION['user_id']; ?>
<article class="inventory-item">
<div class="inventory-image">
<?php photo_html($p['image_url'], 'Foto sajian demo', $p['category']); ?>
</div>
<div class="inventory-details">
<div class="inventory-meta">
<span>#<?= (int) $p['id'] ?>
</span>
<span>
<?= h($p['category']) ?>
</span>
<span class="owner-tag">
<?= $isOwner ? '◈ Milikmu' : '○ ' . h($p['username']) ?> / owner <?= (int) $p['owner_id'] ?>
</span>
</div>
<h3>
<?php // ⚠️ VULNERABLE LINE: echo HTML mentah dari database (stored XSS).
 echo $p['name']; ?>
</h3>
<p>
<?php // ⚠️ VULNERABLE LINE: deskripsi ditampilkan tanpa htmlspecialchars (stored XSS).
 echo $p['description']; ?>
</p>
</div>
<div class="inventory-side">
<strong class="inventory-price">
<?= rupiah($p['price']) ?>
</strong>
<div class="inventory-actions">
<!-- ⚠️ VULNERABLE LINE: semua produk memiliki link edit/hapus tanpa otorisasi owner di server. -->
<a class="action-btn" href="dashboard-rentan.php?action=edit&amp;id=<?= (int) $p['id'] ?>#editor">Edit</a>
<a class="action-btn delete" href="dashboard-rentan.php?action=delete&amp;id=<?= (int) $p['id'] ?>" data-delete-link>Hapus</a>
</div>
</div>
</article>
<?php endforeach; ?>
</div>
<?php endif; ?>
</section>
</div>
<script>
const imageInput=document.getElementById('image-url'),preview=document.getElementById('image-preview');
function updatePreview(){preview.hidden=true;try{const url=new URL(imageInput.value);if(url.protocol==='https:'){preview.src=url.href;}}catch(e){preview.removeAttribute('src');}}
preview.addEventListener('load',()=>{preview.hidden=false;});preview.addEventListener('error',()=>{preview.hidden=true;});imageInput.addEventListener('input',updatePreview);updatePreview();
</script>
<?php page_bottom(); ?>
