<?php
require __DIR__ . '/config.php';
start_lab_session('aman');
require_login('aman');
if (($_SESSION['role'] ?? '') !== 'admin') { go('dashboard-customer.php'); }
$mode = 'aman';
$error = '';
$editId = 0;
$form = ['name' => '', 'category' => 'Makanan', 'price' => '', 'stock' => '20', 'description' => '', 'image_url' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array(posted('action'), ['confirm_order','reject_order'], true)) {
    if (!csrf_ok()) { flash('error', 'Form tidak sah', 'Muat ulang dashboard.'); go('dashboard-aman.php'); }
    $orderId = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if (!$orderId) { flash('error', 'Pesanan tidak valid'); go('dashboard-aman.php'); }
    try {
        $pdo->beginTransaction();
        $statement = $pdo->prepare('SELECT status FROM orders WHERE id=? FOR UPDATE');
        $statement->execute([$orderId]);
        $status = $statement->fetchColumn();
        if ($status !== 'pending') { throw new RuntimeException('Pesanan sudah diproses.'); }
        if (posted('action') === 'confirm_order') {
            $statement = $pdo->prepare('SELECT product_id,quantity FROM order_items WHERE order_id=? ORDER BY product_id');
            $statement->execute([$orderId]);
            $reduce = $pdo->prepare('UPDATE products SET stock=stock-? WHERE id=? AND stock>=?');
            foreach ($statement->fetchAll() as $item) {
                if (!$item['product_id']) { throw new RuntimeException('Salah satu menu telah dihapus. Tolak pesanan ini.'); }
                $reduce->execute([$item['quantity'], $item['product_id'], $item['quantity']]);
                if ($reduce->rowCount() !== 1) { throw new RuntimeException('Stok tidak cukup untuk verifikasi pesanan.'); }
            }
        }
        $statement = $pdo->prepare('UPDATE orders SET status=?, reviewed_at=NOW() WHERE id=?');
        $statement->execute([posted('action') === 'confirm_order' ? 'confirmed' : 'rejected', $orderId]);
        $pdo->commit();
        flash('success', 'Pesanan diperbarui', posted('action') === 'confirm_order' ? 'Pesanan dikonfirmasi dan stok berkurang.' : 'Pesanan ditolak; stok tidak berubah.');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        flash('error', 'Verifikasi gagal', $e instanceof RuntimeException ? $e->getMessage() : 'Coba kembali.');
    }
    go('dashboard-aman.php#orders');
}
// --- PROSES PERUBAHAN DATA AMAN ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = posted('action');
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if (!csrf_ok()) {
        $error = 'Form kedaluwarsa atau tidak sah. Muat ulang halaman sebelum mencoba kembali.';
    } elseif (!in_array($action, ['create', 'update', 'delete'], true) || ($action !== 'create' && !$id)) {
        $error = 'Permintaan tidak valid.';
    } else {
        try {
            if ($action !== 'create') {
                // Hanya admin yang dapat mencapai aksi ini; pastikan produk masih ada.
                $statement = $pdo->prepare('SELECT id FROM products WHERE id = ?');
                $statement->execute([$id]);
                if (!$statement->fetch()) {
                    flash('error', 'Menu tidak ditemukan');
                    go('dashboard-aman.php');
                }
            }
            if ($action === 'delete') {
                // Hapus hanya melalui POST bertoken setelah pesanan tertunda selesai.
                $statement = $pdo->prepare("SELECT COUNT(*) FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.product_id=? AND o.status='pending'");
                $statement->execute([$id]);
                if ($statement->fetchColumn() > 0) { flash('error', 'Menu masih dipesan', 'Proses atau tolak pesanan tertunda sebelum menghapus menu.'); go('dashboard-aman.php'); }
                $statement = $pdo->prepare('DELETE FROM products WHERE id = ?');
                $statement->execute([$id]);
                flash('success', 'Produk dihapus', 'Katalog publik sudah diperbarui.');
                go('dashboard-aman.php');
            }
            $editId = $action === 'update' ? (int) $id : 0;
            foreach (array_keys($form) as $key) { $form[$key] = trim(posted($key)); }
            // AMAN: filter_input memvalidasi angka, bukan menghapus karakter lalu mengasumsikan valid.
            $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 2000000000]]);
            $stock = filter_input(INPUT_POST, 'stock', FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 1000000]]);

            // AMAN: Validasi dan penanganan upload berkas gambar secara ketat
            if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] !== UPLOAD_ERR_NO_FILE) {
                if ($_FILES['image_file']['error'] !== UPLOAD_ERR_OK) {
                    $error = 'Terjadi kesalahan saat mengunggah berkas gambar.';
                } elseif ($_FILES['image_file']['size'] > 2 * 1024 * 1024) {
                    // AMAN: Batasi ukuran berkas (maksimal 2MB)
                    $error = 'Ukuran berkas gambar maksimal 2MB.';
                } else {
                    $allowedExts = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
                    $allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
                    $tmpName = $_FILES['image_file']['tmp_name'];
                    $ext = strtolower(pathinfo($_FILES['image_file']['name'], PATHINFO_EXTENSION));

                    // 1. Validasi whitelist ekstensi berkas
                    if (!in_array($ext, $allowedExts, true)) {
                        $error = 'Format berkas tidak diizinkan. Hanya JPG, PNG, WEBP, dan GIF.';
                    } else {
                        // 2. Validasi tipe MIME asli (magic bytes) lewat Fileinfo
                        $finfo = finfo_open(FILEINFO_MIME_TYPE);
                        $mime = finfo_file($finfo, $tmpName);
                        finfo_close($finfo);

                        if (!in_array($mime, $allowedMimes, true)) {
                            $error = 'Tipe konten berkas tidak valid atau bukan gambar asli.';
                        } else {
                            // 3. Validasi integritas gambar dengan getimagesize()
                            $imageInfo = @getimagesize($tmpName);
                            if ($imageInfo === false) {
                                $error = 'Berkas bukan gambar yang valid atau mengalami kerusakan.';
                            } else {
                                // 4. Buat nama berkas acak yang aman untuk mencegah Path Traversal & Penimpaan berkas
                                $uploadDir = __DIR__ . '/uploads';
                                if (!is_dir($uploadDir)) {
                                    mkdir($uploadDir, 0755, true);
                                }
                                $safeFilename = 'img_' . bin2hex(random_bytes(16)) . '.' . $ext;
                                $targetPath = $uploadDir . '/' . $safeFilename;

                                if (move_uploaded_file($tmpName, $targetPath)) {
                                    $form['image_url'] = 'uploads/' . $safeFilename;
                                } else {
                                    $error = 'Gagal menyimpan berkas ke server.';
                                }
                            }
                        }
                    }
                }
            }

            if ($error === '') {
                if ($form['name'] === '' || strlen($form['name']) > 120) { $error = 'Nama wajib diisi, maksimal 120 byte.'; }
                elseif (!in_array($form['category'], CATEGORIES, true)) { $error = 'Pilih kategori yang tersedia.'; }
                elseif ($price === false || $price === null) { $error = 'Harga harus bilangan bulat Rp 1 sampai Rp 2.000.000.000, tanpa titik/koma.'; }
                elseif ($stock === false || $stock === null) { $error = 'Stok harus bilangan bulat 0 sampai 1.000.000.'; }
                elseif ($form['description'] === '' || strlen($form['description']) > 4000) { $error = 'Deskripsi wajib diisi, maksimal 4.000 byte.'; }
                elseif ($form['image_url'] !== '' && product_image($form['image_url']) === '') { $error = 'Gunakan URL gambar HTTPS yang valid, berkas upload lokal yang sah, atau kosongkan.'; }
                else {
                    // AMAN: simpan teks asli sebagai DATA; encoding dilakukan ketika merender HTML.
                    if ($action === 'update') {
                        $statement = $pdo->prepare('UPDATE products SET name = ?, category = ?, price = ?, stock = ?, description = ?, image_url = ? WHERE id = ?');
                        $statement->execute([$form['name'], $form['category'], $price, $stock, $form['description'], $form['image_url'], $id]);
                    } else {
                        $statement = $pdo->prepare('INSERT INTO products (owner_id, name, category, price, stock, description, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)');
                        // AMAN: owner_id berasal dari sesi, bukan field tersembunyi yang bisa diubah pengguna.
                        $statement->execute([$_SESSION['user_id'], $form['name'], $form['category'], $price, $stock, $form['description'], $form['image_url']]);
                    }
                    flash('success', $action === 'update' ? 'Produk diperbarui' : 'Menu baru berhasil ditambahkan!', 'Produk langsung tersedia di katalog publik.');
                    go('dashboard-aman.php');
                }
            }
        } catch (PDOException $e) { $error = 'Perubahan belum dapat disimpan. Periksa isian dan coba kembali.'; }
    }
    if ($error !== '') {
        flash('error', 'Periksa permintaan', $error);
        go('dashboard-aman.php');
    }
}
// --- AMBIL PRODUK UNTUK EDIT AMAN ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'edit') {
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    try {
        $statement = $pdo->prepare('SELECT * FROM products WHERE id = ?');
        $statement->execute([$id ?: 0]);
        $product = $statement->fetch();
        if (!$product) { flash('error', 'Menu tidak ditemukan', 'Produk tidak tersedia.'); go('dashboard-aman.php'); }
        $editId = (int) $product['id'];
        foreach (array_keys($form) as $key) { $form[$key] = $product[$key]; }
    } catch (PDOException $e) { $error = 'Produk belum dapat dimuat.'; flash('error', 'Gagal memuat produk', $error); }
}
// --- DAFTAR PRODUK UNTUK ADMIN ---
$products = [];
try {
    $statement = $pdo->prepare('SELECT p.*, u.username FROM products p JOIN users u ON u.id = p.owner_id ORDER BY p.id DESC');
    $statement->execute();
    $products = $statement->fetchAll();
} catch (PDOException $e) { flash('error', 'Data belum dapat dimuat', 'Periksa database lalu muat ulang halaman.'); }
$menuCount = count($products);
$orders = $pdo->query('SELECT * FROM orders ORDER BY created_at DESC, id DESC LIMIT 100')->fetchAll();
$orderItems = [];
foreach ($pdo->query('SELECT * FROM order_items ORDER BY id')->fetchAll() as $item) { $orderItems[$item['order_id']][] = $item; }
$pendingByProduct = [];
foreach ($pdo->query("SELECT oi.product_id,SUM(oi.quantity) AS qty FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.status='pending' GROUP BY oi.product_id")->fetchAll() as $row) { $pendingByProduct[$row['product_id']] = (int) $row['qty']; }
page_top('Panel admin', $mode, 'dashboard');
?>

<section class="workspace-heading">
<div>
<span class="eyebrow">PANEL ADMIN KAWAN SANTAP</span>
<h1>Panel admin<span class="teal">.</span>
</h1>
<p>Racik menu baru dan perbarui koleksi sajian favoritmu.</p>
</div>
<div class="user-chip">
<div class="user-avatar"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i></div>
<div class="user-info">
<strong>
<?= h($_SESSION['username']) ?>
</strong>
<small>
<?= h($_SESSION['role']) ?> / ID <?= (int) $_SESSION['user_id'] ?>
</small>
</div>
<form action="logout-aman.php" method="post">
<input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<button type="submit" class="btn small ghost">Keluar ↗</button>
</form>
</div>
</section>
<div class="stats">
<div class="stat">
<span class="stat-icon">▦</span>
<div>
<small>Total menu</small>
<strong>
<?= count($products) ?>
</strong>
</div>
</div>
<div class="stat">
<span class="stat-icon">♧</span>
<div>
<small>Total menu</small>
<strong>
<?= $menuCount ?>
</strong>
</div>
</div>
<div class="stat">
<span class="stat-icon">◈</span>
<div>
<small>Kategori menu</small>
<strong>
<?= count(CATEGORIES) ?>
</strong>
</div>
</div>
</div>
<div class="dashboard-education">
<?php learning_labels('dashboard', 'aman'); ?>
</div>
<section class="panel order-panel" id="orders"><div class="panel-heading"><h2>Pesanan masuk</h2><span><?= count($orders) ?> pesanan terbaru</span></div>
<p>Stok berkurang saat pesanan dikonfirmasi. Pesanan yang ditolak tidak mengubah stok.</p>
<?php if (!$orders): ?><p>Belum ada pesanan.</p><?php endif; ?>
<div class="order-list">
<?php foreach ($orders as $order): $waDigits = preg_replace('/\D/', '', $order['whatsapp']); $waNumber = str_starts_with($waDigits, '0') ? '62' . substr($waDigits, 1) : $waDigits; ?>
<article class="order-card">
  <div class="order-card-head"><strong><?= h($order['order_code']) ?></strong><span class="order-status <?= h($order['status']) ?>"><?= h($order['status']) ?></span></div>
  <p><?= h($order['customer_name']) ?> · <a href="https://wa.me/<?= h($waNumber) ?>" target="_blank" rel="noopener"><?= h($order['whatsapp']) ?></a> · <?= h($order['created_at']) ?></p>
  <p>Alamat <span class="address-source" data-source="<?= $order['latitude'] !== null ? 'gps' : 'manual' ?>"><?= $order['latitude'] !== null ? 'GPS terlampir' : 'Diisi manual' ?></span>: <?= nl2br(h($order['address'])) ?></p>
  <?php if ($order['latitude'] !== null): ?><p><a href="https://www.openstreetmap.org/?mlat=<?= h($order['latitude']) ?>&amp;mlon=<?= h($order['longitude']) ?>#map=17/<?= h($order['latitude']) ?>/<?= h($order['longitude']) ?>" target="_blank" rel="noopener">Lihat titik lokasi ↗</a></p><?php endif; ?>
  <ul><?php foreach ($orderItems[$order['id']] ?? [] as $item): ?><li><?= h($item['product_name']) ?> × <?= (int) $item['quantity'] ?> = <?= rupiah($item['subtotal']) ?></li><?php endforeach; ?></ul>
  <p><strong><?= rupiah($order['total']) ?></strong> · <?= h(strtoupper($order['payment_method'])) ?><?php if ($order['proof_path']): ?> · <a href="proof.php?order=<?= (int) $order['id'] ?>" target="_blank" rel="noopener">Lihat bukti pembayaran ↗</a><?php endif; ?></p>
  <?php if ($order['status'] === 'pending'): ?><div class="order-actions"><form method="post" action="dashboard-aman.php"><input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="confirm_order"><input type="hidden" name="id" value="<?= (int) $order['id'] ?>"><button class="btn small primary" type="submit">Konfirmasi & kurangi stok</button></form><form method="post" action="dashboard-aman.php"><input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="reject_order"><input type="hidden" name="id" value="<?= (int) $order['id'] ?>"><button class="btn small ghost" type="submit">Tolak</button></form></div><?php endif; ?>
</article>
<?php endforeach; ?>
</div></section>
<div class="dashboard-layout">
<section class="panel editor-panel" id="editor">
<div class="panel-heading">
<h2>
<?= $editId ? 'Edit sajian' : 'Tambah sajian baru' ?>
</h2>
<span>
<?= $editId ? '#' . $editId : '+' ?>
</span>
</div>
<p class="editor-help">Lengkapi informasi sajian agar mudah ditemukan di katalog.</p>
<?php if ($error !== ''): ?>
<div class="form-error" role="status">
<?= h($error) ?>
</div>
<?php endif; ?>
<form method="post" action="dashboard-<?= h($mode) ?>.php" enctype="multipart/form-data" data-validate>
<input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<input type="hidden" name="action" value="<?= $editId ? 'update' : 'create' ?>">
<input type="hidden" name="id" value="<?= $editId ?>">
<label class="field wide">
<span>Nama produk</span>
<input name="name" value="<?= h($form['name']) ?>" maxlength="120" placeholder="Contoh: Nasi Goreng Nusantara" required>
</label>
<div class="field-row wide">
<label class="field">
<span>Kategori</span>
<select name="category" required>
<?php foreach (CATEGORIES as $c): ?>
<option value="<?= h($c) ?>" <?= $form['category'] === $c ? 'selected' : '' ?>>
<?= h($c) ?>
</option>
<?php endforeach; ?>
</select>
</label>
<label class="field">
<span>Harga (Rp)</span>
<input name="price" type="number" min="1" max="2000000000" step="1" value="<?= h($form['price']) ?>" placeholder="28000" required>
<small>Angka utuh, tanpa titik/koma.</small>
</label>
<label class="field"><span>Stok porsi</span><input name="stock" type="number" min="0" max="1000000" step="1" value="<?= h($form['stock']) ?>" required></label>
</div>
<label class="field wide">
<span>Deskripsi</span>
<textarea name="description" maxlength="4000" rows="3" placeholder="Ceritakan rasa khas sajianmu…" required>
<?= h($form['description']) ?>
</textarea>
</label>
<label class="field wide">
<span>URL gambar <small style="display:inline">(opsional)</small></span>
<input id="image-url" type="text" name="image_url" maxlength="2048" placeholder="https://… atau uploads/…" value="<?= h($form['image_url']) ?>">
<small>Gunakan tautan HTTPS langsung atau jalur upload berkas. Kosongkan untuk ikon bawaan.</small>
</label>
<div class="field wide">
<span>Upload berkas gambar <small style="display:inline">(opsional / alternatif)</small></span>
<!-- AMAN: membatasi pemilihan berkas hanya pada format gambar yang aman -->
<div class="file-picker"><input id="image-file" type="file" name="image_file" accept=".jpg,.jpeg,.png,.webp,.gif,image/jpeg,image/png,image/webp,image/gif"><label for="image-file" class="file-picker-button"><i class="fa-solid fa-cloud-arrow-up" aria-hidden="true"></i> Pilih gambar</label><span class="file-picker-name" data-file-name>Belum ada berkas dipilih</span></div>
<small>Hanya format gambar yang diizinkan (JPG, PNG, WEBP, GIF), maks 2MB. Nama berkas diacak otomatis di server.</small>
</div>
<div class="review-card wide">
  <div class="review-header">
    <span class="review-title">Pratinjau &amp; Review Gambar</span>
    <span id="preview-source-badge" class="badge neutral">Belum ada gambar</span>
  </div>
  <div class="image-preview" id="image-preview-container">
    <span id="preview-placeholder">▧<br>Pratinjau gambar sajian</span>
    <img id="image-preview" alt="Pratinjau gambar produk" hidden>
  </div>
  <div id="file-review-box" class="file-review-box" hidden>
    <div class="review-row">
      <span class="review-label">Nama berkas:</span>
      <strong id="review-filename" class="review-val">-</strong>
    </div>
    <div class="review-row">
      <span class="review-label">Ukuran berkas:</span>
      <span id="review-filesize" class="review-val">-</span>
    </div>
    <div class="review-row">
      <span class="review-label">Tipe MIME:</span>
      <span id="review-filetype" class="review-val">-</span>
    </div>
    <div id="review-security-verdict" class="review-verdict"></div>
    <button type="button" id="btn-clear-file" class="btn small ghost full-width" style="margin-top:10px">✕ Batalkan pilihan berkas</button>
  </div>
</div>
<button class="btn primary full-width wide" type="submit">
<?= $editId ? 'Simpan perubahan' : '+ Tambahkan ke menu' ?>
</button>
<?php if ($editId): ?>
<a href="dashboard-<?= h($mode) ?>.php" class="btn ghost full-width wide" style="margin-top:10px">Batal edit</a>
<?php endif; ?>
</form>
</section>
<section class="panel inventory-panel">
<div class="panel-heading">
<h2>Koleksi menu</h2>
<a href="index.php#menu" class="text-link">Lihat katalog ↗</a>
</div>
<p class="inventory-note">Lihat seluruh koleksi dan perbarui sajian yang kamu kelola.</p>
<?php if (!$products): ?>
<div class="empty-state">
<span>🍽️</span>
<h3>Dapur masih sepi.</h3>
<p>Tambahkan sajian pertamamu di formulir.</p>
</div>
<?php else: ?>
<div class="inventory-list">
<?php foreach ($products as $p): ?>
<article class="inventory-item">
<div class="inventory-image">
<?php photo_html($p['image_url'], 'Foto sajian', $p['category']); ?>
</div>
<div class="inventory-details">
<div class="inventory-meta">
<span>#<?= (int) $p['id'] ?>
</span>
<span>
<?= h($p['category']) ?>
</span>
<span class="owner-tag">
Ditambahkan oleh <?= h($p['username']) ?>
</span>
</div>
<h3>
<?= h($p['name']) ?>
</h3>
<p>
<?= h($p['description']) ?>
</p>
<p class="stock-note">Tersisa <?= (int) $p['stock'] ?> porsi · <?= $pendingByProduct[$p['id']] ?? 0 ?> porsi menunggu verifikasi</p>
</div>
<div class="inventory-side">
<strong class="inventory-price">
<?= rupiah($p['price']) ?>
</strong>
<div class="inventory-actions">
<a class="action-btn" href="dashboard-aman.php?action=edit&amp;id=<?= (int) $p['id'] ?>#editor">Edit</a>
<form method="post" action="dashboard-aman.php" data-delete-form>
<input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
<button class="action-btn delete" type="submit">Hapus</button>
</form>
</div>
</div>
</article>
<?php endforeach; ?>
</div>
<?php endif; ?>
</section>
</div>
<script>
const imageInput = document.getElementById('image-url');
const imageFile = document.getElementById('image-file');
const preview = document.getElementById('image-preview');
const placeholder = document.getElementById('preview-placeholder');
const badge = document.getElementById('preview-source-badge');
const reviewBox = document.getElementById('file-review-box');
const reviewFilename = document.getElementById('review-filename');
const reviewFilesize = document.getElementById('review-filesize');
const reviewFiletype = document.getElementById('review-filetype');
const reviewVerdict = document.getElementById('review-security-verdict');
const btnClearFile = document.getElementById('btn-clear-file');

let activeObjectUrl = null;

function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024, sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function updatePreview() {
  if (activeObjectUrl) {
    URL.revokeObjectURL(activeObjectUrl);
    activeObjectUrl = null;
  }

  // Jika ada berkas dipilih via file input
  if (imageFile.files && imageFile.files[0]) {
    const file = imageFile.files[0];
    reviewBox.hidden = false;
    reviewFilename.textContent = file.name;
    reviewFilesize.textContent = formatBytes(file.size);
    reviewFiletype.textContent = file.type || 'Tidak diketahui';

    const ext = file.name.split('.').pop().toLowerCase();
    const allowedExts = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    const maxSize = 2 * 1024 * 1024; // 2MB

    const isValidExt = allowedExts.includes(ext);
    const isValidSize = file.size <= maxSize;

    if (!isValidExt) {
      badge.className = 'badge danger';
      badge.textContent = 'Format ditolak';
      reviewVerdict.innerHTML = '<div class="status-msg danger"><b>⚠ Format berkas tidak diizinkan:</b> Hanya ekstensi JPG, PNG, WEBP, dan GIF yang diterima. Berkas skrip/eksekusi (.php, dll) ditolak demi keamanan server.</div>';
      preview.removeAttribute('src');
      preview.hidden = true;
      placeholder.hidden = false;
      placeholder.innerHTML = '✕<br>Format berkas tidak diizinkan';
      return;
    } else if (!isValidSize) {
      badge.className = 'badge danger';
      badge.textContent = 'Ukuran melebihi batas';
      reviewVerdict.innerHTML = '<div class="status-msg danger"><b>⚠ Ukuran berkas terlalu besar:</b> Maksimal 2MB (ukuran berkas saat ini: ' + formatBytes(file.size) + ').</div>';
      preview.removeAttribute('src');
      preview.hidden = true;
      placeholder.hidden = false;
      placeholder.innerHTML = '✕<br>Ukuran melebihi batas 2MB';
      return;
    } else {
      badge.className = 'badge safe';
      badge.textContent = '✓ Siap disimpan (Aman)';
      reviewVerdict.innerHTML = '<div class="status-msg safe"><b>✓ Berkas valid untuk mode aman:</b> Lolos verifikasi format dan batas ukuran. Saat disimpan, nama berkas akan diacak otomatis secara kriptografis di server serta tipe MIME diverifikasi untuk mencegah Path Traversal.</div>';
      activeObjectUrl = URL.createObjectURL(file);
      preview.src = activeObjectUrl;
    }
  } else {
    // Tidak ada berkas baru dipilih, periksa URL atau nilai tersimpan
    reviewBox.hidden = true;
    const val = imageInput.value.trim();
    if (val !== '') {
      badge.className = 'badge neutral';
      badge.textContent = val.startsWith('uploads/') ? 'Gambar tersimpan' : 'Tautan URL';
      preview.src = val;
    } else {
      badge.className = 'badge neutral';
      badge.textContent = 'Belum ada gambar';
      preview.removeAttribute('src');
      preview.hidden = true;
      placeholder.hidden = false;
      placeholder.innerHTML = '▧<br>Pratinjau gambar sajian';
      return;
    }
  }
}

preview.addEventListener('load', () => {
  preview.hidden = false;
  placeholder.hidden = true;
});

preview.addEventListener('error', () => {
  preview.hidden = true;
  placeholder.hidden = false;
  placeholder.innerHTML = '✕<br>Gambar tidak dapat dimuat';
});

imageInput.addEventListener('input', () => {
  if (!imageFile.files || imageFile.files.length === 0) {
    updatePreview();
  }
});

imageFile.addEventListener('change', updatePreview);

btnClearFile.addEventListener('click', () => {
  imageFile.value = '';
  imageFile.dispatchEvent(new Event('change'));
});

// Panggil pertama kali saat halaman dimuat
updatePreview();
</script>
<?php page_bottom(); ?>
