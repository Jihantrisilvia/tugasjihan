<?php
require __DIR__ . '/config.php';
start_lab_session('aman');

if (($_SESSION['role'] ?? '') === 'admin') { go('dashboard-aman.php'); }
$error = '';
$isCustomer = !empty($_SESSION['user_id']) && ($_SESSION['role'] ?? '') === 'customer';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cart_data'])) {
    $raw = json_decode(posted('cart_data'), true);
    $cart = [];
    if (is_array($raw) && count($raw) <= 30) {
        foreach ($raw as $item) {
            if (!is_array($item)) { continue; }
            $id = filter_var($item['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            $qty = filter_var($item['qty'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 50]]);
            if ($id && $qty) { $cart[$id] = min(50, ($cart[$id] ?? 0) + $qty); }
        }
    }
    if (!$cart) { flash('error', 'Keranjang kosong', 'Pilih menu sebelum checkout.'); go('index.php#menu'); }
    $_SESSION['checkout_cart'] = $cart;
    go('checkout.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && posted('action') === 'place_order') {
    $name = trim(posted('customer_name'));
    $whatsapp = preg_replace('/[\s-]/', '', trim(posted('whatsapp')));
    $address = trim(posted('address'));
    $payment = posted('payment_method');
    $latRaw = trim(posted('latitude'));
    $lngRaw = trim(posted('longitude'));
    $latitude = $latRaw === '' ? null : filter_var($latRaw, FILTER_VALIDATE_FLOAT);
    $longitude = $lngRaw === '' ? null : filter_var($lngRaw, FILTER_VALIDATE_FLOAT);
    $cart = $_SESSION['checkout_cart'] ?? [];
    if (!csrf_ok()) { $error = 'Form kedaluwarsa. Muat ulang checkout dan coba lagi.'; }
    elseif (!$cart) { $error = 'Keranjang kosong. Pilih menu terlebih dahulu.'; }
    elseif ($name === '' || strlen($name) > 120 || $address === '' || strlen($address) > 1000) { $error = 'Isi nama dan alamat lengkap dengan benar.'; }
    elseif (!preg_match('/^\+?[0-9]{9,15}$/', $whatsapp)) { $error = 'Nomor WhatsApp harus 9–15 angka.'; }
    elseif (!in_array($payment, ['qris', 'transfer', 'cod'], true)) { $error = 'Pilih metode pembayaran yang tersedia.'; }
    elseif (($latRaw !== '' || $lngRaw !== '') && ($latitude === false || $longitude === false || $latitude === null || $longitude === null || $latitude < -90 || $latitude > 90 || $longitude < -180 || $longitude > 180)) { $error = 'Koordinat lokasi tidak valid. Kosongkan atau gunakan tombol Lacak lokasi.'; }

    $proof = $_FILES['payment_proof'] ?? null;
    $hasProof = $proof && ($proof['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
    if ($error === '' && $payment !== 'cod' && !$hasProof) { $error = 'Unggah bukti pembayaran untuk QRIS atau transfer.'; }
    $proofName = null;
    if ($error === '' && $hasProof) {
        $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf'];
        if ($proof['error'] !== UPLOAD_ERR_OK || $proof['size'] > 3 * 1024 * 1024) { $error = 'Bukti pembayaran maksimal 3 MB.'; }
        else {
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($proof['tmp_name']);
            if (!isset($allowed[$mime])) { $error = 'Bukti pembayaran harus JPG, PNG, WebP, atau PDF.'; }
            else {
                $directory = __DIR__ . '/private_uploads/proofs';
                if (!is_dir($directory) && !mkdir($directory, 0750, true)) { $error = 'Folder bukti pembayaran belum siap.'; }
                else {
                    $proofName = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
                    if (!move_uploaded_file($proof['tmp_name'], $directory . '/' . $proofName)) { $error = 'Bukti pembayaran gagal disimpan.'; }
                }
            }
        }
    }

    if ($error === '') {
        try {
            $ids = array_keys($cart);
            $marks = implode(',', array_fill(0, count($ids), '?'));
            $statement = $pdo->prepare("SELECT id, name, price, stock FROM products WHERE id IN ($marks)");
            $statement->execute($ids);
            $products = array_column($statement->fetchAll(), null, 'id');
            $total = 0;
            if (count($products) !== count($cart)) { throw new RuntimeException('Ada menu yang tidak tersedia lagi.'); }
            foreach ($cart as $id => $qty) {
                if ($qty > (int) $products[$id]['stock']) { throw new RuntimeException($products[$id]['name'] . ' tersisa ' . $products[$id]['stock'] . ' porsi.'); }
                $total += (int) $products[$id]['price'] * $qty;
            }
            $pdo->beginTransaction();
            $code = 'KS-' . strtoupper(bin2hex(random_bytes(5)));
            $statement = $pdo->prepare('INSERT INTO orders (order_code,user_id,customer_name,whatsapp,address,latitude,longitude,payment_method,proof_path,total,status) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
            $statement->execute([$code, $isCustomer ? (int) $_SESSION['user_id'] : null, $name, $whatsapp, $address, $latitude, $longitude, $payment, $proofName, $total, 'pending']);
            $orderId = (int) $pdo->lastInsertId();
            $statement = $pdo->prepare('INSERT INTO order_items (order_id,product_id,product_name,quantity,unit_price,subtotal) VALUES (?,?,?,?,?,?)');
            foreach ($cart as $id => $qty) {
                $product = $products[$id];
                $statement->execute([$orderId, $id, $product['name'], $qty, $product['price'], $product['price'] * $qty]);
            }
            $pdo->commit();
            unset($_SESSION['checkout_cart']);
            $_SESSION['checkout_receipt'] = $orderId;
            go('checkout.php?receipt=1');
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            if ($proofName) { @unlink(__DIR__ . '/private_uploads/proofs/' . $proofName); }
            $error = $e instanceof RuntimeException ? $e->getMessage() : 'Pesanan belum dapat disimpan. Coba lagi.';
        }
    } elseif ($proofName) { @unlink(__DIR__ . '/private_uploads/proofs/' . $proofName); }
}

$receipt = null;
if (isset($_GET['receipt']) && !empty($_SESSION['checkout_receipt'])) {
    $statement = $pdo->prepare('SELECT * FROM orders WHERE id = ?');
    $statement->execute([(int) $_SESSION['checkout_receipt']]);
    $receipt = $statement->fetch();
}
if (!$receipt && empty($_SESSION['checkout_cart'])) { go('index.php#menu'); }

$items = [];
$total = 0;
$profile = null;
if ($receipt) {
    $statement = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ?');
    $statement->execute([$receipt['id']]);
    $items = $statement->fetchAll();
    $total = (int) $receipt['total'];
} else {
    $cart = $_SESSION['checkout_cart'];
    $ids = array_keys($cart);
    $statement = $pdo->prepare('SELECT id,name,price,stock FROM products WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')');
    $statement->execute($ids);
    foreach ($statement->fetchAll() as $product) {
        $qty = $cart[$product['id']];
        $items[] = ['product_name' => $product['name'], 'quantity' => $qty, 'unit_price' => $product['price'], 'subtotal' => $product['price'] * $qty, 'stock' => $product['stock']];
        $total += $product['price'] * $qty;
    }
    if ($isCustomer) {
        $statement = $pdo->prepare('SELECT username,address,whatsapp FROM users WHERE id = ?');
        $statement->execute([$_SESSION['user_id']]);
        $profile = $statement->fetch();
    }
}
page_top($receipt ? 'Pesanan diterima' : 'Checkout', '', 'checkout');
?>
<section class="checkout-layout">
  <div class="checkout-heading"><span class="eyebrow">KAWAN SANTAP / PESANAN</span><h1><?= $receipt ? 'Pesanan menunggu verifikasi.' : 'Selesaikan pesananmu.' ?></h1><p>Stok baru berkurang setelah admin memverifikasi pesanan.</p></div>
  <?php if ($error): ?><div class="form-error" role="alert"><?= h($error) ?></div><?php endif; ?>
  <div class="checkout-grid">
    <div class="panel checkout-card">
      <div class="checkout-card-heading"><h2>Rincian menu</h2><span class="checkout-count"><?= count($items) ?> menu</span></div>
      <div class="checkout-table-wrap"><table class="checkout-table"><thead><tr><th>Menu</th><th>Qty</th><th>Subtotal</th></tr></thead><tbody>
      <?php foreach ($items as $item): ?><tr><td><?= h($item['product_name']) ?><?php if (isset($item['stock'])): ?><small> · Tersisa <?= (int) $item['stock'] ?> porsi</small><?php endif; ?></td><td><?= (int) $item['quantity'] ?></td><td><?= rupiah($item['subtotal']) ?></td></tr><?php endforeach; ?>
      </tbody><tfoot><tr><td colspan="2">Total</td><td><?= rupiah($total) ?></td></tr></tfoot></table></div>
      <?php if ($receipt): ?><p><strong>No. pesanan: <?= h($receipt['order_code']) ?></strong></p><p>Status: menunggu verifikasi admin. Simpan nomor pesanan ini.</p><a class="btn primary" href="index.php#menu">Kembali ke menu →</a><?php endif; ?>
    </div>
    <?php if (!$receipt): ?>
    <div class="panel checkout-card">
      <h2>Data pemesan</h2>
      <?php if (!$isCustomer): ?><div class="checkout-account-prompt"><div><strong>Pesan sebagai tamu?</strong><p>Formulir di bawah bisa langsung dipakai. Buat akun customer jika ingin menyimpan alamat dan melihat riwayat pesanan.</p></div><div class="checkout-account-actions"><a class="btn small primary" href="register-customer.php"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> Daftar customer</a><a class="btn small ghost" href="login-customer.php"><i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i> Masuk akun</a></div></div><?php endif; ?>
      <form method="post" action="checkout.php" enctype="multipart/form-data" class="checkout-form">
        <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="place_order">
        <label class="field"><span>Nama pemesan</span><input name="customer_name" maxlength="120" value="<?= h(posted('customer_name') ?: ($profile['username'] ?? '')) ?>" required></label>
        <label class="field"><span>WhatsApp yang bisa dihubungi</span><input name="whatsapp" type="tel" inputmode="tel" value="<?= h(posted('whatsapp') ?: ($profile['whatsapp'] ?? '')) ?>" placeholder="081234567890" required></label>
        <label class="field"><span>Alamat lengkap pengiriman <span class="address-source" id="address-source" data-source="<?= posted('latitude') !== '' ? 'gps' : 'manual' ?>"><?= posted('latitude') !== '' ? 'Dari GPS' : 'Diisi manual' ?></span></span><textarea id="delivery-address" name="address" maxlength="1000" rows="3" placeholder="Nama jalan, nomor rumah, RT/RW, kelurahan, kecamatan, kota, dan patokan" required><?= h(posted('address') ?: ($profile['address'] ?? '')) ?></textarea><small>Periksa kembali nomor rumah dan patokan, termasuk bila alamat diisi dari GPS.</small></label>
        <div class="location-fields"><input id="latitude" name="latitude" type="hidden" value="<?= h(posted('latitude')) ?>"><input id="longitude" name="longitude" type="hidden" value="<?= h(posted('longitude')) ?>"><button class="btn small ghost" type="button" id="locate-btn"><i class="fa-solid fa-location-crosshairs" aria-hidden="true"></i> Lacak lokasi (opsional)</button><span id="location-result" class="muted" role="status">Klik untuk mengisi alamat otomatis, atau ketik alamat sendiri.</span></div>
        <small class="location-credit">Alamat otomatis menggunakan data <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">© OpenStreetMap contributors</a>.</small>
        <label class="field"><span>Metode pembayaran</span><select name="payment_method" id="payment-method"><option value="qris">QRIS</option><option value="transfer">Transfer bank</option><option value="cod">Bayar di tempat (COD)</option></select></label>
        <p class="payment-note">QRIS / transfer: lampirkan bukti pembayaran. COD: bukti tidak diperlukan. Rekening simulasi BCA 123-456-7890 a.n. Kawan Santap.</p>
        <div class="checkout-qr" id="qris-info"><img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=KAWAN-SANTAP-DEMO" alt="QR ilustrasi untuk pembayaran simulasi"><small>QR ini hanya ilustrasi tugas kuliah.</small></div>
        <div class="field"><span>Bukti pembayaran (JPG, PNG, WebP, PDF; maks. 3 MB)</span><div class="file-picker"><input id="payment-proof" name="payment_proof" type="file" accept="image/jpeg,image/png,image/webp,application/pdf"><label for="payment-proof" class="file-picker-button"><i class="fa-solid fa-cloud-arrow-up" aria-hidden="true"></i> Pilih bukti</label><span class="file-picker-name" data-file-name>Belum ada berkas dipilih</span></div><div class="proof-preview" id="proof-preview" hidden><div class="proof-preview-media"><img id="proof-preview-image" alt="Pratinjau bukti pembayaran" hidden><span id="proof-preview-pdf" hidden><i class="fa-solid fa-file-pdf" aria-hidden="true"></i> PDF</span></div><div class="proof-preview-details"><strong id="proof-preview-name"></strong><small id="proof-preview-size"></small><button id="remove-proof" class="btn small ghost" type="button"><i class="fa-solid fa-trash-can" aria-hidden="true"></i> Hapus bukti</button></div></div></div>
        <button class="btn primary full-width" type="submit">Kirim pesanan · <?= rupiah($total) ?> →</button>
      </form>
    </div>
    <?php endif; ?>
  </div>
</section>
<script>
<?php if ($receipt): ?>localStorage.removeItem('rasa_cart');<?php endif; ?>
const locateButton=document.getElementById('locate-btn');
const addressField=document.getElementById('delivery-address');
const addressSource=document.getElementById('address-source');
const latitudeField=document.getElementById('latitude');
const longitudeField=document.getElementById('longitude');
let lastLookup=0;
const setAddressSource=(type,label)=>{addressSource.dataset.source=type;addressSource.textContent=label;};
addressField?.addEventListener('input',()=>{
  if(latitudeField.value && longitudeField.value){setAddressSource('gps-edited','GPS + disunting manual');}
  else{setAddressSource('manual','Diisi manual');}
});
locateButton?.addEventListener('click',async()=>{
  const result=document.getElementById('location-result');
  if(!navigator.geolocation){result.textContent='Browser tidak menyediakan GPS. Isi alamat secara manual.';return;}
  if(Date.now()-lastLookup<1100)return;
  locateButton.disabled=true;
  result.textContent='Mengambil posisi GPS…';
  const previousAddress=addressField.value;
  try{
    const position=await new Promise((resolve,reject)=>navigator.geolocation.getCurrentPosition(resolve,reject,{enableHighAccuracy:true,timeout:10000}));
    const lat=position.coords.latitude.toFixed(7);
    const lon=position.coords.longitude.toFixed(7);
    latitudeField.value=lat;
    longitudeField.value=lon;
    result.textContent='Posisi didapat. Mencari alamat jalan…';
    const cacheKey=`ks-geocode-${Number(lat).toFixed(4)}-${Number(lon).toFixed(4)}`;
    let foundAddress='';
    try{foundAddress=sessionStorage.getItem(cacheKey)||'';}catch(error){}
    if(!foundAddress){
      lastLookup=Date.now();
      const reverseUrl=new URL('https://nominatim.openstreetmap.org/reverse');
      reverseUrl.search=new URLSearchParams({format:'jsonv2',lat,lon,'accept-language':'id',addressdetails:'1'}).toString();
      const response=await fetch(reverseUrl,{referrerPolicy:'origin'});
      if(!response.ok)throw new Error('Alamat belum tersedia');
      const data=await response.json();
      foundAddress=typeof data.display_name==='string' ? data.display_name.trim().slice(0,1000) : '';
      if(!foundAddress)throw new Error('Alamat belum tersedia');
      try{sessionStorage.setItem(cacheKey,foundAddress);}catch(error){}
    }
    if(addressField.value===previousAddress){
      addressField.value=foundAddress;
      setAddressSource('gps','Diisi otomatis dari GPS');
      result.textContent='Alamat otomatis terisi. Periksa dan tambahkan nomor rumah atau patokan bila perlu.';
    }else{
      setAddressSource('gps-edited','GPS + alamat manual');
      result.textContent='Titik GPS tersimpan. Alamat yang sedang kamu ketik tetap dipakai.';
    }
  }catch(error){
    if(latitudeField.value && longitudeField.value){
      setAddressSource('gps-edited','GPS + alamat manual');
      result.textContent='Posisi GPS tersimpan, tetapi alamat jalan tidak ditemukan. Isi alamat lengkap secara manual.';
    }else{result.textContent='Lokasi gagal diambil. Isi alamat secara manual.';}
  }finally{locateButton.disabled=false;}
});
const method=document.getElementById('payment-method');
const proof=document.getElementById('payment-proof');
const preview=document.getElementById('proof-preview');
let proofObjectUrl=null;
if(method&&proof){
  const sync=()=>{proof.required=method.value!=='cod';document.getElementById('qris-info').hidden=method.value!=='qris';};
  method.addEventListener('change',sync);sync();
  proof.addEventListener('change',()=>{
    if(proofObjectUrl){URL.revokeObjectURL(proofObjectUrl);proofObjectUrl=null;}
    const file=proof.files?.[0];
    preview.hidden=!file;
    if(!file)return;
    document.getElementById('proof-preview-name').textContent=file.name;
    document.getElementById('proof-preview-size').textContent=`${(file.size/1024).toFixed(1)} KB · ${file.type||'Tipe berkas tidak dikenal'}`;
    const image=document.getElementById('proof-preview-image');
    const pdf=document.getElementById('proof-preview-pdf');
    const isImage=['image/jpeg','image/png','image/webp'].includes(file.type);
    image.hidden=!isImage;pdf.hidden=isImage;
    if(isImage){proofObjectUrl=URL.createObjectURL(file);image.src=proofObjectUrl;}
    else{image.removeAttribute('src');}
  });
  document.getElementById('remove-proof').addEventListener('click',()=>{proof.value='';proof.dispatchEvent(new Event('change'));});
}
</script>
<?php page_bottom(); ?>
